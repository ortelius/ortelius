#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "transfer.h"
#include "model.h"
#include "cmdline.h"
#include "exceptions.h"
#include "context.h"
#include "dm.h"
#include "expr.h"	// For CharPtr only
#include "execute.h"
#include "tinyxml.h"
#include "properties.h"
#include "pathname.h"


class RtiTransferProviderImpl : public virtual TransferProviderImpl
{
private:
	const char *m_protocol;
	Server &m_target;
	Environment &m_tgtenv;
	Credentials &m_credentials;
	Component *m_comp;
	char *m_targetPath;

public:
	RtiTransferProviderImpl(
		const char *protocol, Server &target,
		Environment &tgtenv, Credentials &creds,
		Component *comp, const char *targetPath);
	virtual ~RtiTransferProviderImpl();

	List<TransferResult> *transferToServer(const char *dropzone, Context &ctx);

	void transferFromServer(const char *dropzone, Context &ctx);

	int runScriptOnServer(
		const char *shell, const char *script, class StringList *params,
		bool copy, Context &ctx); 
};


class RtiTransferProviderImplFactory : public virtual TransferProviderImplFactory
{
private:
	const char *m_protocol;

public:
	RtiTransferProviderImplFactory(const char *protocol);

	TransferProviderImpl *create(
		Server &target, Environment &tgtenv, Credentials &creds,
		Component *comp, const char *targetPath);
};



///////////////////////////////////////////////////////////////////////////////
// TransferResult
///////////////////////////////////////////////////////////////////////////////

TransferResult::TransferResult()
	: m_sourcedir(NULL), m_targetdir(NULL), m_filename(NULL),
	  m_error(NULL), m_size(-1), m_md5(NULL), m_istext(false),
	  m_dzfile(NULL)
{}


TransferResult::~TransferResult()
{
	SAFE_FREE(m_sourcedir);
	SAFE_FREE(m_targetdir);
	SAFE_FREE(m_filename);
	SAFE_FREE(m_error);
	SAFE_FREE(m_md5);
	m_dzfile = NULL;	// owned by dropzone
}


void TransferResult::setProperty(const char* prop, const char *value)
{
	if(strcmp(prop, "sourcedir") == 0) {
		m_sourcedir = DUP_NULL(value);
	} else if(strcmp(prop, "targetdir") == 0) {
		m_targetdir = DUP_NULL(value);
	} else if(strcmp(prop, "filename") == 0) {
		m_filename = DUP_NULL(value);
	} else if(strcmp(prop, "error") == 0) {
		if(!m_error) {
			m_error = DUP_NULL(value);
		}
	} else if(strcmp(prop, "errortext") == 0) {
		m_error = DUP_NULL(value);
	} else if(strcmp(prop, "size") == 0) {
		m_size = value ? ATOINT32(value) : -1;
	} else if(strcmp(prop, "md5") == 0) {
		m_md5 = DUP_NULL(value);
	} else if(strcmp(prop, "mode") == 0) {
		m_istext = (value && (STRCASECMP(value, "Text") == 0)) ? true : false;
	} else {
		debug0("Unknown transfer property '%s'", prop);
	}
}


char *TransferResult::targetFilename()
{
	if(!m_filename) {
		return NULL;
	}
	if(!m_targetdir) {
		return strdup(m_filename);
	}

	char *ret = (char*) malloc(strlen(m_targetdir) + strlen(m_filename) + 2);
	sprintf(ret, "%s/%s", m_targetdir, m_filename);
	return ret;
}


char *TransferResult::dropzoneFilename()
{
	if(!m_filename) {
		return NULL;
	}
	if(!m_sourcedir) {
		return strdup(m_filename);
	}

	char *ret = (char*) malloc(strlen(m_sourcedir) + strlen(m_filename) + 2);
	sprintf(ret, "%s%s%s", m_sourcedir, DIR_SEP_STR, m_filename);
	return ret;
}


///////////////////////////////////////////////////////////////////////////////
// TransferProviderImpl
///////////////////////////////////////////////////////////////////////////////

/*virtual*/ TransferProviderImpl::~TransferProviderImpl()
{}


///////////////////////////////////////////////////////////////////////////////
// TransferProviderImplFactory
///////////////////////////////////////////////////////////////////////////////

/*virtual*/ TransferProviderImplFactory::~TransferProviderImplFactory()
{}


///////////////////////////////////////////////////////////////////////////////
// TransferProviderImplRegistry
///////////////////////////////////////////////////////////////////////////////

TransferProviderImplRegistry *TransferProviderImplRegistry::s_instance = NULL;


TransferProviderImplRegistry::TransferProviderImplRegistry()
	: m_factories(false, true)
{}


/*static*/ TransferProviderImplRegistry &TransferProviderImplRegistry::instance()
{
	if(!s_instance) {
		s_instance = new TransferProviderImplRegistry();
	}
	return *s_instance;
}


/*static*/ void TransferProviderImplRegistry::cleanup()
{
	SAFE_DELETE(s_instance);
}


void TransferProviderImplRegistry::registerFactory(const char *name, TransferProviderImplFactory *factory)
{
	m_factories.put(name, factory);
}


void TransferProviderImplRegistry::registerBuiltIns()
{
	registerFactory("ftp",  new RtiTransferProviderImplFactory("ftp"));
	registerFactory("ftps", new RtiTransferProviderImplFactory("ftps"));
	registerFactory("sftp", new RtiTransferProviderImplFactory("sftp"));
	registerFactory("win",  new RtiTransferProviderImplFactory("win"));
}


TransferProviderImplFactory *TransferProviderImplRegistry::getFactory(const char *name)
{
	return m_factories.get(name);
}


///////////////////////////////////////////////////////////////////////////////
// RtiTransferProviderImpl
///////////////////////////////////////////////////////////////////////////////

RtiTransferProviderImpl::RtiTransferProviderImpl(
	const char *protocol, Server &target, Environment &tgtenv,
	Credentials &creds, Component *comp, const char *targetPath
	)
	: m_protocol(protocol), m_target(target), m_tgtenv(tgtenv),
	  m_credentials(creds), m_comp(comp), m_targetPath(DUP_NULL(targetPath))
{}


/*virtual*/ RtiTransferProviderImpl::~RtiTransferProviderImpl()
{
	SAFE_FREE(m_targetPath);
}


List<TransferResult> *RtiTransferProviderImpl::transferToServer(const char *dropzone, Context &ctx)
{
	// Dropzone: $TEMP/$DEPID.$DEPMAJOR
	// Targetpath: whatever is specified on the statement, server or environment
	// Username/Password: ???

	const char *basedir = (m_comp?m_comp->basedir():NULL);
	if (!basedir) {
		basedir = m_target.basedir();
	}
	if(!basedir) {
		basedir = m_tgtenv.basedir();
	}
	debug1("basedir for server '%s' is '%s'", m_target.name(), (basedir ? basedir : "(null)"));

	if(!basedir) {
		throw RuntimeError(ctx.stack(), "basedir not specified for server '%s'", m_target.name());
	}

	// TODO: Use comp and target to calculate the actual target dir
	// This code is rough - will need to check for absolute paths etc.
	if(m_targetPath) {
		PathNameImpl *basedirPath = m_target.createPath(basedir);
		if(basedirPath) {
			PathNameImpl *appendedPath = basedirPath->append(m_targetPath);
			basedir = appendedPath->path();
			debug0("appended basedir = '%s'", basedir);
		}
	}

	//dmtransfer -protocol sftp -sourcedir "C:\development\Project Manager" -targetdir /tmp/testing -user phil -password ncc1701 -server 192.168.8.150

	char dmtransfer[1024];
	sprintf(dmtransfer, "%s%slib%sdmtransfer%s",
		ctx.dm().dmHome(), DIR_SEP_STR, DIR_SEP_STR, EXE_EXT);

	CmdLine cmd(dmtransfer);
	cmd.add("-protocol").add(m_protocol)
		.add("-sourcedir").add(dropzone)
		.add("-targetdir").add(basedir);

	switch(m_credentials.kind()) {
	case CREDENTIALS_ENCRYPTED:
	case CREDENTIALS_IN_DATABASE:
	case CREDENTIALS_FROM_VARS: {
		// decrypt always allocates memory
		char *username = m_credentials.getDecryptedUsername(m_tgtenv, ctx);
		char *password = m_credentials.getDecryptedPassword(m_tgtenv, ctx);
		cmd.add("-user").add(username).add("-password").add(password);
		SECURE_FREE(username);
		SECURE_FREE(password);
		}
		break;
	default:
		throw RuntimeError(ctx.stack(), "Credentials kind %d not yet implemented", m_credentials.kind());
	}

	if(!m_target.serverType() || !m_target.serverType()->id()) {
		ctx.writeToStdOut("WARNING: Server '%s' has no server type set", m_target.name());
	}

	LINE_END_FORMAT lineends = m_target.lineends();
	switch(lineends) {
	case LINE_ENDS_OFF:     cmd.add("-target").add("off");  debug2("lineends = OFF"); break;
	case LINE_ENDS_UNIX:    cmd.add("-target").add("unix"); debug2("lineends = UNIX"); break;
	case LINE_ENDS_WINDOWS: cmd.add("-target").add("win");  debug2("lineends = WIN"); break;
	case LINE_ENDS_MAC:     cmd.add("-target").add("mac");  debug2("lineends = MAC"); break;
	}

	cmd.add("-server").add(m_target.hostname());

	/**/char *pocmd = cmd.toCommandString(true);
	/**/debug1("%s", pocmd);

	//int res = pclose(popen(pocmd, "w"));
	/**/free(pocmd);

	//if(res == -1) {
	//	throw RuntimeError(ctx.stack(), "Command did not execute successfully");
	//}

	CapturedData *cd = NULL;
	int tempExitStatus;
	int ret = executeAndCapture(ctx.stream(), cmd, NULL, false, ctx.threadId(), &tempExitStatus, &cd, NULL);
	if(ret) {
		ctx.dm().writeToStdOut("dmtransfer failed to execute");
//#ifdef WIN32
		SAFE_DELETE(cd);
		throw RuntimeError(ctx.stack(), "Command did not execute successfully");
//#else
//		// Fake Linux version!!!
//		// TODO: Remove this code!!!
//		cd = new CapturedData();
//		char temp[4096];
//		if(strstr(basedir, "webapps")) {
//			sprintf(temp, "<files><file>  <sourcedir>%s</sourcedir> "
//				" <targetdir>/srv/tomcat6/webapps</targetdir>  <filename>dmdemo.war</filename> "
//				" <size>12660</size> <mode>Binary</mode>  <error>N</error>  <errortext></errortext> "
//				" <md5>64149c025b202bac9029849d0b33ab76</md5></file></files>",
//				dropzone);
//		} else {
//			sprintf(temp, "<files><file>  <sourcedir>%s2</sourcedir> "
//				" <targetdir>/tmp/Deploy/server2</targetdir>  <filename>add_dob.sql</filename> "
//				" <size>442</size>  <mode>Binary</mode>  <error>N</error>  <errortext></errortext> "
//				" <md5>c7a2b32b6451f010e4775d23d7a853da</md5></file><file> "
//				" <sourcedir>%s</sourcedir>  <targetdir>/tmp/Deploy/server2</targetdir> "
//				" <filename>createtable.sql</filename>  <size>397</size>  <mode>Binary</mode> "
//				" <error>N</error>  <errortext></errortext>  <md5>cddeb96f6b1dba1c72ea5207d1a70f95</md5></file><file> "
//				" <sourcedir>%s</sourcedir>  <targetdir>/tmp/Deploy/server2</targetdir> "
//				" <filename>rollback_dob.sql</filename>  <size>36</size>  <mode>Binary</mode>"
//				"<error>N</error>  <errortext></errortext>  <md5>037be30d516ef6895625a768732d39ba</md5></file></files>",
//				dropzone, dropzone, dropzone);
//		}
//		cd->appendStandardOut(temp, strlen(temp));
//#endif /*WIN32*/
	}
	debug1("tempExitStatus = %d", tempExitStatus);

	if(cd) {
		char *temp = NULL;
		cd->appendStandardErr("\0", 1);
		for(char *eline = STRTOK_R((char*) cd->standardErr(), "\r\n", &temp);
			eline; eline = STRTOK_R(NULL, "\r\n", &temp)) {
			printf("ERROR: %s\n", eline);
		}

		cd->appendStandardOut("\0", 1);
		CapturedData *xml = new CapturedData();
		temp = NULL;
		for(char *line = STRTOK_R((char*) cd->standardOut(), "\r\n", &temp);
			line; line = STRTOK_R(NULL, "\r\n", &temp)) {
				char *x;
				for(x = line; *x && ((*x == ' ') || (*x == '\t')); x++) { /*empty*/ }
				if(*x == '<') {
					xml->appendStandardOut(line, strlen(line));
				} else {
					printf("INFO: %s\n", line);
				}
		}

		xml->appendStandardOut("\0", 1);
		//ctx.dm().writeBufferToStdOut(ctx.threadId(), xml->standardOut(), xml->bytesOfStandardOut());
		//ctx.dm().writeToStdOut("");

		List<TransferResult> *ret = new List<TransferResult>(true);

		TiXmlDocument doc;
		doc.Parse(xml->standardOut());

		if(!doc.Error()) {
			TiXmlElement *root = doc.FirstChildElement("files");
			if(root) {
				for(TiXmlElement *file = root->FirstChildElement("file"); file; file = file->NextSiblingElement("file")) {
					TransferResult *result = new TransferResult();
					for(TiXmlElement *node = file->FirstChildElement(); node; node = node->NextSiblingElement()) {
						result->setProperty(node->Value(), node->GetText());
					}
					ret->add(result);
				}
			} else {
				ctx.dm().writeToStdOut("root not found");
			}
		} else {
			ctx.dm().writeToStdOut("error parsing dmtransfer XML");
		}

		SAFE_DELETE(xml);
		SAFE_DELETE(cd);
		return ret;
	}

	return NULL;
}


void RtiTransferProviderImpl::transferFromServer(const char *dropzone, Context &ctx)
{
	// TODO: Implement checkin transfer
	throw RuntimeError(ctx.stack(), "NOT YET IMPLEMENTED!");
}


int RtiTransferProviderImpl::runScriptOnServer(
	const char *shell, const char *script, StringList *params, bool copy, Context &ctx)
{
	// TODO: Change this to the real program we will use
	// dmtransfer -protocol xxx -server mmm -user uuu -password ppp -exec ccc aaa aaa
	// dmtransfer -protocol xxx -server mmm -user uuu -password ppp -copyexec ccc aaa aaa

	char dmtransfer[1024];
	//RTOEXECP2:sprintf(dmtransfer, "%s%slib%srtoexecp2%s",
	//RTOEXECP2:	ctx.dm().dmHome(), DIR_SEP_STR, DIR_SEP_STR, EXE_EXT);
	sprintf(dmtransfer, "%s%slib%sdmtransfer%s",
		ctx.dm().dmHome(), DIR_SEP_STR, DIR_SEP_STR, EXE_EXT);

	CmdLine cmd(dmtransfer);
	//RTOEXECP2:cmd.add("-m").add(m_target.hostname()).add("-syn").add("-force");
	cmd.add("-protocol").add(m_protocol)
		.add("-server").add(m_target.hostname());

	switch(m_credentials.kind()) {
	case CREDENTIALS_ENCRYPTED:
	case CREDENTIALS_IN_DATABASE:
	case CREDENTIALS_FROM_VARS: {
		// decrypt always allocates memory
		char *username = m_credentials.getDecryptedUsername(m_tgtenv, ctx);
		char *password = m_credentials.getDecryptedPassword(m_tgtenv, ctx);
		//RTOEXECP2:cmd.add("-usr").add(username).add("-pw").add(password);
		cmd.add("-user").add(username).add("-password").add(password);
		SECURE_FREE(username);
		SECURE_FREE(password);
		}
		break;
	default:
		throw RuntimeError(ctx.stack(), "Credentials kind %d not yet implemented", m_credentials.kind());
	}

	cmd.add(copy ? "-copyexec" : "-exec");

	if(shell) {
		cmd.add(shell);
	}
	cmd.add(script);

	if(params) {
		StringListIterator iter(*params);
		for(const char *p = iter.first(); p; p = iter.next()) {
			cmd.add(p);
		}
	}

	debug1("%s", cmd.toCommandString(false));

	bool bShowOutput = true;

	CapturedData *cd = NULL;
	int tempExitStatus = -1;
	int ret = executeAndCapture(ctx.stream(), cmd, NULL, bShowOutput, ctx.threadId(), &tempExitStatus, &cd, NULL);
	if(ret) {
		ctx.dm().writeToStdOut("remotescript failed to execute");
	}

	SAFE_DELETE(cd);
	return tempExitStatus;
}


///////////////////////////////////////////////////////////////////////////////
// RtiTransferProviderImplFactory
///////////////////////////////////////////////////////////////////////////////

RtiTransferProviderImplFactory::RtiTransferProviderImplFactory(const char *protocol)
	: m_protocol(protocol)
{}


TransferProviderImpl *RtiTransferProviderImplFactory::create(
	Server &target, Environment &tgtenv, Credentials &creds,
	Component *comp, const char *targetPath)
{
	//const char *broker  = parent.getProperty("broker");

	return new RtiTransferProviderImpl(
		m_protocol, target, tgtenv, creds, comp, targetPath);
}


extern "C" int rti_PluginInstall(DM &dm)
{
	// name, required, overrideable, appendable
	List<PropertyDef> *propdefs = new List<PropertyDef>(true);

	dm.installProviderImpl("ftp",  NULL, OBJ_KIND_TRANSFER, propdefs);
	dm.installProviderImpl("ftps", NULL, OBJ_KIND_TRANSFER, propdefs);
	dm.installProviderImpl("sftp", NULL, OBJ_KIND_TRANSFER, propdefs);
	dm.installProviderImpl("win",  NULL, OBJ_KIND_TRANSFER, propdefs);
	return 0;
}
