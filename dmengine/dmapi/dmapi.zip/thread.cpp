#ifdef WIN32
#include <windows.h>
#else
#include <pthread.h>
#if defined(__LINUX__) || defined(__linux__)
#include <errno.h>
#endif /*Linux*/
#endif /*WIN32*/

#include <stdio.h>

#include "thread.h"
#include "context.h"
#include "dm.h"
#include "exceptions.h"
#include "autoptr.h"


THREAD_RETURN_TYPE_DECL ThreadStartFunc(void *arg)
{
	((Thread*) arg)->run();
	return 0;
}


///////////////////////////////////////////////////////////////////////////////
// Runnable
///////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////
// Thread
///////////////////////////////////////////////////////////////////////////////

void *Thread::s_globallock = NULL;


Thread::Thread()
	: m_id(0)
#ifndef WIN32
	, m_joined(false)
#endif /*WIN32*/
{}


/*vritual*/ Thread::~Thread()
{}


void Thread::start()
{
#ifdef WIN32
	m_id = CreateThread(NULL, 0, ThreadStartFunc, (LPVOID) this, 0, NULL);
#else
	pthread_create(&m_id, NULL, ThreadStartFunc, this);
#endif /*WIN32*/
}


void Thread::stop()
{}


void Thread::waitFor()
{
#ifdef WIN32
	WaitForSingleObject(m_id, INFINITE);
#else
	if(!m_joined) {
		pthread_join(m_id, NULL);
		m_joined = true;
	} else {
		debug0("Thread %p id %x already joined", this, m_id);
	}
#endif /*WIN32*/
}


#if defined(__LINUX__) || defined(__linux__)
int Thread::waitForWithTimeout()
{
	struct timespec ts;
	if(clock_gettime(CLOCK_REALTIME, &ts) == -1) {
		debug0("clock_gettime failed");
		return -1;
	} 
	ts.tv_nsec += 50000;	// 50 milliseconds - 1/20th of a second
	int s = pthread_timedjoin_np(m_id, NULL, &ts);
	switch(s) {
	case 0:
		// Thread has exited within the timeout
		m_joined = true;
		return 0;
	case ETIMEDOUT:
		// Thread still busy after timeout
		return 1;
	default:
		debug0("pthread_timedjoin_np failed - %d", s);
		return -2;
	}
}
#endif /*Linux*/


/*virtual*/ void Thread::run()
{}


/*static*/ long Thread::currentThreadId()
{
#ifdef WIN32
	return GetCurrentThreadId();
#else
	return pthread_self();
#endif /*WIN32*/
}


/*static*/ void Thread::lock()
{
	if(!s_globallock) {
#ifdef WIN32
		s_globallock = malloc(sizeof(CRITICAL_SECTION));
		InitializeCriticalSection((CRITICAL_SECTION*) s_globallock);
#else
		s_globallock = malloc(sizeof(pthread_mutex_t));
		pthread_mutex_init((pthread_mutex_t*) s_globallock, NULL);
#endif /*WIN32*/
	}

#ifdef WIN32
	EnterCriticalSection((CRITICAL_SECTION*) s_globallock);
#else
	pthread_mutex_lock((pthread_mutex_t*) s_globallock);
#endif /*WIN32*/
}


/*static*/ void Thread::unlock()
{
#ifdef WIN32
	LeaveCriticalSection((CRITICAL_SECTION*) s_globallock);
#else
	pthread_mutex_unlock((pthread_mutex_t*) s_globallock);
#endif /*WIN32*/
}



///////////////////////////////////////////////////////////////////////////////
// DMThread
///////////////////////////////////////////////////////////////////////////////

DMThread::DMThread(DMThreadList &threadList, class Context *ctx)
	: Thread(), m_threadList(threadList), m_ex(NULL), m_exitCode(0), m_ctx(ctx)
{
	m_threadList.add(this);
}


/*virtual*/ DMThread::~DMThread()
{}


/**
 * Asks the thread list if the thread is allowed to start and if it is, starts
 * the thread.  If the thread was not allowed to start, the thread list will
 * start it for us later.
 */
void DMThread::start()
{
	if(m_threadList.threadStart(this)) {
		Thread::start();
		debug0("Thread %p started with id %x", this, m_id);
	}
}


class DMException *DMThread::exception()
{
	return m_ex;
}


int DMThread::exitCode()
{
	return m_exitCode;
}


void DMThread::run()
{
	m_ctx->setThreadId((long) m_id);

	try {
		m_ctx->dm().writeToLogFile("Thread %x running", m_id);
		execute(*m_ctx);
		m_ctx->dm().writeToLogFile("Thread %x finished", m_id);
	} catch(DMException &ex) {
		m_ctx->dm().writeToLogFile("Thread %x threw exception (%s)", m_id, (ex.getMessage() ? ex.getMessage() : "(null)"));
		m_ex = ex.clone();
		m_exitCode = -1;
	}
}


/*virtual*/ void DMThread::execute(class Context &ctx)
{}


///////////////////////////////////////////////////////////////////////////////
// DMThreadList
///////////////////////////////////////////////////////////////////////////////

DMThreadList::DMThreadList(int threadLimit)
	: List<DMThread>(true), m_threadLimit(threadLimit),
	  m_activeThreads(new List<DMThread>()), m_pendingThreads(NULL)
{}


DMThreadList::~DMThreadList()
{
	SAFE_DELETE(m_activeThreads);
	SAFE_DELETE(m_pendingThreads);
}


/**
 * Records that a thread wants to start.  If we are below the current thread
 * limit, then we record it as an active thread and return true, otherwise we
 * put it in the pending list and waitForAll() will be start it when one of the
 * active threads finishes.
 */
bool DMThreadList::threadStart(DMThread *t)
{
	if(m_activeThreads->size() < m_threadLimit) {
		debug0("%p: Thread %p allowed to start - #active was %d",
			this, t, m_activeThreads->size());
		m_activeThreads->add(t);
		return true;
	}

	if(!m_pendingThreads) {
		m_pendingThreads = new List<DMThread>();
	}
	debug0("%p: Thread %p queued - #active was %d, #pending was %d",
		this, t, m_activeThreads->size(), m_pendingThreads->size());
	m_pendingThreads->add(t);
	return false;
}


/**
 * Waits for one of the active threads to finish, removes it from the active
 * list and returns it to the caller.  Windows allows us to wait for multiple
 * threads without blocking and detect when one of them exits.  On Linux we
 * have a version of pthread_join with a timeout which we can use to find
 * threads that have exited.  On other flavours of Unix we use a dumb algorithm
 * that waits for just the first active thead to exit and return that - this
 * will result in some gaps where we could have started a thread, but didn't.
 */
DMThread* DMThreadList::waitForOne()
{
	if(m_activeThreads->size() > 0) {
#ifdef WIN32
		AutoPtr<HANDLE> handles = (HANDLE*) malloc(m_activeThreads->size() * sizeof(HANDLE));
		int count = 0;

		ListIterator<DMThread> iter(*m_activeThreads);
		for(DMThread *t = iter.first(); t; t = iter.next()) {
			debug0("waitForOne adding thread %p id %x", t, t->id());
			handles[count] = t->id();
			count++;
		}

		// Wait indefinitely for one of the list of active threads to exit
		DWORD res = WaitForMultipleObjects(count, handles, FALSE, INFINITE);
		if((res >= WAIT_OBJECT_0) && (res < (WAIT_OBJECT_0 + count))) {
			// Success - find the thread object matching the handle at the given index
			int index = res - WAIT_OBJECT_0;
			HANDLE handle = handles[index];
			for(DMThread *t = iter.first(); t; t = iter.next()) {
				if(t->id() == handle) {
					debug0("%p: Thread %p id %x has exited - found and removed", this, t, t->id());
					m_activeThreads->remove(t);
					return t;
				}
			}

			debug0("%p: Thread id %x has exited - not found in list!", this, (int) handle);
			return NULL;
		}

		debug0("%p: Wait returned %ld", this, res);
		return NULL;
#else
#if defined(__LINUX__) || defined(__linux__)
		// Linux-specific version - use non-blocking join
		ListIterator<DMThread> active(*m_activeThreads);
		while(true) {
			for(DMThread *t = active.first(); t; t = active.next()) {
				int n = t->waitForWithTimeout();
				if(n > 0) {
					// Thread exited within timeout
					debug0("%p: Thread %p id %x has exited - removed", this, t, t->id());
					m_activeThreads->remove(t);
					return t;
				} else if(n < 0) {
					// An error occurred
					return NULL;
				}
			}
		}
#else
		// Dumb version - wait for the first thread to exit and return it
		ListIterator<DMThread> active(*m_activeThreads);
		DMThread *t = active.first();
		debug0("%p: Waiting for thread %p id %x", this, t, t->id());
		t->waitFor();
		debug0("%p: Thread %p id %x has exited - removed", this, t, t->id());
		m_activeThreads->remove(t);
		return t;
#endif /*Linux*/
#endif /*WIN32*/
	}

	return NULL;
}

/**
 * Returns a count of the number of threads with non-zero exit codes, or throws
 * an exception if any of the threads raises an exception.
 */
int DMThreadList::waitForAll()
{
	if(m_pendingThreads) {
		// Still some threads to start - start a new thread when an active one finishes
		debug0("%p: Starting pending threads", this);
		for(DMThread *tfinish = waitForOne(); (m_pendingThreads->size() > 0) && tfinish; tfinish = waitForOne()) {
			ListIterator<DMThread> pending(*m_pendingThreads);
			DMThread *tstart = pending.first();
			m_pendingThreads->remove(tstart);
			debug0("%p: Starting pending thread %p - #pending now %d, #active was %d",
				this, tstart, m_pendingThreads->size(), m_activeThreads->size());
			tstart->start();	// This will call us back to add it to the active list
		}

		debug0("%p: All pending threads started - resume normal waitForAll", this);
	}

	// Wait for all threads in the list to finish
	ListIterator<DMThread> iter(*this);
	for(DMThread *t = iter.first(); t; t = iter.next()) {
		debug0("%p: Waiting for thread %p id %x", this, t, t->id());
		t->waitFor();
		m_activeThreads->remove(t);
	}

	debug0("%p: All threads have finished - #active is %d", this, m_activeThreads->size());

	// Now look for any exceptions raised by the threads and rethrow
	DMException *ex = NULL;
	int count = 0;

	for(DMThread *t = iter.first(); t; t = iter.next()) {
		if(t->exitCode() != 0) {
			count++;
		}
		if(t->exception()) {
			if(!ex) {
				ex = t->exception();
			} else {
				// more than one exception raised
			}
		}
	}

	// rethrow the first caught exception
	if(ex) {
		/*ex->rethrow();*/
		throw *ex;
	}

	return count;
}
