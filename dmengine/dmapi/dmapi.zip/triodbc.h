#ifndef _TRIODBC_H

#define _TRIODBC_H

#ifdef HAVE_DMAPIEXPORT
#include "dmapiexport.h"
#else
// Neither export nor import the classes
#define DMAPI_API
#endif /*HAVE_DMAPIEXPORT*/

#ifdef WIN32
#include <windows.h>
#include <windef.h>
#include <sql.h>
#include <sqlext.h>
#include <sqltypes.h>
#ifndef _WIN64
#define SQLLEN SQLINTEGER
#endif /*_WIN64*/
#else
#include "sql.h"
#include "sqlext.h"
#include "sqltypes.h"
#endif
#ifdef THIS_IS_NOT_DEFINED
#  if defined(__sun)
     typedef int bool;
#    define true 1
#    define false 0
#  endif
#endif


// For convenience - RHT 19/12/2013
#define IS_SQL_SUCCESS(x)		((x == SQL_SUCCESS) || (x == SQL_SUCCESS_WITH_INFO))
#define IS_NOT_SQL_SUCCESS(x)	((x != SQL_SUCCESS) && (x != SQL_SUCCESS_WITH_INFO))


class COLDATA {
public:
	char			*ColumnName;
	SQLSMALLINT		BindType;
	SQLINTEGER		ColumnSize;
	SQLLEN			NullInd;		// RHT 07/08/2012 - was SQLINTEGER
	void			*DataPtr;
	class COLDATA	*next;

	COLDATA(const SQLCHAR *colName);
	~COLDATA();

	void allocDataPtr();
};

typedef struct tabdata_t{
char				*TableName;
char				*TableType;
struct tabdata_t	*next;
} TABLEDATA;

typedef struct charcols_t{
char				*DataPtr;
SQLINTEGER			DataLength;
struct charcols_t	*next;
} CHARCOLS;


// RHT 14/05/2011 - Database type
typedef enum db_type_tag{
DATABASE_TYPE_UNKNOWN=0,
DATABASE_TYPE_ORACLE=10,
DATABASE_TYPE_SQLSERVER=20
} DATABASE_TYPE;


class DMAPI_API triSQL
{
	friend class triODBC;

private:
	SQLHSTMT	m_StatHandle;
	SQLHDBC		m_ConnHandle;
	bool		m_StatHandleSet;
	CHARCOLS	*CharCols;
	CHARCOLS	*xCol;

	long		AllocateStatementHandle(SQLHDBC ConnHandle);
	long		FreeStatementHandle();
	void		CloseAnyOpenHandles();
	unsigned long	m_RowArraySize;
	unsigned long	m_NumRowsFetched;
	SQLLEN		*m_IndicatorArray;
	SQLLEN		m_SingleIndicator;

	triSQL();
	triSQL(triSQL &rhs);

public:
	~triSQL();

	long BindColumn(SQLUSMALLINT,SQLSMALLINT,SQLPOINTER,SQLINTEGER,SQLLEN *ni=NULL);	// RHT 07/08/2012 - was SQLINTEGER
	SQLRETURN BindParameter(SQLUSMALLINT,SQLSMALLINT,SQLUINTEGER,SQLPOINTER,SQLINTEGER);
	SQLRETURN Execute();
	SQLRETURN ExecuteIgnoringErrors();
	SQLRETURN /*long*/ ExecuteSQL(const char *,...);
	SQLRETURN /*long*/ ExecuteSQLIgnoringErrors(const char *,...);
	SQLRETURN PrepareStatement(const char *SQLformat, ...);
	SQLRETURN ParamData();
	SQLRETURN PutData(SQLPOINTER TargetValue,SQLLEN DataLength);
	SQLRETURN GetData(SQLUSMALLINT ColumnNumber,SQLSMALLINT	TargetType,SQLPOINTER TargetValuePtr,SQLLEN DataLength, SQLLEN *ni);	// RHT 04/12/2013
	void SetArraySize(long nRows);
	long GetRowsReturned();
	long GetRowCount();
	SQLRETURN /*long*/ FetchRow();
	// long FetchMultipleRows(unsigned long *RowCount);
	void GetLastError(char **MsgPtr,SQLINTEGER *ErrNum);
	long CloseSQL();
	COLDATA *GetColumnInfo(unsigned char *TableName);
	TABLEDATA *GetTableInfo(unsigned char *TableName);
	COLDATA *GetColumnInfoForStatement();
	SQLRETURN SetAutoCommitMode(bool autoCommit);
	SQLRETURN EndTransaction(bool commit);
	static char *EscapeLiteral(const char *str);
};


class DMAPI_API triODBC
{
private:
	SQLHENV		m_EnvHandle;
	SQLHDBC		m_ConnHandle;
	triSQL		m_triSQL;
	bool		m_EnvHandleSet;
	bool		m_ConnHandleSet;

	long		AllocateAndSetEnvironmentHandle();
	long		AllocateConnectionHandle();
	long		FreeEnvironmentHandle();
	long		FreeConnectionHandle();

public:

	long ConnectToDataSource(char *PathName);
	long ConnectToDataSource(char *DSN,char *Username,char *Password);
	long DisconnectFromDataSource();
	void GetLastError(char **MsgPtr,SQLINTEGER *ErrNum);
	
	triODBC();
	~triODBC();

	triSQL *GetSQL();

	DATABASE_TYPE GetDatabaseType();
};

#endif /*_TRIODBC_H*/
