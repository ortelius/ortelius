#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>

#include "model.h"
//#include "db.h"
#include "triodbc.h"
#include "scopestack.h"
#include "repository.h"
#include "exceptions.h"
#include "dropzone.h"
#include "context.h"
#include "notify.h"
#include "node.h"
#include "datasource.h"
#include "dm.h"
#include "properties.h"
#include "crypto.h"
#include "autoptr.h"
#include "lexer.h"
#include "expr.h"
#include "charptr.h"
#include "credentials.h"
#include "pathname.h"
//#include "thread.h"		// for Thread::currentThreadId()
#include "rewrap.h"
#include "audit.h"
#include "scriptgen.h"
#include "engineconfig.h"
#include "task.h"
#include "envp.h"


extern int yyparse(void *buffer);


///////////////////////////////////////////////////////////////////////////////
// SimplePermission
///////////////////////////////////////////////////////////////////////////////

typedef enum tagSimplePermission {
	UNSET,
	ALLOW,
	DENY
} SimplePermission;


///////////////////////////////////////////////////////////////////////////////
// ObjectAccess
///////////////////////////////////////////////////////////////////////////////

class ObjectAccess
{
private:
	SimplePermission m_readAccess;
	SimplePermission m_writeAccess;

	static SimplePermission fromString(const char *str);
	static SimplePermission combine(SimplePermission obj, const char *str);

	void addObjectAccess(const char *read, const char *write);
	void addDomainAccess(const char *read, const char *write);

public:
	ObjectAccess();

	bool isReadable()   { return (m_readAccess  == ALLOW); }
	bool isWriteable()  { return (m_writeAccess == ALLOW); }

	friend class Model;
};


ObjectAccess::ObjectAccess()
	: m_readAccess(UNSET), m_writeAccess(UNSET)
{}


void ObjectAccess::addObjectAccess(const char *read, const char *write)
{
	m_readAccess  = fromString(read);
	m_writeAccess = fromString(write);
}


void ObjectAccess::addDomainAccess(const char *read, const char *write)
{
	m_readAccess  = combine(m_readAccess,  read);
	m_writeAccess = combine(m_writeAccess, write);
}


/*static*/ SimplePermission ObjectAccess::fromString(const char *str)
{
	return (str != NULL) ? ((str[0] == 'Y') ? ALLOW : DENY) : UNSET;
}


/*static*/ SimplePermission ObjectAccess::combine(SimplePermission obj, const char *str)
{
	switch(fromString(str)) {
	case ALLOW: return ((obj == UNSET) ? ALLOW : obj);
	case DENY:  return ((obj == UNSET) ? DENY : obj);
	default:    return obj;
	}
}


///////////////////////////////////////////////////////////////////////////////
// Object
///////////////////////////////////////////////////////////////////////////////


Object::Object(Model &model, int id, const char *name)
	: m_model(model), m_id(id), m_name(DUP_NULL(name)), m_ownerSet(false),
	  m_owner(NULL), m_owngrp(NULL), m_domainSet(false), m_domain(NULL),
	  m_summary(NULL), m_notes(NULL), m_vars(NULL), m_access(NULL),
	  m_cacheFQDomain(NULL), m_cacheFQName(NULL)
{}


/*virtual*/ Object::~Object()
{
	SAFE_FREE(m_name);
	m_owner  = NULL;		// Don't own
	m_owngrp = NULL;		// Don't own
	m_domain = NULL;		// Don't own
	SAFE_FREE(m_summary);
	SAFE_FREE(m_notes);
	SAFE_DELETE(m_vars);
	SAFE_DELETE(m_access);
	SAFE_FREE(m_cacheFQDomain);
	SAFE_FREE(m_cacheFQName);
}


Object *Object::getOwner()
{
	if(!m_ownerSet) {
		m_ownerSet = true;
		m_model.getOwnerForObject(*this);
	}

	return m_owner ? (Object*) m_owner : (Object*) m_owngrp;
}


void Object::setOwner(User *owner)
{
	m_ownerSet = true;
	m_owner    = owner;
}


void Object::setOwner(UserGroup *owngrp)
{
	m_ownerSet = true;
	m_owngrp   = owngrp;
}


//void Object::addAccess(UserGroup &usrgrp, ObjectAccess *oa)
//{
//	if(!m_access) {
//		m_access = new HashtableById<ObjectAccess>(true);
//	}
//	m_access->put(usrgrp.id(), oa);
//}


bool Object::internalHasDomainAccess(User *user)
{
	if(!m_domainSet) {
		getDomain();
	}
	// Only domains don't have to have a parent domain
	if(!m_domain && (kind() != OBJ_KIND_DOMAIN)) {
		debug0("Domain for object with id %d and kind %d not set", id(), kind());
		return false;
	}
	if(m_domain) {
		// Is the user's domain above the level of the object we are accessing?
		Domain *userdom = user->getDomain();
		if(!userdom) {
			debug1("user's domain NOT found - disallow access");
			return false;
		}
		Domain *dom;
		// THIS IS WRONG
		// Loop through all the parent domains of the user
		//for(; userdom; userdom = userdom->getDomain()) {
		//	// Loop through all the parent domains of the object
		//	for(dom = m_domain; dom; dom = dom->getDomain()) {
		//		debug3("Checking '%s'", dom->name());
		//		if(userdom == dom) {
		//			debug3("user's domain found");
		//			break;
		//		}
		//	}
		//}
		// END THIS IS WRONG

		// First check if the User's domain one of the parent domains of the object
		for(dom = m_domain; dom; dom = dom->getDomain()) {
			debug3("Checking '%s'", dom->name());
			if(userdom == dom) {
				debug3("user's domain found");
				break;
			}
		}
		if(!dom) {
			// No, so now check if the object's domain is one of the parent domains of the User
			for(dom = userdom; dom; dom = dom->getDomain()) {
				debug3("Checking '%s'", dom->name());
				if(m_domain == dom) {
					debug3("object's domain found");
					break;
				}
			}
		}
		if(!dom) {
			debug0("user's domain '%s' cannot see object in domain '%s' - disallow access",
				userdom->getFQName(), m_domain->getFQName());
			return false;
		}

		//// Check that the parent domain allows access
		//if(!m_domain->hasAccess(user)) {
		//	// No access to parent domain - disallow access
		//	return false;
		//}
	}

	return true;
}


bool Object::hasAccess(User *user)
{
	// If user is not supplied, then we check the current user
	if(!user) {
		user = m_model.getCurrentUser();
	}
	if(!user) {
		// Failed to get current user - disallow access
		return false;
	}

	if(!internalHasDomainAccess(user)) {
		return false;
	}

	// Now check our ACL
	if(!m_access) {
		m_access = m_model.getAccessForObject(*this);
	}

	//// If ACL is empty, then default is to allow access
	//if(m_access->count() == 0) {
	//	return true;
	//}

	List<UserGroup> *groups = user->getUserGroups();
	if(!groups) {
		return false;
	}

	ListIterator<UserGroup> iter(*groups);
	for(UserGroup *grp = iter.first(); grp; grp = iter.next()) {
		ObjectAccess *access = m_access->get(grp->id());
		if(access && (access->isReadable() || access->isWriteable())) {
			// ACL contains a group that the user is a member of
			return true;
		}
	}

	return false;
}


bool Object::hasReadAccess(User *user)
{
	// If user is not supplied, then we check the current user
	if(!user) {
		user = m_model.getCurrentUser();
	}
	if(!user) {
		// Failed to get current user - disallow access
		return false;
	}

	if(!internalHasDomainAccess(user)) {
		return false;
	}

	// Now check our ACL
	if(!m_access) {
		m_access = m_model.getAccessForObject(*this);
	}

	//// If ACL is empty, then default is to allow access
	//if(m_access->count() == 0) {
	//	return true;
	//}

	List<UserGroup> *groups = user->getUserGroups();
	if(!groups) {
		return false;
	}

	ListIterator<UserGroup> iter(*groups);
	for(UserGroup *grp = iter.first(); grp; grp = iter.next()) {
		ObjectAccess *access = m_access->get(grp->id());
		if(access && access->isReadable()) {
			// ACL contains a group with read access that the user is a member of
			return true;
		}
	}

	return false;
}


bool Object::hasWriteAccess(User *user)
{
	// If user is not supplied, then we check the current user
	if(!user) {
		user = m_model.getCurrentUser();
	}
	if(!user) {
		// Failed to get current user - disallow access
		return false;
	}

	if(!internalHasDomainAccess(user)) {
		return false;
	}

	// Now check our ACL
	if(!m_access) {
		m_access = m_model.getAccessForObject(*this);
	}

	//// If ACL is empty, then default is to disallow access - this is different from read access
	//if(m_access->count() == 0) {
	//	return false;
	//}

	List<UserGroup> *groups = user->getUserGroups();
	if(!groups) {
		return false;
	}

	ListIterator<UserGroup> iter(*groups);
	for(UserGroup *grp = iter.first(); grp; grp = iter.next()) {
		ObjectAccess *access = m_access->get(grp->id());
		if(access && access->isWriteable()) {
			// ACL contains a group with read access that the user is a member of
			return true;
		}
	}

	return false;
}


Domain *Object::getDomain()
{
	if(!m_domainSet) {
		m_domainSet = true;
		m_model.getDomainForObject(*this);
	}
	return m_domain;
}


void Object::setDomain(Domain *domain)
{
	m_domainSet = true;
	m_domain    = domain;
}


const char *Object::getFQDomain()
{
	if(m_cacheFQDomain) {
		return m_cacheFQDomain;
	}

	Domain *domain = getDomain();
	if(!domain) {
		return NULL;
	}

	const char *mydom = domain->name();
	const char *fqdom = domain->getFQDomain();

	if(!fqdom) {
		m_cacheFQDomain = strdup(mydom);
	} else {
		m_cacheFQDomain = (char*) malloc(strlen(fqdom) + strlen(mydom) + 2);
		sprintf(m_cacheFQDomain, "%s.%s", fqdom, mydom);
	}

	return m_cacheFQDomain;
}


const char *Object::getFQName()
{
	if(m_cacheFQName) {
		return m_cacheFQName;
	}

	const char *fqdom = getFQDomain();

	if(!fqdom) {
		m_cacheFQName = strdup(m_name);
	} else {
		m_cacheFQName = (char*) malloc(strlen(fqdom) + strlen(m_name) + 2);
		sprintf(m_cacheFQName, "%s.%s", fqdom, m_name);
	}

	return m_cacheFQName;
}


const char *Object::getSummary()
{
	if(m_summary) {
		return m_summary;
	}
	m_model.getSummaryForObject(*this);
	return m_summary;
}


void Object::setSummary(const char *summary)
{
	SAFE_FREE(m_summary);
	m_summary = strdup(summary ? summary : "");
}


const char *Object::getNotes()
{
	if(m_notes) {
		return m_notes;
	}
	m_model.getNotesForObject(*this);
	return m_notes;
}


void Object::setNotes(const char *notes)
{
	SAFE_FREE(m_notes);
	m_notes = strdup(notes ? notes : "");
}


void Object::indent(int indent)
{
	for(int n = 0; n < indent; n++) {
		printf("  ");
	}
}


void Object::printObject(int ind)
{
	if(m_access) {
		indent(ind); printf("Access: ");
		AutoPtr<IntList> keys = m_access->keys();
		IntListIterator iter(*keys);
		bool first = true;
		for(int g = iter.first(); iter.more(); g = iter.next()) {
			ObjectAccess *a = m_access->get(g);
			printf("%s%d(%c%c)", (first ? "" : ", "), g,
				(a->isReadable() ? 'r' : '-'), (a->isWriteable() ? 'w' : '-'));
			first = false;
		}
		printf("\n");
	}
	if(m_ownerSet) {
		indent(ind);
		if(m_owner) {
			printf("Owner:\n");
			m_owner->print(ind+1);
		} else if(m_owngrp) {
			printf("Owner:\n");
			m_owngrp->print(ind+1);
		} else {
			printf("Owner: (no owner)\n");
		}
	}
}


/*virtual*/ Expr *Object::getAttribute(const char *name, class Context &ctx)
{
	if(strcmp(name, "id") == 0) {
		return new Expr(m_id);
	} else if(strcmp(name, "name") == 0) {
		return new Expr(m_name);
	} else if(strcmp(name, "fqdomain") == 0) {
		const char *fqd = getFQDomain();
		return fqd ? new Expr(fqd) : NULL;
	} else if(strcmp(name, "summary") == 0) {
		const char *summary = getSummary();
		return summary ? new Expr(summary) : NULL;
	}else if(strcmp(name, "owner") == 0) {
		IObject *owner = getOwner();
		return owner ? new Expr(owner) : NULL;
	}else if(strcmp(name, "domain") == 0) {
		Domain *domain = getDomain();
		return domain ? new Expr(domain) : NULL;
	}
	return NULL;
}


///*virtual*/ class DMArray *Object::getArrayAttribute(const char *name, class Context &ctx)
//{
//	return NULL;
//}


///*virtual*/ IObject *Object::getObjectAttribute(const char *name, class Context &ctx)
//{
//	if(strcmp(name, "owner") == 0) {
//		return getOwner();
//	}
//	if(strcmp(name, "parent") == 0) {
//		return getDomain();
//	}
//	return NULL;
//}


/*virtual*/ Scope *Object::getVars()
{
	return NULL;
}


///////////////////////////////////////////////////////////////////////////////
// ObjectKindAndId
///////////////////////////////////////////////////////////////////////////////

typedef struct tagObjectKindLookup {
	const char *str;
	OBJECT_KIND kind;
} ObjectKindLookup;

ObjectKindLookup objectKindLookupTable[] = {
	{ "en", OBJ_KIND_ENVIRONMENT },
	{ "do", OBJ_KIND_DOMAIN },
	{ "se", OBJ_KIND_SERVER },
	{ "ap", OBJ_KIND_APPLICATION },
	{ "us", OBJ_KIND_USER },
	{ "gr", OBJ_KIND_USERGROUP },
	{ "re", OBJ_KIND_RESPOSITORY },
	{ "no", OBJ_KIND_NOTIFY },
	{ "ds", OBJ_KIND_DATASOURCE },
	{ "ac", OBJ_KIND_ACTION },
	//OBJ_KIND_DROPZONE
	{ "co", OBJ_KIND_COMPONENT },
	{ "ci", OBJ_KIND_COMPONENTITEM },
	//OBJ_KIND_DROPZONEFILE
	{ "xf", OBJ_KIND_TRANSFER },
	//OBJ_KIND_APPVERSION
	{ NULL, OBJ_KIND_NONE }
};

OBJECT_KIND ObjectKindFromTypeString(const char *str)
{
	for(ObjectKindLookup *ok = objectKindLookupTable; ok && ok->str; ok++) {
		if(strcmp(str, ok->str) == 0) {
			return ok->kind;
		}
	}
	return OBJ_KIND_NONE;
}

const char *ObjectKindToTypeString(OBJECT_KIND val)
{
	for(ObjectKindLookup *ok = objectKindLookupTable; ok && ok->str; ok++) {
		if(val == ok->kind) {
			return ok->str;
		}
	}
	return NULL;
}

ObjectKindAndId::ObjectKindAndId(const char *otid)
{
	if(!otid || (strlen(otid) < 3)) {
		throw RuntimeError("Invalid OTID: '%s'", NULL_CHECK(otid));
	}
	char ot[3];
	sprintf(ot, "%c%c", otid[0], otid[1]);
	const char *oid = &otid[2];
	m_objkind = ObjectKindFromTypeString(ot);

	if(m_objkind == OBJ_KIND_NONE) {
		throw RuntimeError("Invalid Object Type: '%s'", ot);
	}
	
	m_id = atoi(oid);
	if(m_id == 0) {
		throw RuntimeError("Invalid Object Id: '%s'", oid);
	}
}


ObjectKindAndId::ObjectKindAndId(OBJECT_KIND objkind, int id)
	: m_objkind(objkind), m_id(id)
{}


ObjectKindAndId::ObjectKindAndId(Object &obj)
	: m_objkind(obj.kind()), m_id(obj.id())
{}

	
char *ObjectKindAndId::toString()
{
	const char *ot = ObjectKindToTypeString(m_objkind);
	if(!ot) {
		throw RuntimeError("Invalid Object Type: %d", m_objkind);
	}

	char buf[34];
	sprintf(buf, "%s%d", ot, m_id);
	return strdup(buf);
}


///////////////////////////////////////////////////////////////////////////////
// ProviderObject
///////////////////////////////////////////////////////////////////////////////

ProviderObject::ProviderObject(Model &model, int id, const char *name)
	: Object(model, id, name), m_credentials(NULL),		////, m_type(DUP_NULL(type))
	  m_props(NULL), m_def(NULL)
{}


/*virtual*/ ProviderObject::~ProviderObject()
{
	SAFE_DELETE(m_props);
	m_credentials = NULL;	// Owned by cache
	m_def = NULL;			// Owned by cache
}


/*virtual*/ Expr *ProviderObject::getAttribute(const char *name, class Context &ctx)
{
	if(strcmp(name, "type") == 0) {
		return new Expr(getDef(ctx).name());
	}

	// TODO: This gives direct access to properties, even if the impl doesn't
	// expose them - this may be useful, but it is also a bit of a security
	// hole - comment out for the time being until we decide if it is useful
	Expr *ret = Object::getAttribute(name, ctx);
	////if(!ret) {
	////	Property *prop = getProperty(name);
	////	ret = prop ? prop->value() : NULL;
	////}

	return ret;
}


Credentials *ProviderObject::getCredentials()
{
	if(!m_credentials) {
		m_model.getCredentialsForProviderObject(*this);
	}

	return m_credentials;
}


void ProviderObject::setCredentials(Credentials *creds)
{
	m_credentials = creds;
}


ProviderObjectDef &ProviderObject::getDef(Context &ctx)
{
	if(!m_def) {
		m_def = m_model.getDefForProviderObject(*this);
	}
	if(!m_def) {
		throw RuntimeError(ctx.stack(), "No definition for %s '%s'", def_kind(), name());
	}

	return *m_def;
}


Property *ProviderObject::getProperty(const char *name)
{
	return m_props ? m_props->get(name) : NULL;
}


void ProviderObject::setProperty(Property *prop)
{
	if(!m_props) {
		m_props = new Hashtable<Property>(false, true);
	}
	m_props->put(prop->name(), prop);
}


Property *ProviderObject::getDefProperty(const char *name)
{
	if(!m_def) {
		throw RuntimeError("Provider object definition not yet resolved for provider '%s'", m_name);
	}
	return m_def->getDefProperty(name);
}


void ProviderObject::setDefProperty(Property *prop)
{
	if(!m_def) {
		throw RuntimeError("Provider object definition not yet resolved for provider '%s'", m_name);
	}
	m_def->setDefProperty(prop);
}


void ProviderObject::printProviderObject(int ind)
{
	indent(ind); printf("Type: %s\n", (m_def ? m_def->name() : "*no def*"));
	printObject(ind);
	if(m_props) {
		indent(ind); printf("Properties:\n");
		AutoPtr<StringList> keys = m_props->keys();
		StringListIterator iter(*keys);
		for(const char *name = iter.first(); name; name = iter.next()) {
			Property *prop =  m_props->get(name);
			indent(ind+1); printf("%s: %s\n", name, (prop ? prop->value() : "(null)"));
		}
	}
}


///////////////////////////////////////////////////////////////////////////////
// ProviderObjectDef
///////////////////////////////////////////////////////////////////////////////

ProviderObjectDef::ProviderObjectDef(
		int id, const char *name, const char *kind, Plugin *plugin
	)
	: m_id(id), m_name(DUP_NULL(name)),
	  m_plugin(plugin), m_kind(DUP_NULL(kind)),
	  m_defprops(NULL), m_propdefs(NULL), m_checker(NULL)
{}


ProviderObjectDef::~ProviderObjectDef()
{
	SAFE_FREE(m_name);
	SAFE_FREE(m_kind);
	SAFE_DELETE(m_defprops);
	SAFE_DELETE(m_propdefs);
	SAFE_DELETE(m_checker);
	m_plugin = NULL;	// Owned by cache
}


List<PropertyDef> *ProviderObjectDef::getPropertyDefs()
{
	if(!m_propdefs) {
		m_propdefs = new List<PropertyDef>(true);
		//	m_model.getProperyDefsForProviderObject(*this); - might do it this way at some point
	}
	return m_propdefs;
}


void ProviderObjectDef::add(class PropertyDef *propdef)
{
	if(!m_propdefs) {
		m_propdefs = new List<PropertyDef>(true);
	}
	m_propdefs->add(propdef);
}


Plugin *ProviderObjectDef::getPlugin()
{
	// might do lazy load at some point
	//if(!m_plugin) {
	//	m_model.getPluginForProviderObjectDef(*this);
	//}
	return m_plugin;
}


void ProviderObjectDef::createChecker()
{
	char *temp = (char*) malloc(strlen(m_name) + strlen(m_kind) + 2);
	sprintf(temp, "%s %s", m_name, m_kind);
	m_checker = new PropertyChecker(m_propdefs, temp);
	free(temp);
}


void ProviderObjectDef::verifyProperties(class Context &ctx, Hashtable<class Property> *props)
{
	if(!m_checker) {
		createChecker();
	}
	m_checker->checkProps(ctx, props);
}

void ProviderObjectDef::verifyArgs(class Context &ctx, class StmtList *args, Hashtable<class Property> *props)
{
	if(!m_checker) {
		createChecker();
	}
	m_checker->checkArgs(ctx, args, props);
}


Property *ProviderObjectDef::getDefProperty(const char *name)
{
	return m_defprops ? m_defprops->get(name) : NULL;
}


void ProviderObjectDef::setDefProperty(Property *prop)
{
	if(!m_defprops) {
		m_defprops = new Hashtable<Property>(false, true);
	}
	m_defprops->put(prop->name(), prop);
}


///////////////////////////////////////////////////////////////////////////////
// ProviderObjectImpl
///////////////////////////////////////////////////////////////////////////////

ProviderObjectImpl::ProviderObjectImpl(DMINT32 implId, ProviderObject &prov)
	: m_implId(implId), m_provider(prov), m_vars(NULL)
{}


/*virtual*/ ProviderObjectImpl::~ProviderObjectImpl()
{
	SAFE_DELETE(m_vars);
}


Scope *ProviderObjectImpl::getVars()
{
	if(!m_vars) {
		m_vars = new DelegatingScope(*(m_provider.getVars()), this);
		m_vars->addRef();
	}
	return m_vars;
}


/*virtual*/ Expr *ProviderObjectImpl::getAttribute(
	const char *name, Context &ctx)
{
	return m_provider.getAttribute(name, ctx);
}


///////////////////////////////////////////////////////////////////////////////
// Credentials
///////////////////////////////////////////////////////////////////////////////

Credentials::Credentials(CREDENTIALS_KIND kind)
	: m_id(0), m_name(NULL), m_kind(kind), m_encusername(NULL),
	  m_encpassword(NULL), m_filename(NULL), m_impls(NULL)
{}


Credentials::Credentials(
		int id, const char *name, CREDENTIALS_KIND kind,
		const char *encusername, const char *encpassword
	)
	: m_id(id), m_name(DUP_NULL(name)), m_kind(kind),
	  m_encusername(DUP_NULL(encusername)), m_encpassword(DUP_NULL(encpassword)),
	  m_filename(NULL), m_impls(NULL)
{}


Credentials::Credentials(
		int id, const char *name, CREDENTIALS_KIND kind, const char *filename
	)
	: m_id(id), m_name(DUP_NULL(name)), m_kind(kind), m_encusername(NULL),
	  m_encpassword(NULL), m_filename(DUP_NULL(filename)), m_impls(NULL)
{}


Credentials::Credentials(Property *username, Property *password)
	: m_id(0), m_name(strdup("From Properties")), m_kind(CREDENTIALS_ENCRYPTED),
	  m_encusername(NULL), m_encpassword(NULL), m_filename(NULL), m_impls(NULL)
{
	if(username) {
		if(username->m_encrypted) {
			m_encusername = strdup(username->m_value);
		} else {
			m_encusername = encryptValue(username->m_value, strlen(username->m_value));
		}
	}
	if(password) {
		if(password->m_encrypted) {
			m_encpassword = strdup(password->m_value);
		} else {
			m_encpassword = encryptValue(password->m_value, strlen(password->m_value));
		}
	}
}


Credentials::~Credentials()
{
	SAFE_FREE(m_name);
	SAFE_FREE(m_encusername);
	SAFE_FREE(m_encpassword);
	SAFE_FREE(m_filename);
	SAFE_DELETE(m_impls);
}


char *Credentials::internalDecryptValue(const char *value, class Object &auth, Context &ctx)
{
	if(!auth.hasAccess(NULL)) {
		throw PermissionDeniedException(ctx.stack(), "You do not have permisson to credentials");
	}

	if(!value) {
		throw RuntimeError(ctx.stack(), "Credentials value was not set - unable to decrypt");
	}

	return decryptValue(value, strlen(value));
}


char *Credentials::getDecryptedUsername(class Object &auth, class Context &ctx)
{
	switch(m_kind) {
	case CREDENTIALS_ENCRYPTED:
	case CREDENTIALS_IN_DATABASE:
		return internalDecryptValue(m_encusername, auth, ctx);
	case CREDENTIALS_FROM_VARS: {
		Node uservar(NODE_STR, strdup(m_encusername), true);
		ExprPtr euser = uservar.evaluate(ctx);
		return (euser ? euser->toString() : NULL);
		}
	}

	return NULL;
}


char *Credentials::getDecryptedPassword(class Object &auth, class Context &ctx)
{
	switch(m_kind) {
	case CREDENTIALS_ENCRYPTED:
	case CREDENTIALS_IN_DATABASE:
		return internalDecryptValue(m_encpassword, auth, ctx);
	case CREDENTIALS_FROM_VARS: {
		Node passvar(NODE_STR, strdup(m_encpassword), true);
		ExprPtr epass = passvar.evaluate(ctx);
		return (epass ? epass->toString() : NULL);
		}
	}

	return NULL;
}


bool Credentials::hasUsername()
{
	switch(m_kind) {
	case CREDENTIALS_ENCRYPTED:
	case CREDENTIALS_IN_DATABASE:
	case CREDENTIALS_FROM_VARS:
		return (m_encusername ? true : false);
	case CREDENTIALS_RTI3_DFO_IN_FILESYSTEM:
	case CREDENTIALS_HARVEST_DFO_IN_FILESYSTEM:
		return true;
	default:
		return false;
	}
}


bool Credentials::hasPassword()
{
	switch(m_kind) {
	case CREDENTIALS_ENCRYPTED:
	case CREDENTIALS_IN_DATABASE:
	case CREDENTIALS_FROM_VARS:
		return (m_encpassword ? true : false);
	case CREDENTIALS_RTI3_DFO_IN_FILESYSTEM:
	case CREDENTIALS_HARVEST_DFO_IN_FILESYSTEM:
		return true;
	default:
		return false;
	}
}


CredentialsProvider *Credentials::createImpl(const char *provider, Context &ctx)
{
	CredentialsProviderFactory *factory =
		CredentialsProviderRegistry::instance().getFactory(provider);

	if(!factory) {
		throw RuntimeError(ctx.stack(), "Unrecognised credentials provider type '%s'", provider);
	}

	// Create an instance of the impl so that we may later execute it
	CredentialsProvider *impl = factory->create(*this);
	if(!impl) {
		throw RuntimeError(ctx.stack(), "Unexpected error creating instance of credentials provider type '%s'", provider);
	}

	if(!m_impls) {
		m_impls = new Hashtable<CredentialsProvider>(false, true);
	}
	m_impls->put(provider, impl);
	return impl;
}


bool Credentials::canTransform(const char *provider, Context &ctx)
{
	CredentialsProvider *impl = m_impls ? m_impls->get(provider) : NULL;
	if(!impl) {
		impl = createImpl(provider, ctx);
	}

	return impl->canTransform();
}


const char *Credentials::transform(const char *provider, Object &auth, Context &ctx)
{
	CredentialsProvider *impl = m_impls ? m_impls->get(provider) : NULL;
	if(!impl) {
		impl = createImpl(provider, ctx);
	}

	return impl->transform(auth, ctx);
}


void Credentials::print(int indent)
{
	switch(m_kind) {
	case CREDENTIALS_USE_DIALOG:				printf("Use dialog"); break;
	case CREDENTIALS_ENCRYPTED:					printf("Encrypted"); break;
	case CREDENTIALS_IN_DATABASE:				printf("In database"); break;
	case CREDENTIALS_RTI3_DFO_IN_FILESYSTEM:	printf("RTI DFO"); break;
	case CREDENTIALS_HARVEST_DFO_IN_FILESYSTEM: printf("Harvest DFO"); break;
	default: printf("Unknown"); break;
	}
}


///////////////////////////////////////////////////////////////////////////////
// Environment
///////////////////////////////////////////////////////////////////////////////


Environment::Environment(
		Model &model, int id, const char *name, const char *basedir
	)
	: Object(model, id, name), m_basedir(DUP_NULL(basedir)), m_servers(NULL),
	  m_apps(NULL), /*m_domain(NULL), m_domainSet(false),*/
	  m_serversArrayCache(NULL), m_credentials(NULL)	  
{}


Environment::~Environment()
{
	SAFE_FREE(m_basedir);
	SAFE_DELETE(m_servers);
	SAFE_DELETE(m_apps);
	//m_domain = NULL;		// Owned by cache
	m_credentials = NULL;	// Owned by cache
	SAFE_DELETE(m_serversArrayCache);
}


Expr *Environment::getAttribute(const char *name, class Context &ctx)
{
	if(strcmp(name, "basedir") == 0) {
		return new Expr(m_basedir);
	}
	if(strcmp(name, "notes") == 0) {
		const char *notes = getNotes();
		return notes ? new Expr(notes) : NULL;
	}
	if((strcmp(name, "servers") == 0) || (strcmp(name, "physicals") == 0)) {
		if(m_serversArrayCache) {
			return new Expr(m_serversArrayCache);
		}
		DMArray *ret = new DMArray(false, false, true);
		ret->addRef();	// This prevents the array being deleted
		List<Server> *list = getServers();
		ListIterator<Server> iter(*list);
		for(Server *s = iter.first(); s; s = iter.next()) {
			ret->put(s->name(), new Variable(NULL, s));
		}
		m_serversArrayCache = ret;
		return new Expr(ret);
	}
	if(strcmp(name, "parent") == 0) {
		Domain *domain = getDomain();
		return domain ? new Expr(domain) : NULL;
	}
	return Object::getAttribute(name, ctx);
}


//DMArray *Environment::getArrayAttribute(const char *name, class Context &ctx)
//{
//	if((strcmp(name, "servers") == 0) || (strcmp(name, "physicals") == 0)) {
//		if(m_serversArrayCache) {
//			return m_serversArrayCache;
//		}
//		DMArray *ret = new DMArray(false, false, true);
//		ret->addRef();	// This prevents the array being deleted
//		List<Server> *list = getServers();
//		ListIterator<Server> iter(*list);
//		for(Server *s = iter.first(); s; s = iter.next()) {
//			ret->put(s->name(), new Variable(NULL, s));
//		}
//		m_serversArrayCache = ret;
//		return ret;
//	}
//	return NULL;
//}


//IObject *Environment::getObjectAttribute(const char *name, class Context &ctx)
//{
//	if(strcmp(name, "parent") == 0) {
//		return getDomain();
//	}
//	return Object::getObjectAttribute(name, ctx);
//}


Scope *Environment::getVars()
{
	if(!m_vars) {
		m_vars = new Scope(ENVIRONMENT_SCOPE, this);
		m_vars->addRef();
		m_model.getVariablesForObject(*this, *m_vars);
	}

	return m_vars;
}


//Domain *Environment::getDomain()
//{
//	if(!m_domainSet) {
//		m_domainSet = true;
//		m_model.getDomainForEnvironment(*this);
//	}
//	return m_domain;
//}


//void Environment::setDomain(Domain *domain)
//{
//	m_domainSet = true;
//	m_domain    = domain;
//}


List<Server> *Environment::getServers()
{
	if(!m_servers) {
		m_servers = new List<Server>();
		m_model.getServersForEnvironment(*this);
	}

	return m_servers;
}


List<Application> *Environment::getAllowedApplications()
{
	if(!m_apps) {
		m_apps = new List<Application>();
		m_model.getApplicationsAllowedInEnvironment(*this);
	}

	return m_apps;
}


Application *Environment::getDeployedApplication(Application &app)
{
	return m_model.getApplicationDeployedToEnvironment(*this, app);
}


Credentials *Environment::getCredentials()
{
	if(!m_credentials) {
		m_model.getCredentialsForEnvironment(*this);
	}

	return m_credentials;
}


void Environment::setCredentials(Credentials *creds)
{
	m_credentials = creds;
}


void Environment::add(Server *server)
{
	if(!m_servers) {
		m_servers = new List<Server>();
	}
	m_servers->add(server);
}


void Environment::add(Application *app)
{
	if(!m_apps) {
		m_apps = new List<Application>(true);	// TODO: This should not own the applications
	}
	m_apps->add(app);
}


//bool Environment::hasAccess(User *user)
//{
//	// Check that the parent domain allows access first
//	if(!m_domainSet) {
//		getDomain();
//	}
//	if(m_domain) {
//		if(!m_domain->hasAccess(user)) {
//			// No access to domain - disallow access
//			return false;
//		}
//	}
//
//	return Object::hasAccess(user);
//}


Server *Environment::server(const char *name)
{
	if(!m_servers) { getServers(); }
	ListIterator<Server> iter(*m_servers);
	for(Server *s = iter.first(); s; s = iter.next()) {
		if(strcmp(s->name(), name) == 0) {
			return s;
		}
	}
	return NULL;
}


class Application *Environment::application(const char *name)
{
	if(!m_apps) { getAllowedApplications(); }
	ListIterator<Application> iter(*m_apps);
	for(Application *a = iter.first(); a; a = iter.next()) {
		if(strcmp(a->name(), name) == 0) {
			return a;
		}
	}
	return NULL;
}


bool Environment::isAvailable()
{
	return m_model.isEnvironmentAvailable(*this);
}


void Environment::print(int ind)
{
	indent(ind);   printf("Environment: %s\n", m_name);
	indent(ind+1); printf("Credentials: ");
	if(m_credentials) {
		m_credentials->print(0);
	} else {
		printf("(none)");
	}
	printf("\n");
	printObject(ind+1);
	if(m_servers) {
		//m_servers->print(ind+1);
		ListIterator<Server> iter(*m_servers);
		for(Server *s = iter.first(); s; s = iter.next()) {
			s->print(ind+1);
		}
	}
	if(m_apps) {
		//m_apps->print(ind+1);
		ListIterator<Application> iter(*m_apps);
		for(Application *a = iter.first(); a; a = iter.next()) {
			a->print(ind+1);
		}
	}
}


///////////////////////////////////////////////////////////////////////////////
// Domain
///////////////////////////////////////////////////////////////////////////////

Domain::Domain(Model &model, int id, const char *name)
	: Object(model, id, name), m_doms(NULL), m_envs(NULL), m_apps(NULL),
	  m_reps(NULL), m_nfys(NULL), m_dats(NULL), m_childrenCache(NULL)
{}


Domain::~Domain()
{
	SAFE_DELETE(m_doms);
	SAFE_DELETE(m_envs);
	SAFE_DELETE(m_apps);
	SAFE_DELETE(m_reps);
	SAFE_DELETE(m_nfys);
	SAFE_DELETE(m_dats);
	SAFE_DELETE(m_childrenCache);
}


List<Domain> *Domain::getSubdomains()
{
	if(!m_doms) {
		m_doms = new List<Domain>();
		m_model.getSubdomainsForDomain(this);
	}

	return m_doms;
}


List<Environment> *Domain::getEnvironments()
{
	if(!m_envs) {
		m_envs = new List<Environment>();
		m_model.getEnvironmentsForDomain(this);
	}

	return m_envs;
}


List<Application> *Domain::getApplications()
{
	if(!m_apps) {
		m_apps = new List<Application>();
		m_model.getApplicationsForDomain(this);
	}

	return m_apps;
}


List<Repository> *Domain::getRepositories()
{
	if(!m_reps) {
		m_reps = new List<Repository>();
		m_model.getRepositoriesForDomain(this);
	}

	return m_reps;
}


List<Notify> *Domain::getNotifys()
{
	if(!m_nfys) {
		m_nfys = new List<Notify>();
		m_model.getNotifysForDomain(this);
	}

	return m_nfys;
}


List<Datasource> *Domain::getDatasources()
{
	if(!m_dats) {
		m_dats = new List<Datasource>();
		m_model.getDatasourcesForDomain(this);
	}

	return m_dats;
}


void Domain::add(Domain *domain)
{
	if(!m_doms) {
		m_doms = new List<Domain>();
	}
	m_doms->add(domain);
}


void Domain::add(Environment *env)
{
	if(!m_envs) {
		m_envs = new List<Environment>();
	}
	m_envs->add(env);
}


void Domain::add(Application *app)
{
	if(!m_apps) {
		m_apps = new List<Application>();
	}
	m_apps->add(app);
}


void Domain::add(Repository *rep)
{
	if(!m_reps) {
		m_reps = new List<Repository>();
	}
	m_reps->add(rep);
}


void Domain::add(Notify *nfy)
{
	if(!m_nfys) {
		m_nfys = new List<Notify>();
	}
	m_nfys->add(nfy);
}


void Domain::add(Datasource *dat)
{
	if(!m_dats) {
		m_dats = new List<Datasource>();
	}
	m_dats->add(dat);
}


/*virtual*/ Expr *Domain::getAttribute(const char *name, class Context &ctx)
{
	if(strcmp(name, "children") == 0) {
		if(!m_childrenCache) {
			m_childrenCache = new DMArray(false);
			m_childrenCache->addRef();	// This prevents the array being deleted
			List<Domain> *children = getSubdomains();
			ListIterator<Domain> iter(*children);
			for(Domain *dom = iter.first(); dom; dom = iter.next()) {
				m_childrenCache->put(dom->name(), new Variable(NULL, dom));
			}
		}
		return new Expr(m_childrenCache);
	}
	return Object::getAttribute(name, ctx);
}


void Domain::print(int ind)
{
	indent(ind); printf("Domain: %s\n", m_name);
	Object::printObject(ind+1);
	if(m_doms) {
		//m_domains->print(ind+1);
		ListIterator<Domain> iter(*m_doms);
		for(Domain *d = iter.first(); d; d = iter.next()) {
			d->print(ind+1);
		}
	}
	if(m_envs) {
		//m_envs->print(ind+1);
		ListIterator<Environment> iter(*m_envs);
		for(Environment *e = iter.first(); e; e = iter.next()) {
			e->print(ind+1);
		}
	}
	if(m_apps) {
		//m_apps->print(ind+1);
		ListIterator<Application> iter(*m_apps);
		for(Application *a = iter.first(); a; a = iter.next()) {
			a->print(ind+1);
		}
	}
	if(m_reps) {
		//m_reps->print(ind+1);
		ListIterator<Repository> iter(*m_reps);
		for(Repository *r = iter.first(); r; r = iter.next()) {
			r->print(ind+1);
		}
	}
	if(m_nfys) {
		//m_nfys->print(ind+1);
		ListIterator<Notify> iter(*m_nfys);
		for(Notify *n = iter.first(); n; n = iter.next()) {
			n->print(ind+1);
		}
	}
	if(m_dats) {
		//m_dats->print(ind+1);
		ListIterator<Datasource> iter(*m_dats);
		for(Datasource *d = iter.first(); d; d = iter.next()) {
			d->print(ind+1);
		}
	}
}


///////////////////////////////////////////////////////////////////////////////
// ServerType
///////////////////////////////////////////////////////////////////////////////

ServerType::ServerType(
		int id, const char *hosttype,
		LINE_END_FORMAT lineends, const char *pathformat)
	: m_id(id), m_hosttype(DUP_NULL(hosttype)), m_lineends(lineends),
	  m_pathformat(DUP_NULL(pathformat))
{}


ServerType::~ServerType()
{
	SAFE_FREE(m_hosttype);
	SAFE_FREE(m_pathformat);
}


PathNameImpl *ServerType::createPath(const char* path)
{
	if(!m_pathformat) {
		return NULL;
	}
	PathNameImplFactory *fact = PathNameImplRegistry::instance().getFactory(m_pathformat);
	if(!fact) {
		throw RuntimeError("Unknown path format provider '%s'", m_pathformat);
	}
	return fact->create(path);
}


///////////////////////////////////////////////////////////////////////////////
// Server
///////////////////////////////////////////////////////////////////////////////

Server::Server(
		Model &model, int id, const char *name, const char *hostname,
		const char *protocol, const char *basedir, ServerType *servertype)
	: Object(model, id, name), m_hostname(DUP_NULL(hostname)),
	  m_protocol(DUP_NULL(protocol)), m_basedir(DUP_NULL(basedir)),
	  m_credentials(NULL), m_servertype(servertype)
{}


Server::~Server()
{
	SAFE_FREE(m_hostname);
	SAFE_FREE(m_protocol);
	SAFE_FREE(m_basedir);
	m_credentials = NULL;		// Owned by cache
	m_servertype = NULL;		// Owned by cache
}


/*virtual*/ const char *Server::hostname()
{
	return m_hostname ? m_hostname : m_name;
}


LINE_END_FORMAT Server::lineends()
{
	return m_servertype ? m_servertype->lineends() : LINE_ENDS_OFF;
}


PathNameImpl *Server::createPath(const char* path)
{
	return m_servertype ? m_servertype->createPath(path) : NULL;
}


/*virtual*/ Expr *Server::getAttribute(const char *name, class Context &ctx)
{
	if(strcmp(name, "hostname") == 0) {
		return new Expr(hostname());
	}
	if(strcmp(name, "basedir") == 0) {
		return m_basedir ? new Expr(m_basedir) : NULL;
	}
	if(strcmp(name, "type") == 0) {
		return m_servertype ? new Expr(m_servertype->hosttype()) : NULL;
	}
	if(strcmp(name, "notes") == 0) {
		const char *notes = getNotes();
		return notes ? new Expr(notes) : NULL;
	}
	return Object::getAttribute(name, ctx);
}


//IObject *Server::getObjectAttribute(const char *name, class Context &ctx)
//{
//	return Object::getObjectAttribute(name, ctx);
//}


Scope *Server::getVars()
{
	if(!m_vars) {
		m_vars = new Scope(SERVER_SCOPE, this);
		m_vars->set("TRIDM_PHYSICAL_SERVER", name());
		m_vars->set("TRIDM_PHYSICAL_HOSTNAME", hostname());
		m_vars->addRef();
		m_model.getVariablesForObject(*this, *m_vars);
	}

	return m_vars;
}


Credentials *Server::getCredentials()
{
	if(!m_credentials) {
		m_model.getCredentialsForServer(*this);
	}

	return m_credentials;
}


void Server::setCredentials(Credentials *creds)
{
	m_credentials = creds;
}


void Server::print(int ind)
{
	indent(ind);   printf("Server: %s\n", m_name);
	indent(ind+1); printf("Hostname: %s\n", (m_hostname ? m_hostname : "(no hostname)"));
	indent(ind+1); printf("Credentials: ");
	if(m_credentials) {
		m_credentials->print(0);
	} else {
		printf("(none)");
	}
	printf("\n");
	printObject(ind+1);
}


///////////////////////////////////////////////////////////////////////////////
// Application
///////////////////////////////////////////////////////////////////////////////


Application::Application(Model &model, int id, const char *name)
	: Object(model, id, name), m_action(NULL), m_preAction(NULL),
	  m_postAction(NULL), m_actionsSet(false), m_components(NULL),
	  m_versionsCache(NULL)
{}


Application::~Application()
{
	m_action = NULL;		// Owned by cache
	m_preAction = NULL;		// Owned by cache
	m_postAction = NULL;	// Owned by cache
	SAFE_DELETE(m_components);	// List only - objects owned by cache
}


/*virtual*/ Expr *Application::getAttribute(const char *name, class Context &ctx)
{
	return Object::getAttribute(name, ctx);
}


//IObject *Application::getObjectAttribute(const char *name, class Context &ctx)
//{
//	return Object::getObjectAttribute(name, ctx);
//}


Scope *Application::getVars()
{
	if(!m_vars) {
		m_vars = new Scope(APPLICATION_SCOPE, this);
		m_vars->addRef();
		m_model.getVariablesForObject(*this, *m_vars);
	}

	return m_vars;
}


Action *Application::getCustomAction()
{
	if(!m_actionsSet) {
		m_model.getActionsForApplication(*this);
	}
	return m_action;
}


Action *Application::getPreAction()
{
	if(!m_actionsSet) {
		m_model.getActionsForApplication(*this);
	}
	return m_preAction;
}


Action *Application::getPostAction()
{
	if(!m_actionsSet) {
		m_model.getActionsForApplication(*this);
	}
	return m_postAction;
}


/*private*/ void Application::setActions(Action *action, Action *preAction, Action *postAction)
{
	m_action = action;
	m_preAction = preAction;
	m_postAction = postAction;
	m_actionsSet = true;
}


List<Component> *Application::getComponents()
{
	if(!m_components) {
		m_components = new List<Component>(false);
		m_model.getComponentsForApplication(*this);
	}
	return m_components;
}


void Application::addComponent(Component *comp)
{
	if(!m_components) {
		m_components = new List<Component>(false);
	}
	m_components->add(comp);
}


List<Application> *Application::getParentList()
{
	List<Application> *ret = new List<Application>(false);
	ret->add(this);
	return ret;
}


ApplicationVersion *Application::getVersion(const char *name)
{
	ApplicationVersion *av = m_versionsCache ? m_versionsCache->get(name) : NULL;
	if(av) {
		return av;
	}
	av = m_model.getVersionOfApplication(*this, name);
	if(av) {
		if(!m_versionsCache) {
			m_versionsCache = new Hashtable<ApplicationVersion>();
		}
		m_versionsCache->put(name, av);
	}
	return av;
}


bool Application::isAvailable(Environment &env)
{
	return m_model.isApplicationAvailable(*this, env);
}


bool Application::approve(class Domain &tgtDomain, bool approve, const char *note)
{
	return m_model.approveApplication(*this, tgtDomain, approve, note);
}


bool Application::move(class Domain &tgtDomain, const char *note)
{
	return m_model.moveApplication(*this, tgtDomain, note);
}


void Application::recordDeployedToEnv(class DM &dm, class Environment &env, bool success)
{
	m_model.recordAppInEnv(dm, *this, env, success);
}


ApplicationVersion *Application::newVersion(Domain &tgtDomain, Application *predecessor)
{
	return m_model.newVersionOfApplication(*this, tgtDomain, predecessor);
}


ApplicationVersion *Application::getLatestVersion(/*branch*/)
{
	return m_model.getLatestVersionOfApplication(*this /*, branch*/);
}


void Application::print(int ind)
{
	indent(ind); printf("Application: %s\n", m_name);
	printObject(ind+1);
}


///////////////////////////////////////////////////////////////////////////////
// ApplicationVersion
///////////////////////////////////////////////////////////////////////////////

ApplicationVersion::ApplicationVersion(
		class Model &model, int id, const char *name,
		const char *version, Application *parent)
	: Application(model, id, name), m_version(DUP_NULL(version)),
	  m_parent(parent), m_predecessor(NULL), m_predecessorSet(false),
	  m_successors(NULL), m_approvalsArrayCache(NULL)
{}


ApplicationVersion::~ApplicationVersion()
{
	SAFE_FREE(m_version);
	m_parent = NULL;		// Owned by cache
	m_predecessor = NULL;	// Owned by cache
	SAFE_DELETE(m_successors);
}


ApplicationVersion *ApplicationVersion::getPredecessor()
{
	if(!m_predecessorSet) {
		m_model.getPredecessorForApplicationVersion(*this);
	}
	return m_predecessor;
}


/*private*/ void ApplicationVersion::setPredecessor(ApplicationVersion *predecessor)
{
	m_predecessor = predecessor;
	m_predecessorSet = true;
}


List<ApplicationVersion> *ApplicationVersion::getSuccessors()
{
	if(!m_successors) {
		m_successors = new List<ApplicationVersion>(false);
		m_model.getSuccessorsForApplicationVersion(*this);
	}
	return m_successors;
}


/*private*/ void ApplicationVersion::addSuccessor(ApplicationVersion *successor)
{
	if(!m_successors) {
		m_successors = new List<ApplicationVersion>(false);
	}
	m_successors->add(successor);
}


List<Application> *ApplicationVersion::getParentList()
{
	List<Application> *ret =  m_parent ? m_parent->getParentList() : NULL;
	if(!ret) {
		ret = new List<Application>(false);
	}
	ret->add(this);
	return ret;
}


DMArray *ApplicationVersion::getApprovals()
{
	if(!m_approvalsArrayCache) {
		m_approvalsArrayCache =  m_model.getApprovalsForApplicationVersion(*this);
		m_approvalsArrayCache->addRef();		// This prevents the array being deleted
	}
	return m_approvalsArrayCache;
}


Expr *ApplicationVersion::getAttribute(const char *name, class Context &ctx)
{
	if(strcmp(name, "version") == 0) {
		return new Expr(m_version);
	} else if(strcmp(name, "parent") == 0) {
		return new Expr(m_parent);
	} else if(strcmp(name, "predecessor") == 0) {
		return new Expr(getPredecessor());
	} else if(strcmp(name, "approvals") == 0) {
		return new Expr(getApprovals());
	}
	return Application::getAttribute(name, ctx);
}


//IObject *ApplicationVersion::getObjectAttribute(const char *name, class Context &ctx)
//{
//	if(strcmp(name, "parent") == 0) {
//		return m_parent;
//	}
//	return Application::getObjectAttribute(name, ctx);
//}


ApplicationVersion *ApplicationVersion::operator_plus(int incr, Context &ctx) const
{
	Scope *avloopScope = ctx.stack().getScope(AVLOOP_SCOPE);
	IObject *avloop = avloopScope ? avloopScope->getScopeObject() : NULL;

	if(avloop) {
		debug1("ApplicationVersion %d + %d (in avloop)", m_id, incr);
		ExprPtr elast = avloop->getAttribute("last", ctx);
		ObjectReference *oref = elast ? elast->toObjectReference() : NULL;
		Object *o = oref ? oref->toObject() : NULL;
		if(o && (o->kind() == OBJ_KIND_APPVERSION)) {
			ApplicationVersion *last = (ApplicationVersion*) o;
			List<ApplicationVersion> path(false);
			bool found = false;
			for(ApplicationVersion *av = last; av; av = av->getPredecessor()) {
				path.prepend(av);
				if(av == this) {
					found = true;
					break;
				}
			}
			if(!found) {
				debug1("Application version %d not on current avloop path", m_id);
				throw RuntimeError(ctx.stack(), "Application version %d not on current avloop path", m_id);
			}
			ListIterator<ApplicationVersion> iter(path);
			for(ApplicationVersion *av = iter.first(); av; incr--) {
				if(incr <= 0) {
					debug1("ApplicationVersion operator+ returning %d", av->id());
					return av;
				}
				av = iter.next();
			}
		}
	}

	debug1("ApplicationVersion %d + %d", m_id, incr);
	if(incr > 0) {
		for(ApplicationVersion *av = (ApplicationVersion*) this; av; incr--) {
			if(incr <= 0) {
				debug1("ApplicationVersion operator+ returning %d", av->id());
				return av;
			}
			List<ApplicationVersion> *succs = av->getSuccessors();
			if(!succs || (succs->size() == 0)) break;
			if(succs->size() > 1) {
				debug1("Successor to application version %d is ambiguous", av->id());
				throw RuntimeError(ctx.stack(), "Successor to application version %d is ambiguous", av->id());
			}
			ListIterator<ApplicationVersion> iter(*succs);
			av = iter.first();
		}
	}
	return NULL;
}


ApplicationVersion *ApplicationVersion::operator_minus(int decr, Context &ctx) const
{
	debug1("ApplicationVersion %d - %d", m_id, decr);
	if(decr > 0) {
		for(ApplicationVersion *av = (ApplicationVersion*) this; av; decr--) {
			if(decr <= 0) {
				debug1("ApplicationVersion operator- returning %d", av->id());
				return av;
			}
			av = av->getPredecessor();
		}
	}
	return NULL;
}


void ApplicationVersion::alterVars(class DMArray *attrs)
{
	m_model.alterApplicationVersionVars(*this, attrs);
}


///////////////////////////////////////////////////////////////////////////////
// ComponentItem
///////////////////////////////////////////////////////////////////////////////

ComponentItem::ComponentItem(
		Model &model, int id, const char *name, Component &parent, int repoid,
		const char *target, ComponentFilter rollup, ComponentFilter rollback
	)
	: /*m_model(model), m_id(id),*/ Object(model, id, name), m_parent(parent), m_repoid(repoid),
	  m_target(DUP_NULL(target)), m_rollup(rollup), m_rollback(rollback),
	  m_repo(NULL), m_props(NULL)
{}


ComponentItem::~ComponentItem()
{
	SAFE_FREE(m_target);
	m_repo = NULL;	// Owned by cache
	SAFE_DELETE(m_props);
}


/*private*/ void ComponentItem::setRepository(Repository *repo)
{
	m_repo = repo;
}


Repository *ComponentItem::getRepository()
{
	if(!m_repo) {
		m_model.getRepositoryForComponentItem(*this);
	}
	return m_repo;
}


Property *ComponentItem::getProperty(const char *name)
{
	return m_props ? m_props->get(name) : NULL;
}


void ComponentItem::setProperty(Property *prop)
{
	if(!m_props) {
		m_props = new Hashtable<Property>(false, true);
	}
	m_props->put(prop->name(), prop);
}


StmtList *ComponentItem::getPropertiesAsArgs()
{
	StmtList *ret = new StmtList();
	if(m_props) {
		AutoPtr<StringList> keys = m_props->keys();
		StringListIterator iter(*keys);
		for(const char *name = iter.first(); name; name = iter.next()) {
			Property *p = m_props->get(name);
			if(p) {
				ret->add(new Stmt(strdup(name), new Node(NODE_STR, DUP_NULL(p->value()))));
			}
		}
	}

	return ret;
}


Expr *ComponentItem::getAttribute(const char *name, Context &ctx)
{
	if(strcmp(name, "repository") == 0) {
		Repository *repo = getRepository();
		return (repo ? new Expr(repo->name()) : NULL);
	} else if(strcmp(name, "target") == 0) {
		return new Expr(m_target);
	} else if(strcmp(name, "parent") == 0) {
		return new Expr(m_parent.toObject());
	} else if(strcmp(name, "rollup") == 0) {
		return new Expr(m_rollup != OFF);
	} else if(strcmp(name, "rollback") == 0) {
		return new Expr(m_rollback != OFF);
	}
	return Object::getAttribute(name, ctx);
}


//DMArray *ComponentItem::getArrayAttribute(const char *name, Context &ctx)
//{
//	return NULL;
//}


//IObject *ComponentItem::getObjectAttribute(const char *name, Context &ctx)
//{
//	return NULL;
//}


void ComponentItem::print(int ind)
{
	indent(ind); printf("ComponentItem: %s\n", m_name);
	printObject(ind+1);
}


///////////////////////////////////////////////////////////////////////////////
// Component
///////////////////////////////////////////////////////////////////////////////


Component::Component(
		Model &model, int id, const char *name, const char *basedir,
		ComponentFilter rollup, ComponentFilter rollback, bool filterItems
	)
	: Object(model, id, name), m_basedir(DUP_NULL(basedir)),
	  m_rollup(rollup), m_rollback(rollback), m_filterItems(filterItems),
	  m_items(NULL), m_itemsArrayCache(NULL), m_serversArrayCache(NULL),
	  m_action(NULL), m_preAction(NULL), m_postAction(NULL), m_actionsSet(false)
{}


Component::~Component()
{
	SAFE_DELETE(m_items);
	SAFE_FREE(m_basedir);
	SAFE_DELETE(m_itemsArrayCache);
	SAFE_DELETE(m_serversArrayCache);
	m_action = NULL;			// owned by cache
	m_preAction = NULL;			// owned by cache
	m_postAction = NULL;		// owned by cache
}


Expr *Component::getAttribute(const char *name, class Context &ctx)
{
	if(strcmp(name, "items") == 0) {
		if(!m_itemsArrayCache) {
			getItems();
			m_itemsArrayCache = new DMArray(true, false, true);
			m_itemsArrayCache->addRef();	// This prevents the array being deleted
			ListIterator<ComponentItem> iter(*m_items);
			for(ComponentItem *ci = iter.first(); ci; ci = iter.next()) {
				m_itemsArrayCache->add(new Variable(NULL, ci));
			}
		}
		return new Expr(m_itemsArrayCache);
	} else if(strcmp(name, "servers") == 0) {
		if(!m_serversArrayCache) {
			m_serversArrayCache = new DMArray(false, false, true);
			Environment *env = ctx.dm().getTargetEnvironment();
			if(env) {
				List<Server> *servers = m_model.getAllServersForComponent(*this, *env);
				m_serversArrayCache->addRef();	// This prevents the array being deleted
				ListIterator<Server> iter(*servers);
				for(Server *s = iter.first(); s; s = iter.next()) {
					m_serversArrayCache->put(s->name(), new Variable(NULL, s));
				}
				SAFE_DELETE(servers);
			}
		}
		return new Expr(m_serversArrayCache);
	} else if(strcmp(name, "rollup") == 0) {
		return new Expr(m_rollup != OFF);
	} else if(strcmp(name, "rollback") == 0) {
		return new Expr(m_rollback != OFF);
	}
	return Object::getAttribute(name, ctx);
}


//DMArray *Component::getArrayAttribute(const char *name, class Context &ctx)
//{
//	if(strcmp(name, "items") == 0) {
//		if(!m_itemsArrayCache) {
//			getItems();
//			m_itemsArrayCache = new DMArray(true, false, true);
//			m_itemsArrayCache->addRef();	// This prevents the array being deleted
//			ListIterator<ComponentItem> iter(*m_items);
//			for(ComponentItem *ci = iter.first(); ci; ci = iter.next()) {
//				m_itemsArrayCache->add(new Variable(NULL, ci));
//			}
//		}
//		return m_itemsArrayCache;
//	} else if(strcmp(name, "servers") == 0) {
//		if(!m_serversArrayCache) {
//			List<Server> *servers = m_model.getAllServersForComponent(*this);
//			m_serversArrayCache = new DMArray(false, false, true);
//			m_serversArrayCache->addRef();	// This prevents the array being deleted
//			ListIterator<Server> iter(*servers);
//			for(Server *s = iter.first(); s; s = iter.next()) {
//				m_serversArrayCache->put(s->name(), new Variable(NULL, s));
//			}
//			SAFE_DELETE(servers);
//		}
//		return m_serversArrayCache;
//	}
//	return Object::getArrayAttribute(name, ctx);
//}


//IObject *Component::getObjectAttribute(const char *name, class Context &ctx)
//{
//	return Object::getObjectAttribute(name, ctx);
//}


Scope *Component::getVars()
{
	if(!m_vars) {
		m_vars = new Scope(COMPONENT_SCOPE, this);
		m_vars->addRef();
		m_model.getVariablesForObject(*this, *m_vars);
	}

	return m_vars;
}


List<Server> *Component::getServerSubset(class Context &ctx)
{
	return m_model.getServerSubsetForComponent(*this, ctx.servers());
}


List<ComponentItem> *Component::getItems()
{
	if(!m_items) {
		m_items = new List<ComponentItem>(true);
		m_model.getItemsForComponent(*this);
	}
	return m_items;
}


void Component::add(ComponentItem *item)
{
	if(!m_items) {
		m_items = new List<ComponentItem>(true);
	}
	m_items->add(item);
}


Action *Component::getCustomAction()
{
	if(!m_actionsSet) {
		m_model.getActionsForComponent(*this);
	}
	return m_action;
}


Action *Component::getPreAction()
{
	if(!m_actionsSet) {
		m_model.getActionsForComponent(*this);
	}
	return m_preAction;
}


Action *Component::getPostAction()
{
	if(!m_actionsSet) {
		m_model.getActionsForComponent(*this);
	}
	return m_postAction;
}


/*private*/ void Component::setActions(Action *action, Action *preAction, Action *postAction)
{
	m_action = action;
	m_preAction = preAction;
	m_postAction = postAction;
	m_actionsSet = true;
}


void Component::recordDeployedToServer(class DM &dm, class Server &server, bool success)
{
	m_model.recordCompOnServ(dm, *this, server, success);
}


void Component::print(int ind)
{
	indent(ind); printf("Component: %s\n", m_name);
	printObject(ind+1);
}


///////////////////////////////////////////////////////////////////////////////
// User
///////////////////////////////////////////////////////////////////////////////

User::User(
		Model &model, int id, const char *name, const char *email,
		const char *realname, const char *phone
	)
	: Object(model, id, name), m_email(DUP_NULL(email)),
	  m_realname(DUP_NULL(realname)), m_phone(DUP_NULL(phone)),
	  m_groups(NULL), m_groupsArrayCache(NULL),
	  m_accessibleDomainsCache(NULL)
{}


User::~User()
{
	SAFE_FREE(m_email);
	SAFE_FREE(m_realname);
	SAFE_FREE(m_phone);
	SAFE_DELETE(m_groups);
	SAFE_DELETE(m_groupsArrayCache);
	SAFE_FREE(m_accessibleDomainsCache)
}


/*virtual*/ Expr *User::getAttribute(const char *name, class Context &ctx)
{
	if(strcmp(name, "email") == 0) {
		return new Expr(m_email);
	}
	if(strcmp(name, "realname") == 0) {
		return new Expr(m_realname);
	}
	if(strcmp(name, "phone") == 0) {
		return new Expr(m_phone);
	}
	if(strcmp(name, "groups") == 0) {
		if(!m_groupsArrayCache) {
			if(!m_groups) {
				getUserGroups();
			}
			DMArray *ret = new DMArray(false, false, true);
			ret->addRef();	// This prevents the array being deleted
			if(m_groups) {
				ListIterator<UserGroup> iter(*m_groups);
				for(UserGroup *group = iter.first(); group; group = iter.next()) {
					ret->put(group->name(), new Variable(NULL, group));
				}
			}
			m_groupsArrayCache = ret;
		}
		return new Expr(m_groupsArrayCache);
	}
	return Object::getAttribute(name, ctx);
}


//DMArray *User::getArrayAttribute(const char *name, class Context &ctx)
//{
//	if(strcmp(name, "groups") == 0) {
//		if(!m_groupsArrayCache) {
//			if(!m_groups) {
//				getUserGroups();
//			}
//			DMArray *ret = new DMArray(false, false, true);
//			ret->addRef();	// This prevents the array being deleted
//			if(m_groups) {
//				ListIterator<UserGroup> iter(*m_groups);
//				for(UserGroup *group = iter.first(); group; group = iter.next()) {
//					ret->put(group->name(), new Variable(NULL, group));
//				}
//			}
//			m_groupsArrayCache = ret;
//		}
//		return m_groupsArrayCache;
//	}
//	return Object::getArrayAttribute(name, ctx);
//}


List<UserGroup> *User::getUserGroups()
{
	if(!m_groups) {
		add(UserGroup::getEveryoneGroup(m_model));
		m_model.getUserGroupsForUser(*this);
	}
	return m_groups;
}


void User::add(class UserGroup *group)
{
	if(!m_groups) {
		m_groups = new List<UserGroup>();
	}
	m_groups->add(group);
}


bool User::validateHashedPassword(const char *passhash)
{
	return m_model.validateHashedPassword(*this, passhash);
}


const char *User::getAccessibleDomains()
{
	if(m_accessibleDomainsCache) {
		return m_accessibleDomainsCache;
	}

	Domain *domain = getDomain();
	if(domain) {
		m_accessibleDomainsCache = m_model.getAccessibleDomains(*domain);
	}

	debug0("User::getAccessibleDomains() returns '%s'", NULL_CHECK(m_accessibleDomainsCache));
	return m_accessibleDomainsCache;
}


void User::print(int ind)
{
	indent(ind);   printf("User: %s\n", m_name);
	indent(ind+1); printf("Email: %s\n", (m_email ? m_email : "(no email)"));
}


///////////////////////////////////////////////////////////////////////////////
// UserGroup
///////////////////////////////////////////////////////////////////////////////

/*static*/ UserGroup *UserGroup::s_everyone = NULL;


UserGroup::UserGroup(
		class Model &model, int id, const char *name, const char *email
	)
	: Object(model, id, name), m_email(DUP_NULL(email)), m_users(NULL),
	  m_usersArrayCache(NULL)
{}


UserGroup::~UserGroup()
{
	SAFE_FREE(m_email);
	SAFE_DELETE(m_users);
	SAFE_DELETE(m_usersArrayCache);
}


Expr *UserGroup::getAttribute(const char *name, class Context &ctx)
{
	if(strcmp(name, "email") == 0) {
		return new Expr(m_email);
	}
	if(strcmp(name, "users") == 0) {
		if(!m_usersArrayCache) {
			if(!m_users) {
				getUsers();
			}
			DMArray *ret = new DMArray(false, false, true);
			ret->addRef();	// This prevents the array being deleted
			if(m_users) {
				ListIterator<User> iter(*m_users);
				for(User *user = iter.first(); user; user = iter.next()) {
					ret->put(user->name(), new Variable(NULL, user));
				}
			}
			m_usersArrayCache = ret;
		}
		return new Expr(m_usersArrayCache);
	}
	return Object::getAttribute(name, ctx);
}


//DMArray *UserGroup::getArrayAttribute(const char *name, class Context &ctx)
//{
//	if(strcmp(name, "users") == 0) {
//		if(!m_usersArrayCache) {
//			if(!m_users) {
//				getUsers();
//			}
//			DMArray *ret = new DMArray(false, false, true);
//			ret->addRef();	// This prevents the array being deleted
//			if(m_users) {
//				ListIterator<User> iter(*m_users);
//				for(User *user = iter.first(); user; user = iter.next()) {
//					ret->put(user->name(), new Variable(NULL, user));
//				}
//			}
//			m_usersArrayCache = ret;
//		}
//		return m_usersArrayCache;
//	}
//	return Object::getArrayAttribute(name, ctx);
//}


List<User> *UserGroup::getUsers()
{
	if(!m_users) {
		m_model.getUsersForUserGroup(*this);
	}
	return m_users;
}


void UserGroup::add(User *user)
{
	if(!m_users) {
		m_users = new List<User>();
	}
	m_users->add(user);
}


void UserGroup::print(int ind)
{
	indent(ind);   printf("UserGroup: %s\n", m_name);
	indent(ind+1); printf("Email: %s\n", (m_email ? m_email : "(no email)"));
}


/*static*/ UserGroup *UserGroup::getEveryoneGroup(class Model &model)
{
	if(!s_everyone) {
		s_everyone = new UserGroup(model, EVERYONE_ID, "EVERYONE", NULL);
	}
	return s_everyone;
}


///////////////////////////////////////////////////////////////////////////////
// Repository
///////////////////////////////////////////////////////////////////////////////

Repository::Repository(class Model &model, int id, const char *name)
	: ProviderObject(model, id, name), m_impls(NULL)
{}


Repository::~Repository()
{
	SAFE_DELETE(m_impls);
}


RepositoryImpl *Repository::createImpl(
	DMINT32 implId, ExtendedStmt &stmt, AuditEntry *entry, Context &ctx)
{
	if(!hasAccess(ctx.dm().getCurrentUser())) {
		throw PermissionDeniedException(ctx.stack(), "No access to repository '%s'", m_name);
	}

	ProviderObjectDef &def = getDef(ctx);

	Plugin *plugin = def.getPlugin();
	if(plugin && !plugin->loadPlugin(ctx.dm())) {
		throw RuntimeError(ctx.stack(), "Unable to load plugin for repository type '%s'", def.name());
	}

	RepositoryImplFactory *factory = RepositoryImplRegistry::instance().getFactory(def);

	if(!factory) {
		throw RuntimeError(ctx.stack(), "Unrecognised repository type '%s'", def.name());
	}

	// Verify that all mandatory properties are present and warn of any we won't use
	def.verifyProperties(ctx, m_props);

	// Create an instance of the impl so that we may later execute it - we push
	// the repository's vars so that they can be used during the evaluation of
	// the args/props.
	RepositoryImpl *impl = NULL;
	ctx.stack().push(getVars());
	try {
		impl = factory->create(implId, *this, stmt, ctx);
	} catch(...) {
		ctx.stack().pop(REPOSITORY_SCOPE);
		throw;
	}
	ctx.stack().pop(REPOSITORY_SCOPE);

	if(!impl) {
		throw RuntimeError(ctx.stack(), "Unexpected error creating instance of repository type '%s'", def.name());
	}
	if(!m_impls) {
		m_impls = new HashtableById<RepositoryImpl>(true);
	}
	m_impls->put(implId, impl);

	if(entry) {
		entry->recordInstance(*impl, ctx);
	}

	return impl;
}


Scope *Repository::getVars()
{
	if(!m_vars) {
		m_vars = new Scope(REPOSITORY_SCOPE, this);
		m_vars->addRef();
		m_model.getVariablesForObject(*this, *m_vars);
	}

	return m_vars;
}


Scope *Repository::getVars(
	DMINT32 implId, class ExtendedStmt &stmt, AuditEntry *entry, Context &ctx)
{
	RepositoryImpl *impl = m_impls ? m_impls->get(implId) : NULL;
	if(!impl) {
		impl = createImpl(implId, stmt, entry, ctx);
	}
	return impl->getVars();
}


char *Repository::dirname(const char *filename)
{
	// TODO: Move this to the factory
	return (m_impls && m_impls->get(0)) ? m_impls->get(0)->dirname(filename) : NULL;
}


bool Repository::testProvider(class ExtendedStmt &stmt, class Context &ctx)
{
	if(!hasAccess(ctx.dm().getCurrentUser())) {
		throw PermissionDeniedException(ctx.stack(), "No access to test repository '%s'", m_name);
	}

	RepositoryImpl *impl = createImpl(1, stmt, NULL, ctx);
	getDef(ctx).verifyArgs(ctx, stmt.getArgs(), m_props);
	return impl->testProvider(ctx);
}


void Repository::checkout(
	const char *dzbase, const char *dzpath, class ExtendedStmt &stmt,
	AuditEntry *entry, DropzoneCallback &cb, Context &ctx)
{
	if(!hasReadAccess(ctx.dm().getCurrentUser())) {
		throw PermissionDeniedException(ctx.stack(), "No read access for checkout from repository '%s'", m_name);
	}

	RepositoryImpl *impl = m_impls ? m_impls->get(cb.repoImplId()) : NULL;
	if(!impl) {
		impl = createImpl(cb.repoImplId(), stmt, entry, ctx);
	}

	bool recursive = stmt.getOverridableArgAsBoolean("recursive", *this, false, ctx);
	debug1("recursive = %s", recursive ? "true" : "false");

	// TODO: Can use either getArg() or getOverridableArg() if we want patterns as properties
	AutoPtr<StringList> pattern;
	ExprPtr epattern = stmt.getArg("pattern", ctx);
	if(epattern) {
		pattern = new StringList();
		if(epattern->kind() == KIND_ARRAY) {
			DMArray *arr = epattern->toArray();
			AutoPtr<StringList> keys = arr->keys();
			StringListIterator iter(*keys);
			for(const char *key = iter.first(); key; key = iter.next()) {
				Variable *v = arr->get(key);
				if(v) {
					debug1("adding pattern '%s'", v->value());
					pattern->add(v->value());
				}
			}
		} else {
			ConstCharPtr patt = epattern->toString();
			if(patt) {
				debug1("setting pattern to '%s'", (const char*) patt);
				pattern->add(patt);
			}
		}
	}

	if(pattern && (pattern->size() == 0)) {
		throw RuntimeError(ctx.stack(), "Unable to evaluate pattern");
	}

	getDef(ctx).verifyArgs(ctx, stmt.getArgs(), m_props);
	cb.checkout_from_repository(this);
	impl->checkout(dzbase, dzpath, recursive, pattern, stmt, cb, ctx);
}


void Repository::checkin(
	const char *dzbase, const char *dzpath, class ExtendedStmt &stmt,
	AuditEntry *entry, DropzoneCallback &cb, Context &ctx)
{
	if(!hasWriteAccess(ctx.dm().getCurrentUser())) {
		throw PermissionDeniedException(ctx.stack(), "No write access for checkin to repository '%s'", m_name);
	}

	RepositoryImpl *impl = m_impls ? m_impls->get(cb.repoImplId()) : NULL;
	if(!impl) {
		impl = createImpl(cb.repoImplId(), stmt, entry, ctx);
	}

	getDef(ctx).verifyArgs(ctx, stmt.getArgs(), m_props);
	cb.checkin_to_repository(this);
	impl->checkin(dzbase, dzpath, stmt, cb, ctx);
}


List<RepositoryTextPattern> *Repository::getTextPatternsForPath(const char *path)
{
	return m_model.getTextPatternsForRepositoryPath(*this, path);
}


List<RepositoryIgnorePattern> *Repository::getIgnorePatterns()
{
	if(!m_def) {
		throw RuntimeError("Provider object definition not yet resolved for repository provider '%s'", m_name);
	}
	return m_model.getIgnorePatternsForRepositoryDef(*m_def);
}


void Repository::print(int ind)
{
	indent(ind); printf("Repository: %s\n", m_name);
	printProviderObject(ind+1);
}


///////////////////////////////////////////////////////////////////////////////
// Notify
///////////////////////////////////////////////////////////////////////////////

Notify::Notify(class Model &model, int id, const char *name)
	: ProviderObject(model, id, name), m_impls(NULL)
{}


Notify::~Notify()
{
	SAFE_DELETE(m_impls);
}


NotifyProviderImpl *Notify::createImpl(
	DMINT32 implId, ExtendedStmt &stmt, AuditEntry *entry, Context &ctx)
{
	if(!hasAccess(ctx.dm().getCurrentUser())) {
		throw PermissionDeniedException(ctx.stack(), "No access to notify '%s'", m_name);
	}

	ProviderObjectDef &def = getDef(ctx);

	Plugin *plugin = def.getPlugin();
	if(plugin && !plugin->loadPlugin(ctx.dm())) {
		throw RuntimeError(ctx.stack(), "Unable to load pluging for notify type '%s'", def.name());
	}

	NotifyProviderImplFactory *factory = NotifyProviderImplRegistry::instance().getFactory(def);
	if(!factory) {
		throw RuntimeError(ctx.stack(), "Unrecognised notify provider type '%s'", def.name());
	}

	// Verify that all mandatory properties are present and warn of any we won't use
	def.verifyProperties(ctx, m_props);

	// Create an instance of the impl so that we may later execute it - we push
	// the notify's vars so that they can be used during the evaluation of
	// the args/props.
	NotifyProviderImpl *impl = NULL;
	ctx.stack().push(getVars());
	try {
		impl = factory->create(implId, *this, stmt, ctx);
	} catch(...) {
		ctx.stack().pop(NOTIFY_SCOPE);
		throw;
	}
	ctx.stack().pop(NOTIFY_SCOPE);

	if(!impl) {
		throw RuntimeError(ctx.stack(), "Unexpected error creating instance of notify provider '%s'", def.name());
	}
	if(!m_impls) {
		m_impls = new HashtableById<NotifyProviderImpl>(true);
	}
	m_impls->put(implId, impl);

	if(entry) {
		entry->recordInstance(*impl, ctx);
	}
	return impl;
}


class Scope *Notify::getVars()
{
	if(!m_vars) {
		m_vars = new Scope(NOTIFY_SCOPE, this);
		m_vars->addRef();
		m_model.getVariablesForObject(*this, *m_vars);
	}

	return m_vars;
}


Scope *Notify::getVars(
	DMINT32 implId, class ExtendedStmt &stmt, AuditEntry *entry, Context &ctx)
{
	NotifyProviderImpl *impl = m_impls ? m_impls->get(implId) : NULL;
	if(!impl) {
		impl = createImpl(implId, stmt, entry, ctx);
	}
	return impl->getVars();
}


bool Notify::testProvider(class ExtendedStmt &stmt, class Context &ctx)
{
	if(!hasAccess(ctx.dm().getCurrentUser())) {
		throw PermissionDeniedException(ctx.stack(), "No access to test notify '%s'", m_name);
	}

	NotifyProviderImpl *impl = createImpl(1, stmt, NULL, ctx);
	getDef(ctx).verifyArgs(ctx, stmt.getArgs(), m_props);
	return impl->testProvider(ctx);
}


void Notify::notify(
	DMINT32 implId, ExtendedStmt &stmt, AuditEntry *entry, OutputStream &body,
	List<Attachment> *atts, Context &ctx)
{
	NotifyProviderImpl *impl = m_impls ? m_impls->get(implId) : NULL;
	if(!impl) {
		impl = createImpl(implId, stmt, entry, ctx);
	}

	getDef(ctx).verifyArgs(ctx, stmt.getArgs(), m_props);
	impl->notify(stmt, body, atts, ctx);
}


void Notify::print(int ind)
{
	indent(ind); printf("Notify: %s\n", m_name);
	printProviderObject(ind+1);
}


///////////////////////////////////////////////////////////////////////////////
// Datasource
///////////////////////////////////////////////////////////////////////////////

Datasource::Datasource(class Model &model, int id, const char *name)
	: ProviderObject(model, id, name), m_impls(NULL)
{}


Datasource::~Datasource()
{
	SAFE_DELETE(m_impls);
}


DatasourceProviderImpl *Datasource::createImpl(
	DMINT32 implId, ExtendedStmt &stmt, AuditEntry *entry, Context &ctx)
{
	if(!hasAccess(ctx.dm().getCurrentUser())) {
		throw PermissionDeniedException(ctx.stack(), "No access to datasource '%s'", m_name);
	}

	ProviderObjectDef &def = getDef(ctx);

	Plugin *plugin = def.getPlugin();
	if(plugin && !plugin->loadPlugin(ctx.dm())) {
		throw RuntimeError(ctx.stack(), "Unable to load pluging for datasource type '%s'", def.name());
	}

	DatasourceProviderImplFactory *factory = DatasourceProviderImplRegistry::instance().getFactory(def);

	if(!factory) {
		throw RuntimeError(ctx.stack(), "Unrecognised datasource type '%s'", def.name());
	}

	// Verify that all mandatory properties are present and warn of any we won't use
	def.verifyProperties(ctx, m_props);

	// Create an instance of the impl so that we may later execute it
	DatasourceProviderImpl *impl = factory->create(implId, *this, stmt, ctx);
	if(!impl) {
		throw RuntimeError(ctx.stack(), "Unexpected error creating instance of datasource '%s'", def.name());
	}
	if(!m_impls) {
		m_impls = new HashtableById<DatasourceProviderImpl>(true);
	}
	m_impls->put(implId, impl);

	if(entry) {
		entry->recordInstance(*impl, ctx);
	}
	return impl;
}


class Scope *Datasource::getVars()
{
	if(!m_vars) {
		m_vars = new Scope(DATASOURCE_SCOPE, this);
		m_vars->addRef();
		m_model.getVariablesForObject(*this, *m_vars);
	}

	return m_vars;
}


Scope *Datasource::getVars(
	DMINT32 implId, class ExtendedStmt &stmt, AuditEntry *entry, Context &ctx)
{
	DatasourceProviderImpl *impl = m_impls ? m_impls->get(implId) : NULL;
	if(!impl) {
		impl = createImpl(implId, stmt, entry, ctx);
	}
	return impl->getVars();
}


bool Datasource::testProvider(class ExtendedStmt &stmt, class Context &ctx)
{
	if(!hasAccess(ctx.dm().getCurrentUser())) {
		throw PermissionDeniedException(ctx.stack(), "No access to test notify '%s'", m_name);
	}

	DatasourceProviderImpl *impl = createImpl(1, stmt, NULL, ctx);
	getDef(ctx).verifyArgs(ctx, stmt.getArgs(), m_props);
	return impl->testProvider(ctx);
}


void Datasource::query(DMINT32 implId, ExtendedStmt &stmt, AuditEntry *entry, Context &ctx)
{
	DatasourceProviderImpl *impl = m_impls ? m_impls->get(implId) : NULL;
	if(!impl) {
		impl = createImpl(implId, stmt, entry, ctx);
	}

	getDef(ctx).verifyArgs(ctx, stmt.getArgs(), m_props);
	impl->query(stmt, ctx);
}


void Datasource::print(int ind)
{
	indent(ind); printf("Datasource: %s\n", m_name);
	printProviderObject(ind+1);
}


///////////////////////////////////////////////////////////////////////////////
// Task
///////////////////////////////////////////////////////////////////////////////

Task::Task(class Model &model, int id, const char *name, const char *kind)
	: Object(model, id, name), m_taskType(DUP_NULL(kind)), m_impls(NULL),
	  m_preAction(NULL), m_postAction(NULL), m_actionsSet(false)
{}


Task::~Task()
{
	SAFE_FREE(m_taskType);
	SAFE_DELETE(m_impls);
	m_preAction = NULL;		// don't own
	m_postAction = NULL;	// don't own
}


void Task::setActions(Action *preAction, Action *postAction)
{
	m_preAction = preAction;
	m_postAction = postAction;
	m_actionsSet = true;
}


Action *Task::getPreAction()
{
	if(!m_actionsSet) {
		m_model.getActionsForTask(*this);
	}
	return m_preAction;
}


Action *Task::getPostAction()
{
	if(!m_actionsSet) {
		m_model.getActionsForTask(*this);
	}
	return m_postAction;
}


TaskImpl *Task::createImpl(
	DMINT32 implId, ExtendedStmt &stmt, class AuditEntry *entry, Context &ctx)
{
	//if(!hasAccess(ctx.dm().getCurrentUser())) {
	//	throw PermissionDeniedException(ctx.stack(), "No access to task '%s'", m_name);
	//}

	TaskImplFactory *factory = TaskImplRegistry::instance().getFactory(m_taskType);
	if(!factory) {
		throw RuntimeError(ctx.stack(), "Unrecognised task type '%s'", m_taskType);
	}

	// Create an instance of the impl so that we may later execute it
	TaskImpl *impl = factory->create(implId, *this, stmt, ctx);
	if(!impl) {
		throw RuntimeError(ctx.stack(), "Unexpected error creating instance of task '%s'", m_taskType);
	}
	if(!m_impls) {
		m_impls = new HashtableById<TaskImpl>(true);
	}
	m_impls->put(implId, impl);
	return impl;
}


class Scope *Task::getVars()
{
	if(!m_vars) {
		m_vars = new Scope(TASK_SCOPE, this);
		m_vars->addRef();
		//m_model.getVariablesForObject(*this, *m_vars);
	}

	return m_vars;
}


Scope *Task::getVars(
	DMINT32 implId, class ExtendedStmt &stmt, AuditEntry *entry, Context &ctx)
{
	TaskImpl *impl = m_impls ? m_impls->get(implId) : NULL;
	if(!impl) {
		impl = createImpl(implId, stmt, entry, ctx);
	}
	return impl->getVars();
}


int Task::run(DMINT32 implId, ExtendedStmt &stmt, AuditEntry *entry, Context &ctx)
{
	TaskImpl *impl = m_impls ? m_impls->get(implId) : NULL;
	if(!impl) {
		impl = createImpl(implId, stmt, entry, ctx);
	}

	// Run any pre-linked action
	Action *preAction = getPreAction();
	if(preAction) {
		ActionNode *act = preAction->getActionNode(ctx);
		if(act) {
			const char *scopeName = act->isFunction() ? FUNCTION_SCOPE : ACTION_SCOPE;
			Scope *actscope = new Scope(scopeName, act, *act, true);
			ctx.stack().push(actscope);
			try {
				act->execute(ctx);
			} catch(ReturnException &e) {
				if(e.expr() && (e.expr()->toInt() != 0)) {
					ctx.dm().writeToStdOut("Pre-linked action returned %d", e.expr()->toInt());
					ctx.stack().pop(scopeName);
					return 1;
				}
			} catch(...) {
				ctx.stack().pop(scopeName);
				throw;
			}
			ctx.stack().pop(scopeName);
		}
	}

	// Run the task itself - this may do notifications
	int ret = impl->run(stmt, ctx);

	// Run any post-linked action
	Action *postAction = getPostAction();
	if(postAction) {
		ActionNode *act = postAction->getActionNode(ctx);
		if(act) {
			Scope *actscope = new Scope(ACTION_SCOPE, act, *act, true);
			ctx.stack().push(actscope);
			try {
				act->execute(ctx);
			} catch(...) {
				ctx.stack().pop(ACTION_SCOPE);
				throw;
			}
			ctx.stack().pop(ACTION_SCOPE);
		}
	}

	return ret;
}


Domain *Task::getApprovalDomain()
{
	if(strcmp(m_taskType, "approve") != 0) {
		throw RuntimeError("Task %d '%s' is not an approve task", m_id, m_name);
	}
	return m_model.getApprovalDomainForApproveTask(*this);
}


Domain *Task::getTargetDomain()
{
	if((strcmp(m_taskType, "copy") != 0)
		&& (strcmp(m_taskType, "move") != 0)
		&& (strcmp(m_taskType, "createversion") != 0)) {
		throw RuntimeError("Task %d '%s' is not a copy or move task", m_id, m_name);
	}
	return m_model.getTargetDomainForCopyMoveTask(*this);
}


Task *Task::getLinkedTask()
{
	if(strcmp(m_taskType, "request") != 0) {
		throw RuntimeError("Task %d '%s' is not a request task", m_id, m_name);
	}
	return m_model.getLinkedTaskForRequestTask(*this);
}


/*virtual*/ void Task::print(int indent)
{}


///////////////////////////////////////////////////////////////////////////////
// Script
///////////////////////////////////////////////////////////////////////////////

Script::Script(Model &model, int repoid, const char *filepath)
	: m_model(model), m_repoid(repoid), m_filepath(DUP_NULL(filepath)),
	  m_action(NULL), m_textid(0), m_repo(NULL), m_parsed(false), m_checksum(NULL)
{}

Script::Script(Model &model, Action *action, int textid)
	: m_model(model), m_repoid(0), m_filepath(NULL), m_action(action),
	  m_textid(textid), m_repo(NULL), m_parsed(false), m_checksum(NULL)
{}


Script::~Script()
{
	SAFE_FREE(m_filepath);
	m_repo = NULL;				// Owned by cache
	m_action = NULL;			// Owned by cache
	SAFE_FREE(m_checksum);
}


Repository *Script::getRepository()
{
	if(!m_repo) {
		m_model.getRepositoryForScript(*this);
	}
	return m_repo;
}


/*private*/ void Script::setRepository(Repository *repo)
{
	m_repo = repo;
}


Dropzone &Script::getScriptDropzone(Context &ctx)
{
	// Check to see if the dropzone was created in this session
	Dropzone *dz = ctx.dm().getDropzone("tdm_scripts");
	if(!dz) {
		// No, so create it, making sure it is empty
		dz = ctx.dm().newDropzone("tdm_scripts", false);
		if(!dz->create(true)) {
			// Set flag to prevent us trying to delete the non-empty folder when we exit
			putenv(strdup("trinounlink=Y"));
			throw RuntimeError(ctx.stack(), "Unable to create dropzone 'tdm_scripts'");
		}
	}
	return *dz;
}


char *Script::getFileContent(const char *filename)
{
	struct stat sb;
	if(stat(filename, &sb) != 0) {
		fprintf(stderr, "Input file '%s' not found\n", (const char*) filename);
		return NULL;
	}

	int buflen = sb.st_size;
	char *input = (char*) malloc(buflen + 1);
	FILE *f = fopen(filename, "r");
	if(!f) {
		fprintf(stderr, "Error opening '%s'\n", (const char*) filename);
		return NULL;
	}

	int read = fread(input, 1, buflen, f);
	fclose(f);

	if(read == 0) {
		return NULL;
	}

	input[read] = '\0';
	return input;
}


int Script::parse(Action &action, Context &ctx)
{
	if(m_parsed) {
		debug0("Script '%s' has already been parsed", (m_action ? m_action->name() : m_filepath));
		return 0; //1;
	}

	m_parsed = true;

	CharPtr filename;
	char *input = NULL;

	if(m_action) {
		// We are an action stored in the database
		if((m_action->actionKind() == ACTION_KIND_IN_DB) && !m_textid) {
			throw RuntimeError(ctx.stack(), "Text id for action '%s' missing.", m_action->name());
		}

		if(m_action->actionKind() == ACTION_KIND_IN_DB) {
			// Create an input buffer with the action name wrapped around the text
			// pulled from the db
			ConstCharPtr text = m_model.getActionText(m_textid);
			if(!text) {
				throw RuntimeError(ctx.stack(), "Error fetching text for action '%s'", m_action->name());
			}
			ConstCharPtr sig = m_action->getSignature();
			input = (char*) malloc(strlen(sig) + strlen(text) + 10);
			sprintf(input, "%s {\n%s\n}\n", (const char*) sig, (const char*) text);
			filename = strdup(sig);
		} else if(m_action->actionKind() == ACTION_KIND_GRAPHICAL) {
			// Generate a script from the graphical data stored in the database
			Dropzone &dz = getScriptDropzone(ctx);
			AutoPtr<GraphicalScriptGenerator> gen = m_model.createGraphicalScriptGenerator(dz, *m_action);
			if(!gen->generate()) {
				throw RuntimeError(ctx.stack(), "Error generating script for action '%s'", m_action->name());
			}
			filename = strdup(gen->filename());
			debug3("parse generated '%s'...", (const char*) filename);
			if(!(input = getFileContent(filename))) {
				return 1;
			}
		} else {
			throw RuntimeError(ctx.stack(), "Invalid action kind for action '%s'", m_action->name());
		}
	} else {
		// We are a script stored in a repository
		if(!m_repo) {
			getRepository();
		}
		if(!m_repo) {
			throw RuntimeError(ctx.stack(), "Repository for script '%s' not found.", (m_filepath ? m_filepath : "(null)"));
		}

		Dropzone &dz = getScriptDropzone(ctx);
		const char *dropzone = dz.pathname();

		StmtList *args = new StmtList();
		args->add(new Stmt(strdup("pattern"), new Node(KIND_STR, strdup(m_filepath), true)));
		ExtendedStmt dummy(strdup("dummy"), args);

		DropzoneCallback callback(m_repo, 0, dz);
		m_repo->checkout(dz.pathname(), dropzone, dummy, NULL, callback, ctx);
		debug3("Checkout from repository '%s': total: %d; success %d; failed %d",
			m_repo->name(), callback.total(), callback.success(), callback.failed());

		if(callback.success() != 1) {
			throw RuntimeError(ctx.stack(), "Failed to checkout script '%s' from repository '%s'.",
				(m_filepath ? m_filepath : "(null)"), m_repo->name());
		}

		Node nfilepath(NODE_STR, strdup(m_filepath), true);
		ExprPtr efilepath = nfilepath.evaluate(ctx);
		ConstCharPtr filepath = efilepath->stringify();

		filename = (char*) malloc(strlen(dropzone) + strlen((const char*) filepath) + 10);
		sprintf(filename, "%s%s%s", dropzone, DIR_SEP_STR, (const char*) filepath);

		debug3("parse '%s'...", (const char*) filename);
		if(!(input = getFileContent(filename))) {
			return 1;
		}
	}

	// Calculate the checksum of the input text
	m_checksum = digestValue(input, strlen(input), false);
	m_model.getAudit().recordAction(action);

	LexerBuffer lb(action_lexer, input, filename);

	yyparse_param param;
	param.buffer = &lb;

	int res = 1;
	try {
		res = yyparse(&param);
	} catch(...) {
		SAFE_FREE(input);
		throw;
	}

	SAFE_FREE(input);			// we have finished with the input buffer now

	if(res != 0) {
		SAFE_DELETE(param.actnlist);
		if(param.ex) {
			throw *((SyntaxError*) param.ex);
		}
		return 2;
	}

	if(!param.actnlist) {
		return 3;
	}

	if(!getenv("trinosemantic")) {
		try {
			param.actnlist->semanticCheck(ctx.dm());
		} catch(...) {
			SAFE_DELETE(param.actnlist);
			throw;
		}
	}

	m_model.setActionNodes(param.actnlist);
	return 0;
}


void Script::print(int ind)
{
	//indent(ind); printf("Script: %s\n", m_name);
	//printObject(ind+1);
}


///////////////////////////////////////////////////////////////////////////////
// Field
///////////////////////////////////////////////////////////////////////////////

Field::Field(
		class Model &model, int id, const char *name,
		FIELD_KIND kind, const char *querystring
	)
	: m_model(model), m_id(id), m_name(DUP_NULL(name)), m_kind(kind),
	  m_querystring(DUP_NULL(querystring)), m_action(NULL)
{}


Field::~Field()
{
	SAFE_FREE(m_name);
	SAFE_FREE(m_querystring);
	m_action = NULL;	// Owned by cache
}


Action *Field::getAction()
{
	if(!m_action) {
		m_model.getActionForField(*this);
	}
	return m_action;
}


/*private*/ void Field::setAction(Action *action)
{
	m_action = action;
}


void Field::populate(DM &dm)
{
	switch(m_kind) {
	case FIELD_KIND_CHECKBOX: break;
	case FIELD_KIND_COMBO_ARRAY: {
		StringList *values = m_model.getFieldValuesForField(*this);
		if(values) {
			StringListIterator iter(*values);
			for(const char *s = iter.first(); s; s = iter.next()) {
				dm.writeToStdOut("%s", s);
			}
			SAFE_DELETE(values);
		} else {
			dm.writeToStdErr("Failed to get values for field '%s'", (m_name ? m_name : "(null)"));
		}
		}
		break;
	case FIELD_KIND_COMBO_DB: {
		StringList *values = m_model.getFieldValuesForField(m_querystring);
		if(values) {
			StringListIterator iter(*values);
			for(const char *s = iter.first(); s; s = iter.next()) {
				dm.writeToStdOut("%s", s);
			}
			SAFE_DELETE(values);
		} else {
			dm.writeToStdErr("Failed to get values for field '%s'", (m_name ? m_name : "(null)"));
		}
		}
		break;
	case FIELD_KIND_COMBO_ACTION: {
		if(!m_action) {
			getAction();
		}
		if(!m_action) {
			throw RuntimeError("Script for field '%s' not found.", (m_name ? m_name : "(null)"));
		}
		int res = dm.runAction(*m_action);
		}
		break;
	case FIELD_KIND_TEXT: break;
	}
}


///////////////////////////////////////////////////////////////////////////////
// ActionArg
///////////////////////////////////////////////////////////////////////////////

ActionArg::ActionArg(
		const char *name, int pos, bool reqd, bool pad,
		SwitchMode mode, const char *sw, const char *nsw
	)
	: m_name(DUP_NULL(name)), m_position(pos), m_required(reqd),
	  m_pad(pad), m_mode(mode), m_switch(DUP_NULL(sw)), m_negswitch(DUP_NULL(nsw))
{}


ActionArg::~ActionArg()
{
	SAFE_FREE(m_name);
	SAFE_FREE(m_switch);
	SAFE_FREE(m_negswitch);
}


/**
 * Appends switches and values to a parameter list.
 *
 * NONE    - value or pad
 * SWITCH  - switch plus value / neg switch / pad
 * PREFIX  - prefix plus value / neg switch / pad
 * ALWAYS  - switch
 * BOOLEAN - switch / negswitch / pad
 */
void ActionArg::process(const char *val, StringList &params)
{
	switch(m_mode) {
	case SWITCH_MODE_NONE:
		if(val) { params.add(val); return; }
		// fall thru for pad
		break;
	case SWITCH_MODE_SWITCH:
		if(val || m_pad) {
			if(m_switch) { params.add(m_switch); }
			if(val) { params.add(val); return; }
			// fall thru for pad
		} else if(m_negswitch) {
			params.add(m_negswitch);
			return;
		}
		break;
	case SWITCH_MODE_PREFIX:
		if(val || m_pad) {
			if(m_switch && val) {
				CharPtr temp = (char*) malloc(strlen(val) + strlen(m_switch) + 1);
				sprintf(temp, "%s%s", m_switch, val);
				params.add(temp);
				return;
			} else if(val) {
				params.add(val);
				return;
			} else if(m_switch) {
				params.add(m_switch);
				return;
			}
			// fall thru for pad
		} else if(m_negswitch) {
			params.add(m_negswitch);
			return;
		}
		return;
	case SWITCH_MODE_ALWAYS:
		params.add(m_switch ? m_switch : "");
		return;
	case SWITCH_MODE_BOOLEAN:
		if(val) {
			Expr e(val);
			if(e.toBool()) {
				if(m_switch) { params.add(m_switch); return; }
				// fall thru for pad
			} else if(m_negswitch) {
				params.add(m_negswitch);
				return;
			}
		}
		// fall thru for pad
		break;
	}

	if(m_pad) { params.add(""); }
}


///////////////////////////////////////////////////////////////////////////////
// Action
///////////////////////////////////////////////////////////////////////////////


Action::Action(
		Model &model, int id, ACTION_KIND kind, bool isFunction,
		/*bool isRemote,*/ bool copyToRemote, bool resultIsExpr,
		const char *name, const char *filepath
	)
	: Object(model, id, name), m_actkind(kind),
	  m_filepath(DUP_NULL(filepath)), m_isFunction(isFunction),
	  /*m_isRemote(isRemote),*/ m_copyToRemote(copyToRemote),
	  m_resultIsExpr(resultIsExpr), m_plugin(NULL),
	  m_args(NULL), m_actionArgMap(NULL), m_functionArgMap(NULL),
	  m_serverTypeFilepaths(NULL), m_parsed(false), m_script(NULL)
{}


Action::~Action()
{
	SAFE_FREE(m_filepath);
	m_plugin = NULL;	// Owned by cache
	SAFE_DELETE(m_actionArgMap);
	SAFE_DELETE(m_functionArgMap);
	SAFE_DELETE(m_args);
	SAFE_DELETE(m_serverTypeFilepaths);
	m_script = NULL;	// Owned by cache
}


const char *Action::filepath(ServerType &type)
{
	if(!m_serverTypeFilepaths) {
		m_model.getServerTypeFilepathsForAction(*this);
	}

	char key[32];
	sprintf(key, "%d", type.id());
	return m_serverTypeFilepaths->get(key);
}


Hashtable<ActionArg> *Action::getActionArgMap()
{
	if(m_actionArgMap) {
		return m_actionArgMap;
	}
	List<ActionArg> *args = getArgs();
	m_actionArgMap = new Hashtable<ActionArg>(false, false);
	ListIterator<ActionArg> iter(*args);
	for(ActionArg *arg = iter.first(); arg; arg = iter.next()) {
		m_actionArgMap->put(arg->name(), arg);
	}
	return m_actionArgMap;
}


HashtableById<ActionArg> *Action::getFunctionArgMap()
{
	if(m_functionArgMap) {
		return m_functionArgMap;
	}
	List<ActionArg> *args = getArgs();
	m_functionArgMap = new HashtableById<ActionArg>(false);
	ListIterator<ActionArg> iter(*args);
	for(ActionArg *arg = iter.first(); arg; arg = iter.next()) {
		// Only args with an input position go into the map - always is skipped
		if(arg->position() > 0) {
			m_functionArgMap->put(arg->position(), arg);
		}
	}
	return m_functionArgMap;
}


List<ActionArg> *Action::getArgs()
{
	if(m_args) {
		return m_args;
	}

	m_args = new List<ActionArg>(true);
	m_model.getArgsForAction(*this);
	return m_args;
}


void Action::add(ActionArg *arg)
{
	if(!m_args) {
		m_args = new List<ActionArg>(true);
	}
	m_args->add(arg);
}


StringList *Action::mapArgsForFunction(class FunctionNode &func, ExprList *args, Context &ctx, Envp *env /*= NULL*/)
{
	List<ActionArg> *ordargs = getArgs();
	HashtableById<ActionArg> *argmap = getFunctionArgMap();
	int argCount = (args ? args->size() : 0);

	// Count the number of required args
	if(ordargs) {
		int requiredCount = 0;
		ListIterator<ActionArg> oit(*ordargs);
		for(ActionArg *lsca = oit.first(); lsca; lsca = oit.next()) {
			if(lsca->required()) {
				requiredCount++;
			}
		}
		if(argCount < requiredCount) {
			throw RuntimeError(func, ctx.stack(),
				"Function '%s' requires at least %d arguments", m_name, requiredCount);			
		}
	} else if(args) {
		throw RuntimeError(func, ctx.stack(),
			"Function '%s' does not accept arguments", m_name);			
	}

	// Go through provided args and make sure that they are all expected
	for(int n = 1; n <= argCount; n++) {
		ActionArg *arg = argmap ? argmap->get(n) : NULL;
		if(!arg) {
			throw RuntimeError(func, ctx.stack(),
				"Argument %d to function '%s' is unexpected", n, m_name);			
		}
	}

	StringList *params = new StringList();

	// Everything seems okay, go through the args in order
	if(ordargs) {
		Expr **argv = args ? args->toArgv() : NULL;
		ListIterator<ActionArg> oit(*ordargs);
		for(ActionArg *lsca = oit.first(); lsca; lsca = oit.next()) {
			ConstCharPtr val;
			if(!lsca->isAlways()) {
				Expr *expr = (argv && (lsca->position() <= argCount)) ? argv[lsca->position()-1] : NULL;
				val = expr ? expr->toString() : NULL;
			}
			lsca->process(val, *params);
			if(env && val) {
				env->putTri(lsca->name(), val);
			}
		}
	}

	// DEBUG
	//StringListIterator iter(*params);
	//for(const char *p = iter.first(); p; p = iter.next()) {
	//	printf("[%s] ", p);
	//}
	//printf("\n");
	// END DEBUG

	return params;
}


StringList *Action::mapArgsForAction(ExtendedStmt &stmt, Context &ctx, Envp *env /*= NULL*/)
{
	StmtList *args = stmt.getArgs();
	List<ActionArg> *ordargs = getArgs();
	Hashtable<ActionArg> *argmap = getActionArgMap();

	// Go through arg map and make sure we have all required args
	if(argmap) {
		AutoPtr<StringList> keys = argmap->keys();
		StringListIterator kit(*keys);
		for(const char *key = kit.first(); key; key = kit.next()) {
			ActionArg *lsca = argmap->get(key);
			if(lsca && lsca->required()) {
				bool found = false;
				if(args) {
					ListIterator<Stmt> ait(*args);
					for(Stmt *arg = ait.first(); arg; arg = ait.next()) {
						if(strcmp(arg->name(), lsca->name()) == 0) {
							debug3("found required arg '%s' for action '%s'", arg->name(), m_name);
							found = true;
							break;
						}
					}
				}
				if(!found) {
					throw RuntimeError(stmt, ctx.stack(),
							"Required arg '%s' must be specified for action '%s'",
							lsca->name(), m_name);
				}
			}
		}
	}

	// Go through provided args and make sure that they are all expected
	// env indicates a local script - so we need to handle the optional dropzone arg
	if(args) {
		ListIterator<Stmt> ait(*args);
		for(Stmt *arg = ait.first(); arg; arg = ait.next()) {
			ActionArg *lsca = argmap ? argmap->get(arg->name()) : NULL;
			if((!lsca || lsca->isAlways()) && (!env || (strcmp(arg->name(), "dropzone") != 0))) {
				throw RuntimeError(stmt, ctx.stack(),
					"Arg '%s' is unknown for action '%s'",
					arg->name(), m_name);
			}
			debug3("found arg '%s' for action '%s'", arg->name(), m_name);
		}
	}

	StringList *params = new StringList();

	// Everything seems okay, go through the args in order
	if(ordargs) {
		ListIterator<ActionArg> oit(*ordargs);
		for(ActionArg *lsca = oit.first(); lsca; lsca = oit.next()) {
			ConstCharPtr val;
			if(!lsca->isAlways()) {
				val = stmt.getArgAsString(lsca->name(), ctx);
			}
			lsca->process(val, *params);
			if(env && val) {
				env->putTri(lsca->name(), val);
			}
		}
	}

	// DEBUG
	//StringListIterator iter(*params);
	//for(const char *p = iter.first(); p; p = iter.next()) {
	//	printf("[%s] ", p);
	//}
	//printf("\n");
	// END DEBUG

	return params;
}


char *Action::getSignature()
{
	char *ret;

	if(m_isFunction) {
		ret = (char*) malloc(strlen(m_name) + 12);
		sprintf(ret, "function %s(", m_name);

		if(!m_args) {
			getArgs();
		}

		ListIterator<ActionArg> iter(*m_args);
		bool first = true;
		for(ActionArg *aa = iter.first(); aa; aa = iter.next()) {
			ret = (char*) realloc(ret, strlen(ret) + strlen(aa->name()) + 3);
			if(!first) {
				strcat(ret, ",");
			}
			strcat(ret, aa->name());
			first = false;
		}

		strcat(ret, ")");
	} else {
		ret = (char*) malloc(strlen(m_name) + 8);
		sprintf(ret, "action %s", m_name);
	}

	return ret;
}


Script *Action::getScript()
{
	if(!m_script) {
		m_model.getScriptForAction(this);
	}
	return m_script;
}


/*private*/ void Action::setScript(Script *script)
{
	m_script = script;
}


Plugin *Action::getPlugin()
{
	if(!m_plugin) {
		m_model.getPluginForAction(*this);
	}
	return m_plugin;
}


/*private*/ void Action::setPlugin(Plugin *plugin)
{
	m_plugin = plugin;
}


/*private*/ void Action::setServerTypeFilepaths(StringHashtable *filepaths)
{
	m_serverTypeFilepaths = filepaths;
}


int Action::parse(Context &ctx)
{
	switch(m_actkind) {
	case ACTION_KIND_SCRIPT:
	case ACTION_KIND_IN_DB:
	case ACTION_KIND_GRAPHICAL:
		if(!m_parsed) {
			getScript();
			if(!m_script) {
				throw RuntimeError(ctx.stack(), "Failed to find script for action '%s'", m_name);
			}
			return m_script->parse(*this, ctx);
		}
		break;
	case ACTION_KIND_LOCAL_EXTERNAL:
	case ACTION_KIND_REMOTE_EXTERNAL:
	case ACTION_KIND_PLUGIN:
		// Nothing to parse for external script or plugin
		return 0;
	default:
		throw RuntimeError(ctx.stack(), "Unrecognised action kind (%d)", m_actkind);
		break;
	}

	return 0;
}


class ActionNode *Action::getActionNode(Context &ctx)
{
	if(parse(ctx) != 0) {
		return NULL;
	}
	// TODO: Go to the script for the action, rather than the model
	ActionNode *ret = m_model.getActionNode(m_name);
	if(!ret) {
		throw RuntimeError(ctx.stack(), "Failed to find action '%s'", m_name);
	}
	return ret;
}


Action *Action::getCalledAction(int actionid)
{
	return m_model.getAction(actionid);
}


void Action::print(int indent)
{}


///////////////////////////////////////////////////////////////////////////////
// Plugin
///////////////////////////////////////////////////////////////////////////////

Plugin::Plugin(int id, int version, const char *library)
	: m_id(id), m_version(version), m_library(DUP_NULL(library)), m_loaded(false)
{}


Plugin::~Plugin()
{
	SAFE_FREE(m_library);
}


bool Plugin::loadPlugin(class DM &dm)
{
	if(!m_loaded) {
		m_loaded = dm.loadPlugin(m_library);
	}
	return m_loaded;
}


///////////////////////////////////////////////////////////////////////////////
// PluginObject
///////////////////////////////////////////////////////////////////////////////

PluginObject::PluginObject()
{}


/*virtual*/ PluginObject::~PluginObject()
{}


///////////////////////////////////////////////////////////////////////////////
// RepositoryTextPattern
///////////////////////////////////////////////////////////////////////////////

RepositoryTextPattern::RepositoryTextPattern(
		const char *path, const char *pattern, bool text
	)
	: m_path(DUP_NULL(path)), m_pattern(DUP_NULL(pattern)), m_text(text)
{}


RepositoryTextPattern::~RepositoryTextPattern()
{
	SAFE_FREE(m_path);
	SAFE_FREE(m_pattern);
}


///////////////////////////////////////////////////////////////////////////////
// RepositoryIgnorePattern
///////////////////////////////////////////////////////////////////////////////

RepositoryIgnorePattern::RepositoryIgnorePattern(
		const char *pattern, bool isDir
	)
	: m_pattern(DUP_NULL(pattern)), m_isDir(isDir), m_re(NULL)
{}


RepositoryIgnorePattern::~RepositoryIgnorePattern()
{
	SAFE_FREE(m_pattern);
	SAFE_DELETE(m_re);
}


bool RepositoryIgnorePattern::matches(const char *filepath, bool isDir)
{
	//printf("RepositoryIgnorePattern::matches('%s', %s)\n", filepath, (isDir ? "true" : "false"));
	if(isDir != m_isDir) {
		return false;
	}
	if(!m_re) {
		// may raise and exception
		m_re = new RegExpWrapper(m_pattern, true);
	}
	return m_re->match(filepath) ? true : false;
}


///////////////////////////////////////////////////////////////////////////////
// Model
///////////////////////////////////////////////////////////////////////////////

Model::Model(class triODBC &odbc, const char *engineHostname)
	: m_odbc(odbc), m_engineHostname(DUP_NULL(engineHostname)),
	  m_config(NULL), m_envs(NULL), m_apps(NULL), m_audit(NULL),
	  m_scrCache(false, true), m_pluginObjects(false, true),
	  m_actionNodes(NULL), m_currentUser(NULL)
{
	m_deploymentStartTime = time(NULL);
	debug1("Deployment started at %d", m_deploymentStartTime);

	AutoPtr<triSQL> sql = m_odbc.GetSQL();
	SQLRETURN res = sql->PrepareStatement("SELECT e.id FROM dm_engine e "
		"WHERE lower(e.hostname)=lower(?) AND e.status = 'N'");
	if(IS_NOT_SQL_SUCCESS(res)) {
		throw RuntimeError("Failed to lookup engine id");
	}
	int hostnamelen = m_engineHostname ? strlen(m_engineHostname) : 0;
	sql->BindParameter(1, SQL_CHAR, hostnamelen, (char*) m_engineHostname, hostnamelen);
	int engineId = 0;
	sql->BindColumn(1, SQL_INTEGER, &engineId, sizeof(engineId));
	res = sql->Execute();
	if(res != SQL_SUCCESS) {
		sql->CloseSQL();
		throw RuntimeError("Failed to find engine id for host '%s'", m_engineHostname);
	}
	res = sql->FetchRow();
	if(IS_NOT_SQL_SUCCESS(res)) {
		sql->CloseSQL();
		throw RuntimeError("Failed to find engine id for host '%s'", m_engineHostname);
	}
	debug1("Engine id is %d", engineId);
	m_engineId = engineId;
	sql->CloseSQL();
}


Model::~Model()
{
	SAFE_DELETE(m_envs);		// not set as owner so will just delete list (envCache is owner)
	SAFE_DELETE(m_apps);		// not set as owner so will just delete list (appCache is owner)
	SAFE_DELETE(m_actionNodes);	// ActionList has a destructor
	m_currentUser = NULL;		// Owned by cache
	SAFE_DELETE(m_audit);
}


class EngineConfig &Model::getEngineConfig()
{
	if(m_config) {
		return *m_config;
	}

	m_config = new EngineConfig();

	AutoPtr<triSQL> sql = m_odbc.GetSQL();
	char name[DB_NAME_LEN];
	char value[DB_VARVAL_LEN];
	sql->BindColumn(1, SQL_CHAR, name, sizeof(name));
	sql->BindColumn(2, SQL_CHAR, value, sizeof(value));
	SQLRETURN res = sql->ExecuteSQL("SELECT c.name, c.value FROM dm_engineconfig c WHERE c.engineid=%d", m_engineId);
	if(IS_NOT_SQL_SUCCESS(res)) {
		throw RuntimeError("Failed to get engine config");
	}
	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		debug0("Engine config: '%s' -> '%s'", name, value);
		m_config->put(name, value);
	}
	sql->CloseSQL();
	return *m_config;
}


List<Environment> *Model::internalGetEnvironments(const char *whereClause, bool checkDomain)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int id = 0;
	char envName[DB_NAME_LEN];
	char envBasedir[DB_PATH_LEN];
	SQLLEN ni_envBasedir = 0;

	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));
	sql->BindColumn(2, SQL_CHAR, envName, sizeof(envName));
	sql->BindColumn(3, SQL_CHAR, envBasedir, sizeof(envBasedir), &ni_envBasedir);

	// If checkDomain is set, limit the domain of the environment to those the user can see
	CharPtr domainClause;
	if(checkDomain) {
		const char *domains = m_currentUser ? m_currentUser->getAccessibleDomains() : NULL;
		if(domains) {
			domainClause = (char*) malloc(strlen(domains) + 25);
			sprintf(domainClause, " AND e.domainid in (%s)", domains);
		}
	}

	int res = sql->ExecuteSQL("select e.id, e.name, e.basedir "
		"from dm_environment e where e.status = 'N' "
		"%s%s%s", (whereClause ? "and " : ""), (whereClause ? whereClause : ""),
		(!domainClause.isNull() ? (const char*) domainClause : ""));
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	List<Environment> *ret = new List<Environment>();

	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		Environment *env = findOrCreateEnvironment(id, envName, NULL_IND(envBasedir, NULL));
		ret->add(env);
	}

	return ret;
}


List<Server> *Model::internalGetServers(const char *fromClause, const char *whereClause)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int id = 0;
	char serverName[DB_NAME_LEN];
	char serverHostname[DB_HOSTNAME_LEN];
	char serverProtocol[65];
	char serverBasedir[DB_PATH_LEN];
	int stid = 0;
	char serverHosttype[DB_NAME_LEN];
	LINE_END_FORMAT lineends = (LINE_END_FORMAT) 0;
	char pathformat[DB_NAME_LEN];
	SQLLEN ni_serverHostname = 0, ni_serverProtocol = 0,
		ni_serverBasedir = 0, ni_stid = 0, ni_serverHosttype = 0,
		ni_lineends = 0, ni_pathformat = 0;

	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));
	sql->BindColumn(2, SQL_CHAR, serverName, sizeof(serverName));
	sql->BindColumn(3, SQL_CHAR, serverHostname, sizeof(serverHostname), &ni_serverHostname);
	sql->BindColumn(4, SQL_CHAR, serverProtocol, sizeof(serverProtocol), &ni_serverProtocol);
	sql->BindColumn(5, SQL_CHAR, serverBasedir, sizeof(serverBasedir), &ni_serverBasedir);
	sql->BindColumn(6, SQL_INTEGER, &stid, sizeof(stid), &ni_stid);
	sql->BindColumn(7, SQL_CHAR, serverHosttype, sizeof(serverHosttype), &ni_serverHosttype);
	sql->BindColumn(8, SQL_INTEGER, &lineends, sizeof(lineends), &ni_lineends);
	sql->BindColumn(9, SQL_CHAR, pathformat, sizeof(pathformat), &ni_pathformat);

	int res = sql->ExecuteSQL(
			"select s.id, s.name, s.hostname, s.protocol, s.basedir, "
			" st.id, st.name, st.lineends, st.pathformat "
			"from (dm_server s left join dm_servertype st on s.typeid = st.id) %s%s "
			"where s.status = 'N' %s%s",
			(fromClause ? ", " : ""), (fromClause ? fromClause : ""),
			(whereClause ? "and " : ""), (whereClause ? whereClause : ""));
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	List<Server> *ret = new List<Server>();

	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		ServerType *st = findOrCreateServerType(
			NULL_IND(stid, 0), NULL_IND(serverHosttype, NULL),
			NULL_IND(lineends, LINE_ENDS_OFF), NULL_IND(pathformat, NULL));
		Server *srv = findOrCreateServer(
			id, serverName, NULL_IND(serverHostname, NULL),
			NULL_IND(serverProtocol, NULL), NULL_IND(serverBasedir, NULL), st);
		ret->add(srv);
	}

	return ret;
}


List<Domain> *Model::internalGetDomains(const char *fromClause, const char *whereClause)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int id = 0;
	char domainName[DB_NAME_LEN];

	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));
	sql->BindColumn(2, SQL_CHAR, domainName, sizeof(domainName));

	int res = sql->ExecuteSQL("select d.id, d.name "
			"from dm_domain d %s%s where d.status = 'N' %s%s",
			(fromClause ? ", " : ""), (fromClause ? fromClause : ""),
			(whereClause ? "and " : ""), (whereClause ? whereClause : ""));
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	List<Domain> *ret = new List<Domain>();

	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		Domain *domain = findOrCreateDomain(id, domainName);
		ret->add(domain);
	}

	return ret;
}


List<Application> *Model::internalGetApplications(const char *fromClause, const char *whereClause, bool checkDomain)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int id = 0;
	char appName[DB_NAME_LEN];
	char appVers[DB_NAME_LEN];
	int parentid = 0;
	SQLLEN ni_appVers = 0, ni_parentid = 0;

	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));
	sql->BindColumn(2, SQL_CHAR, appName, sizeof(appName));
	sql->BindColumn(3, SQL_CHAR, appVers, sizeof(appVers), &ni_appVers);
	sql->BindColumn(4, SQL_INTEGER, &parentid, sizeof(parentid), &ni_parentid);

	// If checkDomain is set, limit the domain of the environment to those the user can see
	CharPtr domainClause;
	if(checkDomain) {
		const char *domains = m_currentUser ? m_currentUser->getAccessibleDomains() : NULL;
		if(domains) {
			domainClause = (char*) malloc(strlen(domains) + 25);
			sprintf(domainClause, " and a.domainid in (%s)", domains);
		}
	}

	int res = sql->ExecuteSQL("select a.id, a.name, a.version, a.parentid "
		"from dm_application a %s%s where a.status = 'N' %s%s%s",
		(fromClause ? ", " : ""), (fromClause ? fromClause : ""),
		(whereClause ? "and " : ""), (whereClause ? whereClause : ""),
		(!domainClause.isNull() ? (const char*) domainClause : ""));
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	List<Application> *ret = new List<Application>(false);

	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		Application *app = NULL;
		if(NULL_IND(parentid, 0)) {
			// Retrieve the parent
			char clause[1024];
			sprintf(clause, "a.id = %d", parentid);
			AutoPtr<List<Application> > matches = internalGetApplications(NULL, clause, false);
			if(matches) {
				ListIterator<Application> mit(*matches);
				Application *parent = mit.first();
				if(parent) {
					app = findOrCreateApplicationVersion(id, appName, NULL_IND(appVers, NULL), parent);
				} else {
					debug0("Failed to get parent application with id %d", parentid);
				}
			} else {
				debug0("Parent application query failed");
			}
		} else {
			app = findOrCreateApplication(id, appName);
		}

		if(app) {
			ret->add(app);
		}
	}

	sql->CloseSQL();

	return ret;
}


List<Component> *Model::internalGetComponents(const char *fromClause, const char *whereClause)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int id = 0;
	char compName[DB_NAME_LEN];
	char baseDir[DB_PATH_LEN];
	int rollup;
	int rollback;
	char filterItems[DB_BOOL_LEN];
	SQLLEN ni_baseDir = 0, ni_rollup = 0, ni_rollback = 0, ni_filterItems = 0;

	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));
	sql->BindColumn(2, SQL_CHAR, compName, sizeof(compName));
	sql->BindColumn(3, SQL_CHAR, baseDir, sizeof(baseDir),&ni_baseDir);
	sql->BindColumn(4, SQL_INTEGER, &rollup, sizeof(rollup), &ni_rollup);
	sql->BindColumn(5, SQL_INTEGER, &rollback, sizeof(rollback), &ni_rollback);
	sql->BindColumn(6, SQL_CHAR, filterItems, sizeof(filterItems), &ni_filterItems);

	int res = sql->ExecuteSQL(
		"select c.id, c.name, c.basedir, c.rollup, c.rollback, c.filteritems "
		"from dm_component c %s%s where c.status = 'N' %s%s",
		(fromClause ? ", " : ""), (fromClause ? fromClause : ""),
		(whereClause ? "and " : ""), (whereClause ? whereClause : ""));
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	List<Component> *ret = new List<Component>(false);

	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		Component *comp = findOrCreateComponent(
			id, compName, NULL_IND(baseDir,NULL), (ComponentFilter) NULL_IND(rollup, false),
			(ComponentFilter) NULL_IND(rollback, false),
			BOOL_NULL_IND(filterItems, false));
		ret->add(comp);
	}

	return ret;
}


List<User> *Model::internalGetUsers(
	const char *fromClause, const char *whereClause, bool checkDomain)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int id = 0;
	char userName[DB_NAME_LEN];
	char userEmail[DB_EMAIL_LEN];
	char realName[DB_NAME_LEN];
	char userPhone[DB_PHONE_LEN];
	SQLLEN ni_userEmail = 0, ni_realName = 0, ni_userPhone = 0;

	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));
	sql->BindColumn(2, SQL_CHAR, userName, sizeof(userName));
	sql->BindColumn(3, SQL_CHAR, userEmail, sizeof(userEmail), &ni_userEmail);
	sql->BindColumn(4, SQL_CHAR, realName, sizeof(realName), &ni_realName);
	sql->BindColumn(5, SQL_CHAR, userPhone, sizeof(userPhone), &ni_userPhone);

	// If checkDomain is set, limit the domain of the environment to those the user can see
	CharPtr domainClause;
	if(checkDomain) {
		const char *domains = m_currentUser ? m_currentUser->getAccessibleDomains() : NULL;
		if(domains) {
			domainClause = (char*) malloc(strlen(domains) + 25);
			sprintf(domainClause, " and u.domainid in (%s)", domains);
		}
	}

	int res = sql->ExecuteSQL("select u.id, u.name, u.email, u.realname, u.phone "
		"from dm_user u %s%s where u.status = 'N' %s%s%s",
		(fromClause ? ", " : ""), (fromClause ? fromClause : ""),
		(whereClause ? "and " : ""), (whereClause ? whereClause : ""),
		(!domainClause.isNull() ? (const char*) domainClause : ""));
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	List<User> *ret = new List<User>(false);

	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		User *user = findOrCreateUser(id, userName, NULL_IND(userEmail, NULL),
			NULL_IND(realName, NULL), NULL_IND(userPhone,NULL));
		ret->add(user);
	}

	return ret;
}


List<UserGroup> *Model::internalGetUserGroups(
	const char *fromClause, const char *whereClause, bool checkDomain)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int id = 0;
	char groupName[DB_NAME_LEN];
	char groupEmail[DB_EMAIL_LEN];
	SQLLEN ni_groupEmail = 0;

	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));
	sql->BindColumn(2, SQL_CHAR, groupName, sizeof(groupName));
	sql->BindColumn(3, SQL_CHAR, groupEmail, sizeof(groupEmail), &ni_groupEmail);

	// If checkDomain is set, limit the domain of the environment to those the user can see
	CharPtr domainClause;
	if(checkDomain) {
		const char *domains = m_currentUser ? m_currentUser->getAccessibleDomains() : NULL;
		if(domains) {
			domainClause = (char*) malloc(strlen(domains) + 25);
			sprintf(domainClause, " and g.domainid in (%s)", domains);
		}
	}

	int res = sql->ExecuteSQL("select g.id, g.name, g.email "
		"from dm_usergroup g %s%s where g.status = 'N' %s%s%s",
		(fromClause ? ", " : ""), (fromClause ? fromClause : ""),
		(whereClause ? "and " : ""), (whereClause ? whereClause : ""),
		(!domainClause.isNull() ? (const char*) domainClause : ""));
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	List<UserGroup> *ret = new List<UserGroup>(false);

	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		UserGroup *group = findOrCreateUserGroup(id, groupName, NULL_IND(groupEmail, NULL));
		ret->add(group);
	}

	return ret;
}


Credentials *Model::internalGetCredentials(const char *fromClause, const char *whereClause)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int id = 0;
	char name[DB_NAME_LEN];
	CREDENTIALS_KIND kind;
	char encusername[2049];
	char encpassword[2049];
	char filename[DB_PATH_LEN];
	SQLLEN ni_name = 0, ni_encusername = 0, ni_encpassword = 0, ni_filename = 0;

	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));
	sql->BindColumn(2, SQL_CHAR, name, sizeof(name), &ni_name);
	sql->BindColumn(3, SQL_INTEGER, &kind, sizeof(kind));
	sql->BindColumn(4, SQL_CHAR, encusername, sizeof(encusername), &ni_encusername);
	sql->BindColumn(5, SQL_CHAR, encpassword, sizeof(encpassword), &ni_encpassword);
	sql->BindColumn(6, SQL_CHAR, filename, sizeof(filename), &ni_filename);

	int res = sql->ExecuteSQL("select c.id, c.name, c.kind, c.encusername, c.encpassword, c.filename "
			"from %s t, dm_credentials c where c.id = t.credid and %s ",
			fromClause, whereClause);
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	res = sql->FetchRow();
	if(IS_SQL_SUCCESS(res)) {
		return findOrCreateCredentials(id, NULL_IND(name, NULL), kind,
			NULL_IND(encusername, NULL), NULL_IND(encpassword, NULL),
			NULL_IND(filename, NULL));
	}

	return NULL;
}


Action *Model::internalGetAction(const char *fromClause, const char *whereClause, bool checkDomain)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int id = 0;
	char name[DB_NAME_LEN];
	ACTION_KIND kind;
	char filepath[DB_PATH_LEN];
	int textid = 0;
	int repoid = 0;
	char isFunc[DB_BOOL_LEN];
	//char isRemote[DB_BOOL_LEN];
	char copyToRemote[DB_BOOL_LEN];
	char resIsExpr[DB_BOOL_LEN];
	int pluginid = 0;
	//char isGraphical[DB_BOOL_LEN];
	SQLLEN ni_name = 0, ni_filepath = 0, ni_textid = 0,
		ni_repoid = 0, /*ni_isRemote = 0,*/ ni_copyToRemote = 0,
		ni_resIsExpr = 0, ni_pluginid = 0 /*, ni_isGraphical = 0*/;

	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));
	sql->BindColumn(2, SQL_CHAR, name, sizeof(name), &ni_name);
	sql->BindColumn(3, SQL_INTEGER, &kind, sizeof(kind));
	sql->BindColumn(4, SQL_CHAR, filepath, sizeof(filepath), &ni_filepath);
	sql->BindColumn(5, SQL_INTEGER, &textid, sizeof(textid), &ni_textid);
	sql->BindColumn(6, SQL_INTEGER, &repoid, sizeof(repoid), &ni_repoid);
	sql->BindColumn(7, SQL_CHAR, isFunc, sizeof(isFunc));
	//sql->BindColumn(7, SQL_CHAR, isRemote, sizeof(isRemote), &ni_isRemote);
	sql->BindColumn(8, SQL_CHAR, copyToRemote, sizeof(copyToRemote), &ni_copyToRemote);
	sql->BindColumn(9, SQL_CHAR, resIsExpr, sizeof(resIsExpr), &ni_resIsExpr);
	sql->BindColumn(10, SQL_INTEGER, &pluginid, sizeof(pluginid), &ni_pluginid);
	//sql->BindColumn(11, SQL_CHAR, isGraphical, sizeof(isGraphical), &ni_isGraphical);

	// If checkDomain is set, limit the domain of the environment to those the user can see
	CharPtr domainClause;
	if(checkDomain) {
		const char *domains = m_currentUser ? m_currentUser->getAccessibleDomains() : NULL;
		if(domains) {
			domainClause = (char*) malloc(strlen(domains) + 25);
			sprintf(domainClause, " %s a.domainid in (%s)",
				(whereClause ? "and" : "where"), domains);
		}
	}

	int res = sql->ExecuteSQL(
		"select a.id, a.name, a.kind, a.filepath, a.textid, a.repositoryid, "
		" a.function, a.copy, a.resultisexpr, a.pluginid "	// a.remote, a.graphical
		"from dm_action a %s%s where a.status = 'N' %s%s%s",
		(fromClause ? ", " : ""), (fromClause ? fromClause : ""),
		(whereClause ? "and " : ""), (whereClause ? whereClause : ""),
		(!domainClause.isNull() ? (const char*) domainClause : ""));
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	res = sql->FetchRow();
	if(IS_SQL_SUCCESS(res)) {
		//ACTION_KIND kind;
		//if(BOOL_NULL_IND(isGraphical, false)) {
		//	kind = ACTION_KIND_GRAPHICAL;
		//} else if(NULL_IND(repoid, 0)) {
		//	kind = ACTION_KIND_SCRIPT;
		//} else if(NULL_IND(textid, 0)) {
		//	kind = ACTION_KIND_IN_DB;
		//} else if(NULL_IND(pluginid, 0)) {
		//	kind = ACTION_KIND_PLUGIN;
		//} else {
		//	kind = ACTION_KIND_EXTERNAL;
		//}

		return findOrCreateAction(
			id, kind, ((isFunc[0] == 'Y') ? true : false),
			//BOOL_NULL_IND(isRemote, false),
			BOOL_NULL_IND(copyToRemote, false),
			BOOL_NULL_IND(resIsExpr, false),
			NULL_IND(name, NULL), NULL_IND(filepath, NULL));
	}

	return NULL;
}


List<Property> *Model::internalGetProperties(const char *table, const char *fk, int id, const char *fk2, int id2)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	char propName[DB_NAME_LEN];
	char propValue[DB_VARVAL_LEN];
	char propEnc[DB_BOOL_LEN];
	char propOver[DB_BOOL_LEN];
	char propApnd[DB_BOOL_LEN];
	SQLLEN ni_propValue = 0, ni_propEnc = 0, ni_propOver = 0, ni_propApnd = 0;

	sql->BindColumn(1, SQL_CHAR, propName, sizeof(propName));
	sql->BindColumn(2, SQL_CHAR, propValue, sizeof(propValue), &ni_propValue);
	sql->BindColumn(3, SQL_CHAR, propEnc, sizeof(propEnc), &ni_propEnc);
	sql->BindColumn(4, SQL_CHAR, propOver, sizeof(propOver), &ni_propOver);
	sql->BindColumn(5, SQL_CHAR, propApnd, sizeof(propApnd), &ni_propApnd);

	int res;
	if(fk2) {
		res = sql->ExecuteSQL("select p.name, p.value, p.encrypted, "
				"p.overridable, p.appendable "
				"from %sprops p where p.%s = %d and p.%s = %d ", table, fk, id, fk2, id2);
	} else {
		res = sql->ExecuteSQL("select p.name, p.value, p.encrypted, "
				"p.overridable, p.appendable "
				"from %sprops p where p.%s = %d ", table, fk, id);
	}
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	List<Property> *ret = new List<Property>();

	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		ret->add(new Property(propName,
			NULL_IND(propValue, NULL), BOOL_NULL_IND(propEnc, false),
			BOOL_NULL_IND(propOver, false), BOOL_NULL_IND(propApnd, false)));
	}

	return ret;
}


List<Environment> *Model::getEnvironments()
{
	if(m_envs) {
		return m_envs;
	}
	m_envs = internalGetEnvironments(NULL, true);
	return m_envs;
}


List<Application> *Model::getApplications()
{
	if(m_apps) {
		return m_apps;
	}
	m_apps = internalGetApplications(NULL, NULL, true);
	return m_apps;
}


Environment *Model::getEnvironment(const char *name)
{
	// Have we already got this environment
	Environment *ret = m_envCache.get(name);
	if(ret) { return ret; }

	char *nameLit = triSQL::EscapeLiteral(name);
	char whereClause[2100];
	sprintf(whereClause, "e.name = %s", nameLit);
	SAFE_FREE(nameLit);

	AutoPtr<List<Environment> > matches = internalGetEnvironments(whereClause, true);
	if(matches && (matches->size() > 0)) {
		ListIterator<Environment> iter(*matches);
		ret = iter.first();
	}

	return ret;
}


Environment *Model::getEnvironment(int id)
{
	// Have we already got this environment
	Environment *ret = m_envCache.get(id);
	if(ret) { return ret; }

	char whereClause[2100];
	sprintf(whereClause, "e.id = %d", id);

	AutoPtr<List<Environment> > matches = internalGetEnvironments(whereClause, true);
	if(matches && (matches->size() > 0)) {
		ListIterator<Environment> iter(*matches);
		ret = iter.first();
	}

	return ret;
}


Application *Model::getApplication(const char *name)
{
	// Have we already got this application
	Application *ret = m_appCache.get(name);
	if(ret) { return ret; }

	char *nameLit = triSQL::EscapeLiteral(name);
	char whereClause[2100];
	sprintf(whereClause, "a.name = %s", nameLit);
	SAFE_FREE(nameLit);

	AutoPtr<List<Application> > matches = internalGetApplications(NULL, whereClause, true);
	if(matches && (matches->size() > 0)) {
		ListIterator<Application> iter(*matches);
		ret = iter.first();
	}

	return ret;
}


Application *Model::getApplication(int id)
{
	// Have we already got this application
	Application *ret = m_appCache.get(id);
	if(ret) { return ret; }

	char whereClause[2100];
	sprintf(whereClause, "a.id = %d", id);

	AutoPtr<List<Application> > matches = internalGetApplications(NULL, whereClause, true);
	if(matches && (matches->size() > 0)) {
		ListIterator<Application> iter(*matches);
		ret = iter.first();
	}

	return ret;
}


Component *Model::getComponent(const char *name)
{
	// Have we already got this component
	Component *ret = m_comCache.get(name);
	if(ret) { return ret; }

	char *nameLit = triSQL::EscapeLiteral(name);
	char whereClause[2100];
	sprintf(whereClause, "c.name = %s", nameLit);
	SAFE_FREE(nameLit);

	AutoPtr<List<Component> > matches = internalGetComponents(NULL, whereClause);
	if(matches && (matches->size() > 0)) {
		ListIterator<Component> iter(*matches);
		ret = iter.first();
	}

	return ret;
}


User *Model::getUser(const char *name)
{
	// Have we already got this user
	User *ret = m_usrCache.get(name);
	if(ret) { return ret; }

	char *nameLit = triSQL::EscapeLiteral(name);
	char whereClause[1024];
	sprintf(whereClause, "u.name = %s", nameLit);
	SAFE_FREE(nameLit);

	AutoPtr<List<User> > matches = internalGetUsers(NULL, whereClause, true);
	if(matches && (matches->size() > 0)) {
		ListIterator<User> iter(*matches);
		ret = iter.first();
	}

	return ret;
}


User *Model::getUser(int id)
{
	// Have we already got this user
	User *ret = m_usrCache.get(id);
	if(ret) { return ret; }

	char whereClause[1024];
	sprintf(whereClause, "u.id = %d", id);

	AutoPtr<List<User> > matches = internalGetUsers(NULL, whereClause, true);
	if(matches && (matches->size() > 0)) {
		ListIterator<User> iter(*matches);
		ret = iter.first();
	}

	return ret;
}


UserGroup *Model::getUserGroup(int id)
{
	// Have we already got this user group
	UserGroup *ret = m_usgCache.get(id);
	if(ret) { return ret; }

	char whereClause[1024];
	sprintf(whereClause, "g.id = %d", id);

	AutoPtr<List<UserGroup> > matches = internalGetUserGroups(NULL, whereClause, true);
	if(matches && (matches->size() > 0)) {
		ListIterator<UserGroup> iter(*matches);
		ret = iter.first();
	}

	return ret;
}


Repository *Model::getRepository(const char *name)
{
	// Have we already got this repository
	Repository *ret = m_repCache.get(name);
	if(ret) { return ret; }

	char *nameLit = triSQL::EscapeLiteral(name);
	char whereClause[1024];
	sprintf(whereClause, "t.name = %s", nameLit);
	SAFE_FREE(nameLit);

	AutoPtr<List<Repository> > matches = internalGetProviderObjects<Repository>(
		m_repCache, NULL, whereClause, true);
	if(matches && (matches->size() > 0)) {
		ListIterator<Repository> iter(*matches);
		ret = iter.first();
	}

	return ret;
}


Repository *Model::getRepository(int id)
{
	// Have we already got this repository
	Repository *ret = m_repCache.get(id);
	if(ret) { return ret; }

	char whereClause[1024];
	sprintf(whereClause, "t.id = %d", id);

	AutoPtr<List<Repository> > matches = internalGetProviderObjects<Repository>(
		m_repCache, NULL, whereClause, true);
	if(matches && (matches->size() > 0)) {
		ListIterator<Repository> iter(*matches);
		ret = iter.first();
	}

	return ret;
}


Notify *Model::getNotifier(const char *name)
{
	// Have we already got this notifier
	Notify *ret = m_nfyCache.get(name);
	if(ret) { return ret; }

	char *nameLit = triSQL::EscapeLiteral(name);
	char whereClause[1024];
	sprintf(whereClause, "t.name = %s", nameLit);
	SAFE_FREE(nameLit);

	AutoPtr<List<Notify> > matches = internalGetProviderObjects<Notify>(
		m_nfyCache, NULL, whereClause, true);
	if(matches && (matches->size() > 0)) {
		ListIterator<Notify> iter(*matches);
		ret = iter.first();
	}

	return ret;
}


Notify *Model::getNotifier(int id)
{
	// Have we already got this notifier
	Notify *ret = m_nfyCache.get(id);
	if(ret) { return ret; }

	char whereClause[1024];
	sprintf(whereClause, "t.id = %d", id);

	AutoPtr<List<Notify> > matches = internalGetProviderObjects<Notify>(
		m_nfyCache, NULL, whereClause, true);
	if(matches && (matches->size() > 0)) {
		ListIterator<Notify> iter(*matches);
		ret = iter.first();
	}

	return ret;
}


Datasource *Model::getDatasource(const char *name)
{
	// Have we already got this datasource
	Datasource *ret = m_datCache.get(name);
	if(ret) { return ret; }

	char *nameLit = triSQL::EscapeLiteral(name);
	char whereClause[1024];
	sprintf(whereClause, "t.name = %s", nameLit);
	SAFE_FREE(nameLit);

	AutoPtr<List<Datasource> > matches = internalGetProviderObjects<Datasource>(
		m_datCache, NULL, whereClause, true);
	if(matches && (matches->size() > 0)) {
		ListIterator<Datasource> iter(*matches);
		ret = iter.first();
	}

	return ret;
}


Datasource *Model::getDatasource(int id)
{
	// Have we already got this datasource
	Datasource *ret = m_datCache.get(id);
	if(ret) { return ret; }

	char whereClause[1024];
	sprintf(whereClause, "t.id = %d", id);

	AutoPtr<List<Datasource> > matches = internalGetProviderObjects<Datasource>(
		m_datCache, NULL, whereClause, true);
	if(matches && (matches->size() > 0)) {
		ListIterator<Datasource> iter(*matches);
		ret = iter.first();
	}

	return ret;
}


Field *Model::getField(const char *name)
{
	// Have we already got this field
	Field *ret = m_fldCache.get(name);
	if(ret) { return ret; }

	AutoPtr<triSQL> sql = m_odbc.GetSQL();
	char *nameLit = triSQL::EscapeLiteral(name);

	int id = 0;
	char fldName[DB_NAME_LEN];
	FIELD_KIND fldKind = (FIELD_KIND) 0;
	char fldQueryString[DB_QUERY_LEN];
	SQLLEN ni_fldQueryString = 0;

	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));
	sql->BindColumn(2, SQL_CHAR, fldName, sizeof(fldName));
	sql->BindColumn(3, SQL_INTEGER, &fldKind, sizeof(fldKind));
	sql->BindColumn(4, SQL_CHAR, fldQueryString, sizeof(fldQueryString), &ni_fldQueryString);

	int res = sql->ExecuteSQL("select f.id, f.name, f.type, f.querystring "
			"from dm_field f where f.name = %s ", nameLit);
	if(IS_NOT_SQL_SUCCESS(res)) {
		SAFE_FREE(nameLit);
		return NULL;
	}

	SAFE_FREE(nameLit);

	res = sql->FetchRow();
	if(IS_SQL_SUCCESS(res)) {
		ret = new Field(*this, id, fldName, fldKind,
			NULL_IND(fldQueryString, NULL));
		m_fldCache.put(ret);
		return ret;
	}

	return NULL;
}


StringList *Model::getFieldValuesForField(Field &field)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	char fldValue[129];
	sql->BindColumn(1, SQL_CHAR, fldValue, sizeof(fldValue));

	int res = sql->ExecuteSQL("select fv.fieldvalue "
			"from dm_fieldvalues fv where fv.fieldid = %d "
			"order by fv.positionid ", field.id());
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	StringList *ret = new StringList();

	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		ret->add(fldValue);
	}

	return ret;
}


StringList *Model::getFieldValuesForField(const char *querystring)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	// TODO: This may need to be dynamic
	char fldValue[129];
	sql->BindColumn(1, SQL_CHAR, fldValue, sizeof(fldValue));

	int res = sql->ExecuteSQL(querystring);
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	StringList *ret = new StringList();

	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		ret->add(fldValue);
	}

	return ret;
}


void Model::getRepositoryForScript(Script &script)
{
	char whereClause[1024];
	sprintf(whereClause, "t.id = %d", script.repoid());

	AutoPtr<List<Repository> > matches = internalGetProviderObjects<Repository>(
		m_repCache, NULL, whereClause, false);
	if(matches && (matches->size() > 0)) {
		ListIterator<Repository> iter(*matches);
		script.setRepository(iter.first());
	}
}


GraphicalScriptGenerator *Model::createGraphicalScriptGenerator(Dropzone &dz, Action &action) {
	return new GraphicalScriptGenerator(m_odbc, dz, action);
}


Action *Model::getAction(const char *name)
{
	Action *ret = m_actCache.get(name);
	if(ret) {
		return ret;
	}

	char *nameLit = triSQL::EscapeLiteral(name);

	char whereClause[1024];
	sprintf(whereClause, "a.name = %s", nameLit);
	ret = internalGetAction(NULL, whereClause, true);
	SAFE_FREE(nameLit);
	return ret;
}


Action *Model::getAction(int id)
{
	Action *ret = m_actCache.get(id);
	if(ret) {
		return ret;
	}

	char whereClause[1024];
	sprintf(whereClause, "a.id = %d", id);
	ret = internalGetAction(NULL, whereClause, true);
	return ret;
}


SwitchMode decodeSwitchMode(const char *mode)
{
	if(mode) {
		switch(mode[0]) {
		case 'S': return SWITCH_MODE_SWITCH;
		case 'P': return SWITCH_MODE_PREFIX;
		case 'A': return SWITCH_MODE_ALWAYS;
		case 'B': return SWITCH_MODE_BOOLEAN;
		}
	}
	return SWITCH_MODE_NONE;
}


void Model::getArgsForAction(Action &action)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	char argName[DB_NAME_LEN];
	int argPos = 0;
	char argReqd[DB_BOOL_LEN];
	char argPad[DB_BOOL_LEN];
	char argMode[DB_BOOL_LEN];
	char argSwitch[DB_NAME_LEN];
	char argNegSwitch[DB_NAME_LEN];
	SQLLEN ni_argPos = 0, ni_argReqd = 0, ni_argMode = 0,
		ni_argSwitch = 0, ni_argNegSwitch = 0;

	sql->BindColumn(1, SQL_CHAR, argName, sizeof(argName));
	sql->BindColumn(2, SQL_INTEGER, &argPos, sizeof(argPos), &ni_argPos);
	sql->BindColumn(3, SQL_CHAR, argReqd, sizeof(argReqd), &ni_argReqd);
	sql->BindColumn(4, SQL_CHAR, argPad, sizeof(argPad));
	sql->BindColumn(5, SQL_CHAR, argMode, sizeof(argMode), &ni_argMode);
	sql->BindColumn(6, SQL_CHAR, argSwitch, sizeof(argSwitch), &ni_argSwitch);
	sql->BindColumn(7, SQL_CHAR, argNegSwitch, sizeof(argNegSwitch), &ni_argNegSwitch);

	int res = sql->ExecuteSQL(
			"select aa.name, aa.inpos, aa.required, aa.pad, "
			"  aa.switchmode, aa.switch, aa.negswitch "
			"from dm_actionarg aa "
			"where aa.actionid = %d order by aa.outpos ", action.id());
	if(IS_NOT_SQL_SUCCESS(res)) {
		return;
	}

	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		action.add(new ActionArg(argName, NULL_IND(argPos, -1), BOOL_NULL_IND(argReqd, false),
			((argPad[0] == 'Y') ? true : false), decodeSwitchMode(NULL_IND(argMode, NULL)),
			NULL_IND(argSwitch, NULL), NULL_IND(argNegSwitch, NULL)));
	}	
}


void Model::getScriptForAction(Action *action)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	char filepath[DB_PATH_LEN];
	int textid = 0;
	int repoid = 0;
	SQLLEN ni_filepath = 0, ni_textid = 0, ni_repoid = 0;

	sql->BindColumn(1, SQL_CHAR, filepath, sizeof(filepath), &ni_filepath);
	sql->BindColumn(2, SQL_INTEGER, &textid, sizeof(textid), &ni_textid);
	sql->BindColumn(3, SQL_INTEGER, &repoid, sizeof(repoid), &ni_repoid);

	int res = sql->ExecuteSQL("select a.filepath, a.textid, a.repositoryid "
			"from dm_action a where a.id = %d and a.status = 'N' ", action->id());
	if(IS_NOT_SQL_SUCCESS(res)) {
		return;
	}

	res = sql->FetchRow();
	if(IS_SQL_SUCCESS(res)) {
		switch(action->actionKind()) {
		case ACTION_KIND_SCRIPT: {
			Script *script = findOrCreateScript(repoid, NULL_IND(filepath, NULL));
			action->setScript(script);
			}
			break;
		case ACTION_KIND_IN_DB:
		case ACTION_KIND_GRAPHICAL: {
			Script *script = findOrCreateScript(action, NULL_IND(textid, 0));
			action->setScript(script);
			}
			break;
		}
	}
}


char *Model::getActionText(int textid)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int id;
	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));	// we don't need this, but we need to call BindColumn

	int res = sql->ExecuteSQL(
		"select at.id, at.data from dm_actiontext at where at.id = %d ", textid);
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	char *ret = NULL;
	res = sql->FetchRow();
	if(IS_SQL_SUCCESS(res)) {
		char *data = NULL;
		SQLLEN ni_data = 0;

		res = sql->GetData(2, SQL_C_BINARY, &data, 0, &ni_data);
		if(IS_SQL_SUCCESS(res)) {
			//debug0("Action text length: %d", ni_data);
			// Get all the data at once.
			data = (char*) malloc(ni_data + 2);
			res = sql->GetData(2, SQL_C_DEFAULT, data, ni_data + 1, &ni_data);
			if(IS_SQL_SUCCESS(res)) {
				ret = data;
				//debug0("Action text is: %s", data);
			}
		}
	}

	sql->CloseSQL();
	return ret;
}


void Model::getPluginForAction(Action &act)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int id = 0;
	int version = 0;
	char library[256];
	SQLLEN ni_library = 0;

	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));
	sql->BindColumn(2, SQL_INTEGER, &version, sizeof(version));
	sql->BindColumn(3, SQL_CHAR, library, sizeof(library), &ni_library);

	int res = sql->ExecuteSQL(
		"select p.id, p.version, p.library from dm_action a, dm_plugin p "
		"where p.id = a.pluginid and a.id = %d ", act.id());
	if(IS_NOT_SQL_SUCCESS(res)) {
		return;
	}

	res = sql->FetchRow();
	if(IS_SQL_SUCCESS(res)) {
		Plugin *plugin = findOrCreatePlugin(id, version,
			NULL_IND(library, NULL));
		act.setPlugin(plugin);
	}
}


void Model::getServerTypeFilepathsForAction(Action &act)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int servertypeid = 0;
	char filepath[DB_PATH_LEN];

	sql->BindColumn(1, SQL_INTEGER, &servertypeid, sizeof(servertypeid));
	sql->BindColumn(2, SQL_CHAR, filepath, sizeof(filepath));

	int res = sql->ExecuteSQL(
		"select af.typeid, af.filepath from dm_actionfilepath af "
		"where af.actionid = %d ", act.id());
	if(IS_NOT_SQL_SUCCESS(res)) {
		return;
	}

	StringHashtable *filepaths = new StringHashtable();

	res = sql->FetchRow();
	if(IS_SQL_SUCCESS(res)) {
		char key[32];
		sprintf(key, "%d", servertypeid);
		filepaths->put(key, filepath);
	}

	act.setServerTypeFilepaths(filepaths);
}


Task *Model::getTask(const char *name)
{
	// Have we already got this task
	Task *ret = m_tskCache.get(name);
	if(ret) { return ret; }

	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	char *nameLit = triSQL::EscapeLiteral(name);

	int id;
	char taskName[DB_NAME_LEN];
	char taskKind[DB_NAME_LEN];

	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));
	sql->BindColumn(2, SQL_CHAR, taskName, sizeof(taskName));
	sql->BindColumn(3, SQL_CHAR, taskKind, sizeof(taskKind));

	int res = sql->ExecuteSQL("select t.id, t.name, lower(tt.name) "
			"from dm_task t, dm_tasktypes tt where t.name = %s AND tt.id = t.typeid", nameLit);
	if(IS_NOT_SQL_SUCCESS(res)) {
		SAFE_FREE(nameLit);
		return NULL;
	}

	SAFE_FREE(nameLit);

	res = sql->FetchRow();
	if(IS_SQL_SUCCESS(res)) {
		ret = findOrCreateTask(id, taskName, taskKind);
		return ret;
	}

	return NULL;
}


Task *Model::getTask(int id)
{
	// Have we already got this task
	Task *ret = m_tskCache.get(id);
	if(ret) { return ret; }

	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	char taskName[DB_NAME_LEN];
	char taskKind[DB_NAME_LEN];

	sql->BindColumn(1, SQL_CHAR, taskName, sizeof(taskName));
	sql->BindColumn(2, SQL_CHAR, taskKind, sizeof(taskKind));

	int res = sql->ExecuteSQL("select t.name, lower(tt.name) "
			"from dm_task t, dm_tasktypes tt where t.id = %d AND tt.id = t.typeid", id);
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	res = sql->FetchRow();
	if(IS_SQL_SUCCESS(res)) {
		ret = findOrCreateTask(id, taskName, taskKind);
		return ret;
	}

	return NULL;
}


void Model::getActionsForTask(Task &task)
{
	char whereClause[1024];

	sprintf(whereClause, "t.id = %d and a.id = t.preactionid", task.id());
	Action *preAction = internalGetAction("dm_task t", whereClause, false);

	sprintf(whereClause, "t.id = %d and a.id = t.postactionid", task.id());
	Action *postAction = internalGetAction("dm_task t", whereClause, false);

	task.setActions(preAction, postAction);
}


Domain *Model::getApprovalDomainForApproveTask(Task &task)
{
	char whereClause[1024];
	sprintf(whereClause, "at.id = %d and d.id = at.approvaldomain", task.id());

	List<Domain> *matches = internalGetDomains("dm_taskapprove at", whereClause);
	if(matches) {
		ListIterator<Domain> iter(*matches);
		return iter.first();
	}

	return NULL;
}


Domain *Model::getTargetDomainForCopyMoveTask(Task &task)
{
	char fromClause[256], whereClause[1024];
	sprintf(fromClause, "dm_task%s cmt", task.taskType());
	sprintf(whereClause, "cmt.id = %d and d.id = cmt.targetdomain", task.id());

	List<Domain> *matches = internalGetDomains(fromClause, whereClause);
	if(matches) {
		ListIterator<Domain> iter(*matches);
		return iter.first();
	}

	return NULL;
}


Task *Model::getLinkedTaskForRequestTask(Task &task)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int linkedTaskId;
	char linkedTaskName[DB_NAME_LEN];
	char linkedTaskKind[DB_NAME_LEN];

	sql->BindColumn(1, SQL_INTEGER, &linkedTaskId, sizeof(linkedTaskId));
	sql->BindColumn(1, SQL_CHAR, linkedTaskName, sizeof(linkedTaskName));
	sql->BindColumn(2, SQL_CHAR, linkedTaskKind, sizeof(linkedTaskKind));

	int res = sql->ExecuteSQL("select lt.id, lt.name, lower(tt.name) "
			"from dm_taskrequest rt, dm_task lt, dm_tasktypes tt "
			"where rt.id = %d AND lt.id = rt.linkedtaskid AND tt.id = lt.typeid", task.id());
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	res = sql->FetchRow();
	if(IS_SQL_SUCCESS(res)) {
		return findOrCreateTask(linkedTaskId, linkedTaskName, linkedTaskKind);
	}

	return NULL;
}


bool Model::approveApplication(
	Application &app, Domain &tgtDomain, bool approve, const char *note)
{
	debug0("%s application %d for domain %d",
		(approve ? "Approving" : "Rejecting"), app.id(), tgtDomain.id());

	if(!m_currentUser) {
		debug0("Current user not set");
		return false;
	}

	long id = getNextObjectId("approval");
	if(id == 0) {
		return false;
	}

	long appid = app.id();
	long domid = tgtDomain.id();
	long when = time(NULL);
	long userid = m_currentUser->id();
	const char *approved = approve ? "Y" : "N";
	int notelen = note ? strlen(note) : 0;

	AutoPtr<triSQL> sql = m_odbc.GetSQL();
	SQLRETURN res = sql->PrepareStatement(
		"INSERT INTO dm_approval("
		"  id, appid, domainid, \"when\", userid, approved, note) VALUES (?,?,?,?,?,?,?)");
	if(IS_NOT_SQL_SUCCESS(res)) {
		debug0("Failed to insert approval entry");
		return false;
	}
	sql->BindParameter(1, SQL_INTEGER, sizeof(id), &id, sizeof(id));
	sql->BindParameter(2, SQL_INTEGER, sizeof(appid), &appid, sizeof(appid));
	sql->BindParameter(3, SQL_INTEGER, sizeof(domid), &domid, sizeof(domid));
	sql->BindParameter(4, SQL_INTEGER, sizeof(when), &when, sizeof(when));
	sql->BindParameter(5, SQL_INTEGER, sizeof(userid), &userid, sizeof(userid));
	sql->BindParameter(6, SQL_CHAR, 1, (char*) approved, 1);
	sql->BindParameter(7, SQL_CHAR, notelen, (char*) note, notelen);
	res = sql->Execute();
	if(IS_NOT_SQL_SUCCESS(res)) {
		debug0("Failed to insert approval entry (2)");
		sql->CloseSQL();
		return false;
	}
	sql->CloseSQL();
	return true;
}


bool Model::moveApplication(
	Application &app, Domain &tgtDomain, const char *note)
{
	debug0("Moving application %d to domain %d", app.id(), tgtDomain.id());

	if(!m_currentUser) {
		debug0("Current user not set");
		return false;
	}

	// TODO: Check that the application is currently approved for this domain

	long modified = time(NULL);
	long modifierid = m_currentUser->id();
	long domid = tgtDomain.id();
	long appid = app.id();

	AutoPtr<triSQL> sql = m_odbc.GetSQL();
	SQLRETURN res = sql->PrepareStatement(
		"UPDATE dm_application "
		" SET modified = ?, modifierid = ?, domainid = ? "
		" WHERE id = ?");
	if(IS_NOT_SQL_SUCCESS(res)) {
		debug0("Failed to update application entry");
		return false;
	}
	sql->BindParameter(1, SQL_INTEGER, sizeof(modified), &modified, sizeof(modified));
	sql->BindParameter(2, SQL_INTEGER, sizeof(modifierid), &modifierid, sizeof(modifierid));
	sql->BindParameter(3, SQL_INTEGER, sizeof(domid), &domid, sizeof(domid));
	sql->BindParameter(4, SQL_INTEGER, sizeof(appid), &appid, sizeof(appid));

	res = sql->Execute();
	if(IS_NOT_SQL_SUCCESS(res)) {
		debug0("Failed to update application entry (2)");
		sql->CloseSQL();
		return false;
	}
	sql->CloseSQL();

	sql = m_odbc.GetSQL();

	// Record an entry to say that we moved the application
	long id = getNextObjectId("historynote");
	if(id == 0) {
		return false;
	}

	long kind = OBJ_KIND_APPLICATION;
	int notelen = note ? strlen(note) : 0;
	const char *icon = "movever";

	res = sql->PrepareStatement(
		"INSERT INTO dm_historynote(id, objid, kind, \"when\", note, userid, icon) VALUES(?, ?, ?, ?, ?, ?, ?)");
	if(IS_NOT_SQL_SUCCESS(res)) {
		debug0("Failed to insert history note entry");
		return false;
	}
	sql->BindParameter(1, SQL_INTEGER, sizeof(id), &id, sizeof(id));
	sql->BindParameter(2, SQL_INTEGER, sizeof(appid), &appid, sizeof(appid));
	sql->BindParameter(3, SQL_INTEGER, sizeof(kind), &kind, sizeof(kind));
	sql->BindParameter(4, SQL_INTEGER, sizeof(modified), &modified, sizeof(modified));
	sql->BindParameter(5, SQL_CHAR, notelen, (char*) note, notelen);
	sql->BindParameter(6, SQL_INTEGER, sizeof(modifierid), &modifierid, sizeof(modifierid));
	sql->BindParameter(7, SQL_CHAR, strlen(icon), (char*) icon, strlen(icon));
	res = sql->Execute();
	if(IS_NOT_SQL_SUCCESS(res)) {
		debug0("Failed to insert history note entry (2)");
		sql->CloseSQL();
		return false;
	}
	sql->CloseSQL();
	return true;
}


#define BOX_WIDTH  120
#define BOX_HEIGHT 50


ApplicationVersion* Model::newVersionOfApplication(
	Application &app, Domain &tgtDomain, Application *predecessor)
{
	debug0("Creating new version of application %d in domain %d", app.id(), tgtDomain.id());

	if(!m_currentUser) {
		debug0("Current user not set");
		return false;
	}

	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	long appid = app.id();
	long predid = predecessor ? predecessor->id() : appid;

	// Count of children
	long c = 0;
	SQLRETURN res = sql->PrepareStatement(
		"SELECT count(*) FROM dm_application a WHERE a.parentid=?");
	if(IS_NOT_SQL_SUCCESS(res)) {
		debug0("Failed to get count of application versions");
		return NULL;
	}
	sql->BindParameter(1, SQL_INTEGER, sizeof(appid), &appid, sizeof(appid));
	sql->BindColumn(1, SQL_INTEGER, &c, sizeof(c));

	res = sql->Execute();
	if(IS_SQL_SUCCESS(res)) {
		res = sql->FetchRow();
	}
	if(IS_NOT_SQL_SUCCESS(res)) {
		c = 0;
	}
	sql->CloseSQL();

	int xpos = 0, ypos = 0;

	if(predecessor) {
		// Coords of predecessor
		SQLLEN ni_xpos = 0, ni_ypos = 0;
		res = sql->PrepareStatement(
			"SELECT a.xpos, a.ypos FROM dm_application a WHERE a.id = ?");
		if(IS_NOT_SQL_SUCCESS(res)) {
			debug0("Failed to get coords of application version");
			return NULL;
		}
		sql->BindParameter(1, SQL_INTEGER, sizeof(predid), &predid, sizeof(predid));
		sql->BindColumn(1, SQL_INTEGER, &xpos, sizeof(xpos), &ni_xpos);
		sql->BindColumn(2, SQL_INTEGER, &ypos, sizeof(ypos), &ni_ypos);

		res = sql->Execute();
		if(IS_SQL_SUCCESS(res)) {
			res = sql->FetchRow();
		}
		if(IS_NOT_SQL_SUCCESS(res)) {
			xpos = 0;
			ypos = 0;
		}
		sql->CloseSQL();

		// Max xpos of predecessors children
		int maxxpos = 0;
		SQLLEN ni_maxxpos = 0;
		res = sql->PrepareStatement(
			"SELECT max(a.xpos) FROM dm_application a WHERE a.predecessorid=?");
		if(IS_NOT_SQL_SUCCESS(res)) {
			debug0("Failed to get max xpos of application versions");
			return NULL;
		}
		sql->BindParameter(1, SQL_INTEGER, sizeof(predid), &predid, sizeof(predid));
		sql->BindColumn(1, SQL_INTEGER, &maxxpos, sizeof(maxxpos), &ni_maxxpos);

		res = sql->Execute();
		if(IS_SQL_SUCCESS(res)) {
			res = sql->FetchRow();
		}
		if(IS_NOT_SQL_SUCCESS(res)) {
			maxxpos = 0;
		}
		sql->CloseSQL();

		if(maxxpos > 0) {
			xpos = maxxpos + BOX_WIDTH*1.5;
		}
	}

	ypos += BOX_HEIGHT*2;

	char newName[DB_NAME_LEN];
	sprintf(newName, "%s;%d", app.name(), c+1);

	long newid = getNextObjectId("application");
	long domid = tgtDomain.id();
	long now = time(NULL);
	long userid = m_currentUser->id();

	res = sql->PrepareStatement(
		"INSERT INTO dm_application("
		"  id,name,domainid,ownerid,creatorid,modifierid,created,modified,"
		"  parentid,predecessorid,xpos,ypos,status) "
		"VALUES(?,?,?,?,?,?,?,?,?,?,?,?,'N')");
	if(IS_NOT_SQL_SUCCESS(res)) {
		debug0("Failed to insert application version");
		return NULL;
	}
	sql->BindParameter( 1, SQL_INTEGER, sizeof(newid), &newid, sizeof(newid));
	sql->BindParameter( 2, SQL_CHAR,    strlen(newName), newName, strlen(newName));
	sql->BindParameter( 3, SQL_INTEGER, sizeof(domid), &domid, sizeof(domid));
	sql->BindParameter( 4, SQL_INTEGER, sizeof(userid), &userid, sizeof(userid));
	sql->BindParameter( 5, SQL_INTEGER, sizeof(userid), &userid, sizeof(userid));
	sql->BindParameter( 6, SQL_INTEGER, sizeof(userid), &userid, sizeof(userid));
	sql->BindParameter( 7, SQL_INTEGER, sizeof(now), &now, sizeof(now));
	sql->BindParameter( 8, SQL_INTEGER, sizeof(now), &now, sizeof(now));
	sql->BindParameter( 9, SQL_INTEGER, sizeof(appid), &appid, sizeof(appid));
	sql->BindParameter(10, SQL_INTEGER, sizeof(predid), &predid, sizeof(predid));
	sql->BindParameter(11, SQL_INTEGER, sizeof(xpos), &xpos, sizeof(xpos));
	sql->BindParameter(12, SQL_INTEGER, sizeof(ypos), &ypos, sizeof(ypos));
	res = sql->Execute();
	if(IS_NOT_SQL_SUCCESS(res)) {
		debug0("Failed to insert application version (2)");
		return NULL;
	}
	sql->CloseSQL();

	// Set any custom action
	Action *custact = app.getCustomAction();
	if(custact) {
		long actionid = custact->id();
		res = sql->PrepareStatement("UPDATE dm_application SET actionid = ? WHERE id = ?");
		if(IS_NOT_SQL_SUCCESS(res)) {
			debug0("Failed to update application version action");
			return NULL;
		}
		sql->BindParameter(1, SQL_INTEGER, sizeof(xpos), &actionid, sizeof(actionid));
		sql->BindParameter(2, SQL_INTEGER, sizeof(newid), &newid, sizeof(newid));
		res = sql->Execute();
		if(IS_NOT_SQL_SUCCESS(res)) {
			debug0("Failed to update application version action (2)");
			return NULL;
		}
		sql->CloseSQL();
	}

	// Set any pre-action
	Action *preact = app.getPreAction();
	if(preact) {
		long actionid = preact->id();
		res = sql->PrepareStatement("UPDATE dm_application SET preactionid = ? WHERE id = ?");
		if(IS_NOT_SQL_SUCCESS(res)) {
			debug0("Failed to update application version preaction");
			return NULL;
		}
		sql->BindParameter(1, SQL_INTEGER, sizeof(xpos), &actionid, sizeof(actionid));
		sql->BindParameter(2, SQL_INTEGER, sizeof(newid), &newid, sizeof(newid));
		res = sql->Execute();
		if(IS_NOT_SQL_SUCCESS(res)) {
			debug0("Failed to update application version preaction (2)");
			return NULL;
		}
		sql->CloseSQL();
	}

	// Set any post-action
	Action *postact = app.getPostAction();
	if(postact) {
		long actionid = preact->id();
		res = sql->PrepareStatement("UPDATE dm_application SET postactionid = ? WHERE id = ?");
		if(IS_NOT_SQL_SUCCESS(res)) {
			debug0("Failed to update application version postaction");
			return NULL;
		}
		sql->BindParameter(1, SQL_INTEGER, sizeof(xpos), &actionid, sizeof(actionid));
		sql->BindParameter(2, SQL_INTEGER, sizeof(newid), &newid, sizeof(newid));
		res = sql->Execute();
		if(IS_NOT_SQL_SUCCESS(res)) {
			debug0("Failed to update application version postaction (2)");
			return NULL;
		}
		sql->CloseSQL();
	}

	// Add the components from the predecessor
	res = sql->PrepareStatement(
		"INSERT INTO dm_applicationcomponent(appid,compid,xpos,ypos) "
		"SELECT ?,compid,xpos,ypos FROM dm_applicationcomponent WHERE appid=?");
	if(IS_NOT_SQL_SUCCESS(res)) {
		debug0("Failed to copy components to application version");
	} else {
		sql->BindParameter(1, SQL_INTEGER, sizeof(newid), &newid, sizeof(newid));
		sql->BindParameter(2, SQL_INTEGER, sizeof(predid), &predid, sizeof(predid));
		res = sql->Execute();
		if(IS_NOT_SQL_SUCCESS(res)) {
			debug0("Failed to copy components to application version (2)");
		}
	}
	sql->CloseSQL();

	// Add the component flows from the predecessor
	res = sql->PrepareStatement(
		"INSERT INTO dm_applicationcomponentflows(appid,compfrom,compto) "
		"SELECT ?,compfrom,compto FROM dm_applicationcomponentflows WHERE appid=?");
	if(IS_NOT_SQL_SUCCESS(res)) {
		debug0("Failed to copy component flows to application version");
	} else {
		sql->BindParameter(1, SQL_INTEGER, sizeof(newid), &newid, sizeof(newid));
		sql->BindParameter(2, SQL_INTEGER, sizeof(predid), &predid, sizeof(predid));
		res = sql->Execute();
		if(IS_NOT_SQL_SUCCESS(res)) {
			debug0("Failed to copy component flows to application version (2)");
		}
	}
	sql->CloseSQL();

	debug0("New Application Version is %d '%s'", newid, newName);
	return findOrCreateApplicationVersion(newid, newName, newName, (Application*) app.toObject());
}


ApplicationVersion* Model::getLatestVersionOfApplication(Application &app /*, branch*/)
{
	char whereClause[2100];
	sprintf(whereClause,
		"a.id = (select max(a2.id) from dm_application a2 "
		"where a2.parentid = %d)", app.id());

	AutoPtr<List<Application> > matches = internalGetApplications(NULL, whereClause, true);
	if(matches && (matches->size() > 0)) {
		ListIterator<Application> iter(*matches);
		Application *ret = iter.first();
		return ret ? ret->toApplicationVersion() : NULL;
	}

	return NULL;
}


void Model::recordAppInEnv(class DM &dm, Application &app, Environment &env, bool success)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	SQLRETURN res = sql->PrepareStatement(
		"UPDATE dm_appsinenv SET appid = ?, deploymentid = ? "
		"WHERE envid = ? AND appid IN (SELECT a.id FROM dm_application a, dm_application b "
		"WHERE (a.parentid = b.parentid OR a.id = b.parentid OR a.parentid = b.id OR a.id = b.id) AND b.id = ?)");
	if(IS_NOT_SQL_SUCCESS(res)) {
		throw RuntimeError("Failed to update app in env");
	}
	long appid = app.id();
	long deployid = dm.deployId();
	long envid = env.id();
	sql->BindParameter(1, SQL_INTEGER, sizeof(appid), &appid, sizeof(appid));
	sql->BindParameter(2, SQL_INTEGER, sizeof(deployid), &deployid, sizeof(deployid));
	sql->BindParameter(3, SQL_INTEGER, sizeof(envid), &envid, sizeof(envid));
	sql->BindParameter(4, SQL_INTEGER, sizeof(appid), &appid, sizeof(appid));
	debug1("Updating appsinenv (%d, %d, %d)", appid, envid, deployid);
	res = sql->ExecuteIgnoringErrors();
	debug2("res = %d", res);
	sql->CloseSQL();
	if(IS_NOT_SQL_SUCCESS(res)) {
		if((res != SQL_ERROR) && (res != SQL_NO_DATA)) {
			throw RuntimeError("Failed to update app in env (2), %d", res);
		}
		res = sql->PrepareStatement(
			"INSERT INTO dm_appsinenv(envid, appid, deploymentid) VALUES(?,?,?)");
		if(IS_NOT_SQL_SUCCESS(res)) {
			throw RuntimeError("Failed to insert app in env");
		}
		sql->BindParameter(1, SQL_INTEGER, sizeof(envid), &envid, sizeof(envid));
		sql->BindParameter(2, SQL_INTEGER, sizeof(appid), &appid, sizeof(appid));
		sql->BindParameter(3, SQL_INTEGER, sizeof(deployid), &deployid, sizeof(deployid));
		debug1("Inserting into appsinenv (%d, %d, %d)", appid, envid, deployid);
		res = sql->Execute();
		debug2("res = %d", res);
		sql->CloseSQL();
		if(IS_NOT_SQL_SUCCESS(res)) {
			throw RuntimeError("Failed to insert app in env (2)");
		}
	}
}


void Model::recordCompOnServ(class DM &dm, Component &comp, Server &server, bool success)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	SQLRETURN res = sql->PrepareStatement(
		"UPDATE dm_compsonserv SET compid = ?, deploymentid = ? "
		"WHERE serverid = ? AND compid IN (SELECT a.id FROM dm_component a, dm_component b "
		"WHERE (a.parentid = b.parentid OR a.id = b.parentid OR a.parentid = b.id OR a.id = b.id) AND b.id = ?)");
	if(IS_NOT_SQL_SUCCESS(res)) {
		throw RuntimeError("Failed to update comp on serv");
	}
	long compid = comp.id();
	long deployid = dm.deployId();
	long serverid = server.id();
	sql->BindParameter(1, SQL_INTEGER, sizeof(compid), &compid, sizeof(compid));
	sql->BindParameter(2, SQL_INTEGER, sizeof(deployid), &deployid, sizeof(deployid));
	sql->BindParameter(3, SQL_INTEGER, sizeof(serverid), &serverid, sizeof(serverid));
	sql->BindParameter(4, SQL_INTEGER, sizeof(compid), &compid, sizeof(compid));
	debug1("Updating compsonserv (%d, %d, %d)", compid, serverid, deployid);
	res = sql->ExecuteIgnoringErrors();
	debug2("res = %d", res);
	sql->CloseSQL();
	if(IS_NOT_SQL_SUCCESS(res)) {
		if((res != SQL_ERROR) && (res != SQL_NO_DATA)) {
			throw RuntimeError("Failed to update comp on serv (2), %d", res);
		}
		res = sql->PrepareStatement(
			"INSERT INTO dm_compsonserv(serverid, compid, deploymentid) VALUES(?,?,?)");
		if(IS_NOT_SQL_SUCCESS(res)) {
			throw RuntimeError("Failed to insert comp on serv");
		}
		sql->BindParameter(1, SQL_INTEGER, sizeof(serverid), &serverid, sizeof(serverid));
		sql->BindParameter(2, SQL_INTEGER, sizeof(compid), &compid, sizeof(compid));
		sql->BindParameter(3, SQL_INTEGER, sizeof(deployid), &deployid, sizeof(deployid));
		debug1("Inserting into compsonserv (%d, %d, %d)", compid, serverid, deployid);
		res = sql->Execute();
		debug2("res = %d", res);
		sql->CloseSQL();
		if(IS_NOT_SQL_SUCCESS(res)) {
			throw RuntimeError("Failed to insert comp on serv (2)");
		}
	}
}


/*private*/ void Model::setCurrentUser(User *user)
{
	m_currentUser = user;
}


User *Model::getCurrentUser()
{
	return m_currentUser;
}


void Model::updateUserLastLogin(User &user)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();
	sql->ExecuteSQL("update dm_user "
		"set lastlogin = now() "
		"where id = %d ", user.id());
}


Audit &Model::getAudit()
{
	if(!m_currentUser) {
		throw RuntimeError("Current user not set - can't deploy");
	}

	if(!m_audit) {
		m_audit = new DatabaseAudit(m_currentUser->id(), m_odbc);
	}

	return *m_audit;
}


Audit &Model::getDummyAudit()
{
	if(!m_audit) {
		m_audit = new Audit();
	}

	return *m_audit;
}


/**
 * Validate the given user's password hash.  To avoid sending the actual hash
 * value across the wire, we query for a match against the hash that we have
 * calculated from the supplied password.  Whilst this might expose how we hash
 * the passwords, it means sniffing the wire whilst attempting a login does not
 * give away the actual password hash, only the hash of what has been entered.
 */
bool Model::validateHashedPassword(User &user, const char *passhash)
{
	char *passhashLit = triSQL::EscapeLiteral(passhash);

	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int id = 0;
	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));

	int res = sql->ExecuteSQL(
			"select u.id from dm_user u "
			"where u.id = %d and u.passhash = %s and u.status = 'N' ",
			user.id(), passhashLit);
	if(IS_NOT_SQL_SUCCESS(res)) {
		SAFE_FREE(passhashLit);
		return false;
	}

	SAFE_FREE(passhashLit);

	sql->FetchRow();
	if(IS_SQL_SUCCESS(res)) {
		return (id == user.id());
	}

	return false;
}


int Model::getNextObjectId(const char *objectType)
{
	// Convert objectType to lowercase
	CharPtr key = strdup(objectType);
	for(char *x = key; *x; x++) { *x = tolower(*x); }

	AutoPtr<triSQL> sql = m_odbc.GetSQL();
	sql->SetAutoCommitMode(false);

	long objectId = 0;
	sql->BindColumn(1, SQL_INTEGER, &objectId, sizeof(objectId));

	// Lock the row in our id table so that we can update it
	SQLRETURN res = sql->ExecuteSQL(
		"SELECT id FROM dm_keys WHERE lower(object)='%s' FOR UPDATE",
		(const char*) key);
	if(IS_SQL_SUCCESS(res)) {
		res = sql->FetchRow();
		if(IS_SQL_SUCCESS(res)) {
			objectId++;
			char stmt[256];
			// Increment the id in the table
			AutoPtr<triSQL> upsql = m_odbc.GetSQL();
			sprintf(stmt, "UPDATE dm_keys SET id=%d WHERE lower(object)='%s'",
				objectId, (const char*) key);
			res = upsql->ExecuteSQL(stmt);

			if(IS_SQL_SUCCESS(res)) {
				// Release the lock
				res = sql->EndTransaction(true);
				sql->CloseSQL();
				upsql->CloseSQL();
				sql->SetAutoCommitMode(true);

				if(IS_SQL_SUCCESS(res)) {
					return objectId;
				} else {
					throw RuntimeError("EndTransaction failed");
				}
			} else {
				throw RuntimeError("Update failed");
			}
		} else  {
			// Key does not exist - create it
			AutoPtr<triSQL> maxsql = m_odbc.GetSQL();
			maxsql->BindColumn(1, SQL_INTEGER, &objectId, sizeof(objectId));
			res = maxsql->ExecuteSQL(
				"SELECT coalesce(max(id),0)+1 FROM dm.dm_%s",
				(const char*) key);
			res = maxsql->FetchRow();
			if(IS_SQL_SUCCESS(res)) {
				debug0("Key not found, inserting ('%s', %d)",
					(const char*) key, objectId);
				maxsql->CloseSQL();
			} else {
				objectId = 1;
				debug0("Key not found, max failed, inserting ('%s', %d)",
					(const char*) key, objectId);
			}

			res = sql->EndTransaction(true);
			// Revert to auto-commit mode
			sql->SetAutoCommitMode(true);

			// Insert starting id in the table
			AutoPtr<triSQL> insql = m_odbc.GetSQL();
			res = insql->ExecuteSQL(
				"INSERT INTO dm_keys(object, id) VALUES('%s', %d)",
				(const char*) key, objectId);
			if(IS_SQL_SUCCESS(res)) {
				insql->CloseSQL();
				return objectId;
			} else {
				throw RuntimeError("Insert failed");
			}
		}
	}
	
	sql->SetAutoCommitMode(true);
	throw RuntimeError("Select for update failed");
}


char *Model::internalGetAccessibleChildDomains(int domainid)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int id = 0;
	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));

	int res = sql->ExecuteSQL(
			"select d.id from dm_domain d where d.domainid =  %d and d.status = 'N' ",
			domainid);
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	char *ret = NULL;
	int rows = sql->GetRowCount();

	if(rows > 0) {
		int *domains = (int*) malloc(rows * sizeof(int));

		int i;

		// Cache the result so that we can start another query
		for(i = 0; i < rows; i++) {
			res = sql->FetchRow();
			if(IS_NOT_SQL_SUCCESS(res)) {
				return NULL;
			}
			domains[i] = id;
			debug3("domain %d", domains[i]);
		}

		// Now recurse using the cached results
		for(i = 0; i < rows; i++) {
			char *list = internalGetAccessibleChildDomains(domains[i]);

			char idstr[32];
			sprintf(idstr, "%d", domains[i]);

			if(ret) {
				ret = (char*) realloc(ret, strlen(idstr) + strlen(ret) + (list ? strlen(list) : 0) + 3);
				strcat(ret, ",");
			} else {
				ret = (char*) malloc(strlen(idstr) + (list ? strlen(list) : 0) + 2);
				*ret = '\0';
			}

			strcat(ret, idstr);

			if(list) {
				strcat(ret, ",");
				strcat(ret, list);
				SAFE_FREE(list);
			}

			debug3("ret %s", ret);
		}

		SAFE_FREE(domains);
	}

	return ret;
}


char *Model::internalGetAccessibleParentDomains(int domainid)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int id = 0;
	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));

	int res = sql->ExecuteSQL(
			"select d.id from dm_domain c, dm_domain d where c.id = %d and d.id = c.domainid and d.status = 'N' ",
			domainid);
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	char *ret = NULL;
	int rows = sql->GetRowCount();

	if(rows > 0) {
		int *domains = (int*) malloc(rows * sizeof(int));

		int i;

		// Cache the result so that we can start another query
		for(i = 0; i < rows; i++) {
			res = sql->FetchRow();
			if(IS_NOT_SQL_SUCCESS(res)) {
				return NULL;
			}
			domains[i] = id;
			debug3("domain %d", domains[i]);
		}

		// Now recurse using the cached results
		for(i = 0; i < rows; i++) {
			char *list = internalGetAccessibleParentDomains(domains[i]);

			char idstr[32];
			sprintf(idstr, "%d", domains[i]);

			if(ret) {
				ret = (char*) realloc(ret, strlen(idstr) + strlen(ret) + (list ? strlen(list) : 0) + 3);
				strcat(ret, ",");
			} else {
				ret = (char*) malloc(strlen(idstr) + (list ? strlen(list) : 0) + 2);
				*ret = '\0';
			}

			strcat(ret, idstr);

			if(list) {
				strcat(ret, ",");
				strcat(ret, list);
				SAFE_FREE(list);
			}

			debug3("ret %s", ret);
		}

		SAFE_FREE(domains);
	}

	return ret;
}


char *Model::getAccessibleDomains(Domain &domain)
{
	char idstr[32];
	sprintf(idstr, "%d", domain.id());

	char *ret = strdup(idstr);

	char *childList = internalGetAccessibleChildDomains(domain.id());
	if(childList) {
		ret = (char*) realloc(ret, strlen(ret) + strlen(childList) + 2);
		strcat(ret, ",");
		strcat(ret, childList);
		SAFE_FREE(childList);
	}

	char *parentList = internalGetAccessibleParentDomains(domain.id());
	if(parentList) {
		ret = (char*) realloc(ret, strlen(ret) + strlen(parentList) + 2);
		strcat(ret, ",");
		strcat(ret, parentList);
		SAFE_FREE(parentList);
	}

	return ret;
}


Environment *Model::findOrCreateEnvironment(
	int id, const char* name, const char *basedir)
{
	Environment *env = NULL;
	if(!(env = m_envCache.get(id))) {
		env = new Environment(*this, id, name, basedir);
		m_envCache.put(env);
	}
	return env;
}


Domain *Model::findOrCreateDomain(int id, const char* name)
{
	Domain *domain = NULL;
	if(!(domain = m_domCache.get(id))) {
		domain = new Domain(*this, id, name);
		m_domCache.put(domain);
	}
	return domain;
}


ServerType *Model::findOrCreateServerType(
	int id, const char *hosttype, LINE_END_FORMAT lineends,
	const char *pathformat)
{
	ServerType *st = NULL;
	if(!(st = m_styCache.get(id))) {
		st = new ServerType(id, hosttype, lineends, pathformat);
		m_styCache.put(st);
	}
	return st;
}


Server *Model::findOrCreateServer(
	int id, const char *name, const char *hostname, const char *protocol,
	const char *basedir, ServerType *servertype)
{
	Server *server = NULL;
	if(!(server = m_srvCache.get(id))) {
		server = new Server(
			*this, id, name, hostname, protocol, basedir, servertype);
		m_srvCache.put(server);
	}
	return server;
}


Application *Model::findOrCreateApplication(int id, const char *name)
{
	Application *app = NULL;
	if(!(app = m_appCache.get(id))) {
		app = new Application(*this, id, name);
		m_appCache.put(app);
	}
	return app;
}


ApplicationVersion *Model::findOrCreateApplicationVersion(
	int id, const char *name, const char *version, Application *parent)
{
	Application *app = NULL;
	if(!(app = m_appCache.get(id))) {
		app = new ApplicationVersion(*this, id, name, version, parent);
		m_appCache.put(app);
	}
	return app->toApplicationVersion();
}


Component *Model::findOrCreateComponent(
	int id, const char *name, const char *basedir, ComponentFilter rollup,
	ComponentFilter rollback, bool filterItems)
{
	Component *com = NULL;
	if(!(com = m_comCache.get(id))) {
		com = new Component(*this, id, name, basedir, rollup, rollback, filterItems);
		m_comCache.put(com);
	}
	return com;
}


User *Model::findOrCreateUser(
	int id, const char *name, const char* email,
	const char *realname, const char *phone)
{
	User *user = NULL;
	if(name || email) {
		if(!(user = m_usrCache.get(id))) {
			user = new User(*this, id, name, email, realname, phone);
			m_usrCache.put(user);
		}
	}
	return user;
}


UserGroup *Model::findOrCreateUserGroup(
	int id, const char *name, const char* email)
{
	UserGroup *group = NULL;
	if(name || email) {
		if(!(group = m_usgCache.get(id))) {
			group = new UserGroup(*this, id, name, email);
			m_usgCache.put(group);
		}
	}
	return group;
}


ProviderObjectDef *Model::findOrCreateProviderObjectDef(
	int id, const char *name, const char *kind, Plugin *plugin)
{
	ProviderObjectDef *pod = NULL;
	if(!(pod = m_podCache.get(id))) {
		pod = new ProviderObjectDef(id, name, kind, plugin);
		m_podCache.put(pod);
		getPropertiesForProviderObjectDef(*pod);
		getPropertyDefsForProviderObjectDef(*pod);
	}
	return pod;
}


Credentials *Model::findOrCreateCredentials(
	int id, const char *name, CREDENTIALS_KIND kind,
	char *encuser, const char *encpass, const char *filename)
{
	Credentials *cred = NULL;
	if(!(cred = m_crdCache.get(id))) {
		switch(kind) {
		case CREDENTIALS_USE_DIALOG:
		case CREDENTIALS_ENCRYPTED:
			// These should never be set in database
			throw RuntimeError("Credentials kind not allowed in database");
		case CREDENTIALS_IN_DATABASE:
		case CREDENTIALS_FROM_VARS:
			cred = new Credentials(id, name, kind, encuser, encpass);
			break;
		case CREDENTIALS_RTI3_DFO_IN_FILESYSTEM:
		case CREDENTIALS_HARVEST_DFO_IN_FILESYSTEM:
			return new Credentials(id, name, kind, filename);
		default:
			throw RuntimeError("Unrecognised credentials kind in database (%d)", (int) kind);
		}
		m_crdCache.put(cred);
	}
	return cred;
}


Action *Model::findOrCreateAction(
	int id, ACTION_KIND kind, bool isFunc, /*bool isRemote,*/ bool copyTo,
	bool resIsExpr, const char *name, const char *filepath)
{
	Action *action = NULL;
	if(!(action = m_actCache.get(id))) {
		action = new Action(
			*this, id, kind, isFunc, /*isRemote,*/ copyTo, resIsExpr, name, filepath);
		m_actCache.put(action);
	}
	return action;
}


Script *Model::findOrCreateScript(int repoid, const char *filepath)
{
	char *key = (char*) malloc(strlen(filepath) + 32);
	sprintf(key, "r%d:%s", repoid, filepath);

	Script *script = NULL;
	if(!(script = m_scrCache.get(key))) {
		script = new Script(*this, repoid, filepath);
		m_scrCache.put(key, script);
	}

	SAFE_FREE(key);
	return script;
}


Script *Model::findOrCreateScript(Action *action, int textid)
{
	// TODO: consider whether action name needs to be part of key
	// textid can be null (0) so must put actionid into key
	char key[32];
	sprintf(key, "a%d:%d", action->id(), textid);

	Script *script = NULL;
	if(!(script = m_scrCache.get(key))) {
		script = new Script(*this, action, textid);
		m_scrCache.put(key, script);
	}

	return script;
}


Plugin *Model::findOrCreatePlugin(int id, int version, const char *library)
{
	Plugin *plugin = NULL;
	if(!(plugin = m_plgCache.get(id))) {
		plugin = new Plugin(id, version, library);
		m_plgCache.put(plugin);
	}
	return plugin;
}


Task *Model::findOrCreateTask(int id, const char *name, const char *kind)
{
	Task *task = NULL;
	if(!(task = m_tskCache.get(id))) {
		task = new Task(*this, id, name, kind);
		m_tskCache.put(task);
	}
	return task;
}


void Model::getServersForEnvironment(Environment &env)
{
	char whereClause[1024];
	sprintf(whereClause, "sie.envid = %d and s.id = sie.serverid", env.id());
	AutoPtr<List<Server> > matches = internalGetServers("dm_serversinenv sie", whereClause);
	if(matches) {
		ListIterator<Server> iter(*matches);
		for(Server *s = iter.first(); s; s = iter.next()) {
			env.add(s);
		}
	}
}


/**
 * Gets all the applications and application versions which are allowed in the
 * given environment.
 */
void Model::getApplicationsAllowedInEnvironment(Environment &env)
{
	char whereClause[1024];
	sprintf(whereClause, "aie.envid = %d and a.id = aie.appid OR a.parentid = aie.appid" , env.id());
	AutoPtr<List<Application> > matches = internalGetApplications("dm_appsallowedinenv aie", whereClause, false);
	ListIterator<Application> iter(*matches);
	for(Application *app = iter.first(); app; app = iter.next()) {
		env.add(app);
	}
}


Application *Model::getApplicationDeployedToEnvironment(Environment &env, Application &app)
{
	char whereClause[1024];
	sprintf(whereClause, "aie.envid = %d and a.id = aie.appid and (a.id = %d or a.parentid = %d)",
		env.id(), app.id(), app.id());
	AutoPtr<List<Application> > matches = internalGetApplications("dm_appsinenv aie", whereClause, false);
	ListIterator<Application> iter(*matches);
	Application *depapp = iter.first();

	if(depapp) {
		debug0("getAppDeployedToEnv %d, '%s' - returning %d, '%s'", env.id(), env.name(), depapp->id(), depapp->name());
	} else {
		debug0("getAppDeployedToEnv %d, '%s' - returning NULL", env.id(), env.name());
	}

	return depapp;
}


void Model::getCredentialsForEnvironment(Environment &env)
{
	char whereClause[256];
	sprintf(whereClause, "t.id = %d", env.id());

	Credentials *creds = internalGetCredentials("dm_environment", whereClause);
	env.setCredentials(creds);
}


bool Model::isEnvironmentAvailable(Environment &env)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int unavailstart = 0;
	int unavailend = 0;
	sql->BindColumn(1, SQL_INTEGER, &unavailstart, sizeof(unavailstart));
	sql->BindColumn(2, SQL_INTEGER, &unavailend, sizeof(unavailend));

	int res = sql->ExecuteSQL(
			"select a.unavailstart, a.unavailend from dm_availability a "
			"where a.envid = %d and a.unavailstart < %d and a.unavailend > %d",
			env.id(), m_deploymentStartTime, m_deploymentStartTime);
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	int rows = sql->GetRowCount();
	return (rows == 0) ? true : false;
}


void Model::getSubdomainsForDomain(Domain *domain)
{
	char whereClause[256];
	sprintf(whereClause, "d.domainid = %d", domain->id());

	AutoPtr<List<Domain> > matches = internalGetDomains(NULL, whereClause);

	if(matches) {
		ListIterator<Domain> iter(*matches);
		for(Domain *child = iter.first(); child; child = iter.next()) {
			child->setDomain(domain);
			domain->add(child);
		}
	}
}


void Model::getEnvironmentsForDomain(Domain *domain)
{
	char whereClause[256];
	sprintf(whereClause, "e.domainid = %d ", domain->id());
	AutoPtr<List<Environment> > matches = internalGetEnvironments(whereClause, false);

	if(matches) {
		ListIterator<Environment> iter(*matches);
		for(Environment *e = iter.first(); e; e = iter.next()) {
			e->setDomain((Domain*) domain);
			domain->add(e);
		}
	}
}


void Model::getApplicationsForDomain(Domain *domain)
{
	char whereClause[256];
	sprintf(whereClause, "a.domainid = %d", domain->id());

	AutoPtr<List<Application> > matches = internalGetApplications(NULL, whereClause, false);

	if(matches) {
		ListIterator<Application> iter(*matches);
		for(Application *child = iter.first(); child; child = iter.next()) {
			child->setDomain(domain);
			domain->add(child);
		}
	}
}


void Model::getRepositoriesForDomain(Domain *domain)
{
	getProviderObjectsForDomain<Repository>(m_repCache, domain);
}


void Model::getNotifysForDomain(Domain *domain)
{
	getProviderObjectsForDomain<Notify>(m_nfyCache, domain);
}


void Model::getDatasourcesForDomain(Domain *domain)
{
	getProviderObjectsForDomain<Datasource>(m_datCache, domain);
}


void Model::getParentForDomain(Domain &domain)
{
	char whereClause[256];
	sprintf(whereClause, "egc.id = %d and eg.id = egc.domainid", domain.id());

	AutoPtr<List<Domain> > matches = internalGetDomains(
		"dm_domain egc, (dm_domain eg left join dm_user u on eg.ownerid = u.id"
		"left join dm_usergroup g on eg.ogrpid = g.id)", whereClause);

	if(matches && (matches->size() > 0)) {
		ListIterator<Domain> iter(*matches);
		domain.setDomain(iter.first());
		// Note that we don't add an incomplete list of children
		// they will be read from the db only if requested
	}
}


void Model::getCredentialsForServer(Server &server)
{
	char whereClause[256];
	sprintf(whereClause, "t.id = %d", server.id());

	Credentials *creds = internalGetCredentials(server.table(), whereClause);
	server.setCredentials(creds);
}


void Model::getActionsForApplication(Application &app)
{
	char whereClause[1024];

	sprintf(whereClause, "app.id = %d and a.id = app.actionid", app.id());
	Action *action = internalGetAction("dm_application app", whereClause, false);

	sprintf(whereClause, "app.id = %d and a.id = app.preactionid", app.id());
	Action *preAction = internalGetAction("dm_application app", whereClause, false);

	sprintf(whereClause, "app.id = %d and a.id = app.postactionid", app.id());
	Action *postAction = internalGetAction("dm_application app", whereClause, false);

	app.setActions(action, preAction, postAction);
}


void Model::getComponentsForApplication(Application &app)
{
	//char whereClause[1024];
	//sprintf(whereClause, "ac.appid = %d and c.id = ac.compid", app.id()); // TODO:  was "order by ac.comporder", but comporder replaced with predecessorid
	//AutoPtr<List<Component> > matches = internalGetComponents("dm_applicationcomponent ac", whereClause);
	//if(matches) {
	//	ListIterator<Component> iter(*matches);
	//	for(Component *c = iter.first(); c; c = iter.next()) {
	//		app.addComponent(c);
	//	}
	//}
	//debug0("getComponentsForApplication %d, '%s'", app.id(), app.name());

	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int id = 0;
	char compName[DB_NAME_LEN];
	char baseDir[DB_PATH_LEN];
	int rollup;
	int rollback;
	char filterItems[DB_BOOL_LEN];
	int predecessorid = 0;
	SQLLEN ni_baseDir = 0, ni_rollup = 0, ni_rollback = 0, ni_filterItems = 0, ni_predecessorid = 0;

	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));
	sql->BindColumn(2, SQL_CHAR, compName, sizeof(compName));
	sql->BindColumn(3, SQL_CHAR, baseDir, sizeof(baseDir), &ni_baseDir);
	sql->BindColumn(4, SQL_INTEGER, &rollup, sizeof(rollup), &ni_rollup);
	sql->BindColumn(5, SQL_INTEGER, &rollback, sizeof(rollback), &ni_rollback);
	sql->BindColumn(6, SQL_CHAR, filterItems, sizeof(filterItems), &ni_filterItems);
	sql->BindColumn(7, SQL_INTEGER, &predecessorid, sizeof(predecessorid), &ni_predecessorid);

	// This query has been altered to use dm_applicationcomponentflows, but it
	// treats them purely to give what it thinks is still a predecessorid.
	int res = sql->ExecuteSQL(
		"select c.id, c.name, c.basedir, c.rollup, c.rollback, c.filteritems, cf.compfrom "
		"from dm_applicationcomponent ac "
		"left outer join dm_component c on c.id = ac.compid and c.status = 'N' "
		"left outer join dm_applicationcomponentflows cf on cf.appid = ac.appid and cf.compto = ac.compid "
		"where ac.appid = %d order by 1 ", app.id());
	if(IS_NOT_SQL_SUCCESS(res)) {
		return;
	}

	// TODO: This needs to change to build up the notion of parallel component
	// deployments - at the moment this returns a simple flat list - RHT 10/02/2014

	List<Component> roots;			// List of all start components (no predecessor)
	HashtableById<Component> preds;	// Hashtable of non-start components indexed by their predecessor

	int count = 0;
	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		Component *comp = findOrCreateComponent(
			id, compName, NULL_IND(baseDir,NULL), (ComponentFilter) NULL_IND(rollup, false),
			(ComponentFilter) NULL_IND(rollback, false),
			BOOL_NULL_IND(filterItems, false));
		count++;
		if(NULL_IND(predecessorid, 0) != 0) {
			//debug0("Component %d, '%s' with predecessor %d", id, compName, predecessorid);
			preds.put(predecessorid, comp);
		} else {
			//debug0("Component %d, '%s' with no predecessor", id, compName);
			roots.add(comp);
		}
	}

	// Go through the roots one at a time and add them to the list followed
	// immediatedly by any components that hang from them
	int count2 = 0;
	ListIterator<Component> iter(roots);
	for(Component *c = iter.first(); c; c = iter.next()) {
		//debug0("Application %d, '%s' - adding root component %d, '%s'", app.id(), app.name(), c->id(), c->name());
		app.addComponent(c);
		count2++;
		for(Component *p = preds.get(c->id()); p; p = preds.get(p->id())) {
			//debug0("Application %d, '%s' - adding next component %d, '%s'", app.id(), app.name(), p->id(), p->name());
			app.addComponent(p);
			count2++;
		}
	}

	// This is just a sanity check to make sure we didn't lose an AV
	if(count != count2) {
		debug0("WARNING: Component counts differ %d != %d", count, count2);
	}
}


ApplicationVersion *Model::getVersionOfApplication(Application &app, const char *name)
{
	char *nameLit = triSQL::EscapeLiteral(name);
	char whereClause[1024];
	sprintf(whereClause, "a.parentid = %d AND a.name = %s", app.id(), nameLit);
	SAFE_FREE(nameLit);

	ApplicationVersion *version = NULL;
	AutoPtr<List<Application> > matches = internalGetApplications(NULL, whereClause, false);
	if(matches) {
		ListIterator<Application> iter(*matches);
		Application *app = iter.first();
		if(app && (app->kind() == OBJ_KIND_APPVERSION)) {
			return (ApplicationVersion*) app;
		}
	}
	return NULL;
}


bool Model::isApplicationAvailable(Application &app, Environment &env)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int appid = 0;
	int starttime = 0;
	int endtime = 0;
	sql->BindColumn(1, SQL_INTEGER, &appid, sizeof(appid));
	sql->BindColumn(2, SQL_INTEGER, &starttime, sizeof(starttime));
	sql->BindColumn(3, SQL_INTEGER, &endtime, sizeof(endtime));

	int res = sql->ExecuteSQL(
			"select c.appid, c.starttime, c.endtime from dm_calendar c "
			"where c.envid = %d and c.starttime < %d and c.endtime > %d",
			env.id(), m_deploymentStartTime, m_deploymentStartTime);
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	bool okay = true;
	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		if(appid == app.id()) {
			// reserved for this application, so okay
			return true;
		}
		// at least one reservation which is not this application
		okay = false;
	}
	return okay;
}


void Model::getPredecessorForApplicationVersion(ApplicationVersion &av)
{
	char whereClause[1024];
	sprintf(whereClause, "a.id = b.predecessorid and b.id = %d", av.id());

	ApplicationVersion *predecessor = NULL;
	AutoPtr<List<Application> > matches = internalGetApplications("dm_application b", whereClause, false);
	if(matches) {
		ListIterator<Application> iter(*matches);
		Application *app = iter.first();
		if(app && (app->kind() == OBJ_KIND_APPVERSION)) {
			predecessor = (ApplicationVersion*) app;
		}
	}
	av.setPredecessor(predecessor);
}


void Model::getSuccessorsForApplicationVersion(ApplicationVersion &av)
{
	char whereClause[1024];
	sprintf(whereClause, "a.predecessorid = %d", av.id());

	ApplicationVersion *predecessor = NULL;
	AutoPtr<List<Application> > matches = internalGetApplications(NULL, whereClause, false);
	if(matches) {
		ListIterator<Application> iter(*matches);
		for(Application *app = iter.first(); app; app = iter.next()) {
			if(app->kind() == OBJ_KIND_APPVERSION) {
				av.addSuccessor((ApplicationVersion*) app);
			}
		}
	}
}


DMArray *Model::getApprovalsForApplicationVersion(ApplicationVersion &av)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();
	char approved[DB_BOOL_LEN];
	int domainid;
	char domainName[DB_NAME_LEN];

	SQLRETURN res = sql->PrepareStatement(
		"select a.approved, a.domainid, d.name from dm_approval a, dm_domain d "
		"where a.id in (select max(b.id) from dm_approval b "
		"where b.appid = ? AND b.domainid = a.domainid) and d.id = a.domainid");
	if(IS_NOT_SQL_SUCCESS(res)) {
		throw RuntimeError("Failed to get approvals for application");
	}
	int avid = av.id();
	sql->BindParameter(1, SQL_INTEGER, sizeof(avid), &avid, sizeof(avid));
	sql->BindColumn(1, SQL_CHAR, approved, sizeof(approved));
	sql->BindColumn(2, SQL_INTEGER, &domainid, sizeof(domainid));
	sql->BindColumn(3, SQL_CHAR, domainName, sizeof(domainName));
	res = sql->Execute();
	DMArray *ret =  new DMArray(false);
	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		debug0("Approval %s for domain %d '%s'", approved, domainid, domainName);
		ret->put(domainName, new Variable(NULL, (approved[0] == 'Y' ? "approved" : "rejected")));
	}
	sql->CloseSQL();
	return ret;
}


void Model::alterApplicationVersionVars(ApplicationVersion &av, class DMArray *attrs)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();
	AutoPtr<StringList> keys = attrs->keys();
	StringListIterator iter(*keys);
	for(const char *key = iter.first(); key; key = iter.next()) {
		Variable  *var = attrs->get(key);
		const char *val = var ? var->value() : NULL;
		if(val) {
			debug0("SET '%s' = '%s'", key, val);

			int avid = av.id();
			SQLRETURN res = sql->PrepareStatement(
				"update %svars set value = ? where %s = ? and name = ?",
				av.table(), av.fk());
			if(IS_NOT_SQL_SUCCESS(res)) {
				throw RuntimeError("Failed to update object vars");
			}
			sql->BindParameter(1, SQL_CHAR, strlen(val), (char*) val, strlen(val));
			sql->BindParameter(2, SQL_INTEGER, sizeof(avid), &avid, sizeof(avid));
			sql->BindParameter(3, SQL_CHAR, strlen(key), (char*) key, strlen(key));
			res = sql->ExecuteIgnoringErrors();
			sql->CloseSQL();
			if(IS_NOT_SQL_SUCCESS(res)) {
				if((res != SQL_ERROR) && (res != SQL_NO_DATA)) {
					throw RuntimeError("Failed to update object vars (2), %d", res);
				}
				res = sql->PrepareStatement(
					"insert into %svars(%s,name,value,nocase) values(?,?,?,'N')",
					av.table(), av.fk());
				if(IS_NOT_SQL_SUCCESS(res)) {
					throw RuntimeError("Failed to insert object vars");
				}
				sql->BindParameter(1, SQL_INTEGER, sizeof(avid), &avid, sizeof(avid));
				sql->BindParameter(2, SQL_CHAR, strlen(key), (char*) key, strlen(key));
				sql->BindParameter(3, SQL_CHAR, strlen(val), (char*) val, strlen(val));
				res = sql->Execute();
				sql->CloseSQL();
				if(IS_NOT_SQL_SUCCESS(res)) {
					throw RuntimeError("Failed to insert object vars (2)");
				}
			}
		}
	}
}


List<Server> *Model::getAllServersForComponent(Component &comp, Environment &env)
{
	char whereClause[2048];
	sprintf(whereClause,
		"c.id = %d and (caos.compid = c.id or caos.compid = c.parentid) "
		" and caos.serverid = s.id and sie.envid = %d and sie.serverid = s.id ",
		comp.id(), env.id());
	return internalGetServers("dm_component c, dm_compsallowedonserv caos, dm_serversinenv sie", whereClause);
}


List<Server> *Model::getServerSubsetForComponent(
		Component &comp, List<Server> &servers)
{
	// This won't work if the server set is empty
	if(servers.size() == 0) {
		throw RuntimeError("Server set is empty when processing component '%s'", comp.name());
	}

	char whereClause[2048];
	int len = sprintf(whereClause,
		"c.id = %d and (caos.compid = c.id or caos.compid = c.parentid) "
		" and caos.serverid = s.id and s.id in (", comp.id());
	char *pos = &whereClause[len];
	bool first = true;
	ListIterator<Server> iter(servers);
	for(Server *s = iter.first(); s; s = iter.next()) {
		pos += sprintf(pos, (first ? "%d" : ",%d"), s->id());
		first = false;
	}
	sprintf(pos, ")");
	return internalGetServers("dm_component c, dm_compsallowedonserv caos", whereClause);
}


void Model::getItemsForComponent(Component &comp)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int id = 0;
	char ciName[DB_NAME_LEN];
	int ciRepoId = 0;
	char ciTarget[DB_PATH_LEN];
	int rollup;
	int rollback;
	int predecessorid = 0;
	SQLLEN ni_ciRepoId = 0, ni_ciTarget = 0,
		ni_rollup = 0, ni_rollback = 0,
		ni_predecessorid = 0;

	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));
	sql->BindColumn(2, SQL_CHAR, ciName, sizeof(ciName));
	sql->BindColumn(3, SQL_INTEGER, &ciRepoId, sizeof(ciRepoId), &ni_ciRepoId);
	sql->BindColumn(4, SQL_CHAR, ciTarget, sizeof(ciTarget), &ni_ciTarget);
	sql->BindColumn(5, SQL_INTEGER, &rollup, sizeof(rollup), &ni_rollup);
	sql->BindColumn(6, SQL_INTEGER, &rollback, sizeof(rollback), &ni_rollback);
	sql->BindColumn(7, SQL_INTEGER, &predecessorid, sizeof(predecessorid), &ni_predecessorid);

	int res = sql->ExecuteSQL(
			"select ci.id, ci.name, ci.repositoryid, ci.target, ci.rollup, ci.rollback, ci.predecessorid "
			"from dm_componentitem ci "
			"where ci.compid = %d and ci.status = 'N' "
			"order by 1 ", comp.id());
	if(IS_NOT_SQL_SUCCESS(res)) {
		return;
	}

	List<ComponentItem> roots;			// List of all start items (no predecessor)
	HashtableById<ComponentItem> preds;	// Hashtable of non-start items indexed by their predecessor

	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		ComponentItem *ci = new ComponentItem(
			*this, id, ciName, comp, NULL_IND(ciRepoId, 0), NULL_IND(ciTarget, NULL),
			(ComponentFilter) NULL_IND(rollup, 0), (ComponentFilter) NULL_IND(rollback, 0));
		if(NULL_IND(predecessorid, 0) != 0) {
			//debug0("ComponentItem %d, '%s' with predecessor %d", id, ciName, predecessorid);
			preds.put(predecessorid, ci);
		} else {
			//debug0("ComponentItem %d, '%s' with no predecessor", id, ciName);
			roots.add(ci);
		}
		getPropertiesForComponentItem(*ci);
	}	

	// Go through the roots one at a time and add them to the list followed
	// immediatedly by any items that hang from them
	ListIterator<ComponentItem> iter(roots);
	for(ComponentItem *ci = iter.first(); ci; ci = iter.next()) {
		//debug0("Component %d, '%s' - adding root component item %d, '%s'", comp.id(), comp.name(), ci->id(), ci->name());
		comp.add(ci);
		for(ComponentItem *pi = preds.get(ci->id()); pi; pi = preds.get(pi->id())) {
			//debug0("Component %d, '%s' - adding next component item %d, '%s'", comp.id(), comp.name(), pi->id(), pi->name());
			comp.add(pi);
		}
	}
}


void Model::getActionsForComponent(Component &comp)
{
	char whereClause[1024];

	sprintf(whereClause, "c.id = %d and a.id = c.actionid", comp.id());
	Action *action = internalGetAction("dm_component c", whereClause, false);

	sprintf(whereClause, "c.id = %d and a.id = c.preactionid", comp.id());
	Action *preAction = internalGetAction("dm_component c", whereClause, false);

	sprintf(whereClause, "c.id = %d and a.id = c.postactionid", comp.id());
	Action *postAction = internalGetAction("dm_component c", whereClause, false);

	comp.setActions(action, preAction, postAction);
}


void Model::getRepositoryForComponentItem(ComponentItem &ci)
{
	char whereClause[1024];
	sprintf(whereClause, "t.id = %d", ci.repoid());

	AutoPtr<List<Repository> > matches = internalGetProviderObjects<Repository>(
		m_repCache, NULL, whereClause, false);
	if(matches && (matches->size() > 0)) {
		ListIterator<Repository> iter(*matches);
		ci.setRepository(iter.first());
	}
}


void Model::getPropertiesForComponentItem(ComponentItem &ci)
{
	AutoPtr<List<Property> > matches = internalGetProperties(
		"dm_compitem", "compitemid", ci.id());
	if(matches) {
		ListIterator<Property> iter(*matches);
		for(Property *prop = iter.first(); prop; prop = iter.next()) {
			ci.setProperty(prop);
		}
	}
}


void Model::getUsersForUserGroup(UserGroup &group)
{
	char whereClause[1024];
	sprintf(whereClause, "u.id = uig.userid and uig.groupid = %d", group.id());

	AutoPtr<List<User> > matches = internalGetUsers(
		"dm_usersingroup uig", whereClause, false);

	if(matches) {
		ListIterator<User> iter(*matches);
		for(User *user = iter.first(); user; user = iter.next()) {
			group.add(user);
		}
	}
}


void Model::getUserGroupsForUser(User &user)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int id = 0;
	char groupName[DB_NAME_LEN];
	char groupEmail[DB_EMAIL_LEN];
	SQLLEN ni_groupEmail = 0;

	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));
	sql->BindColumn(2, SQL_CHAR, groupName, sizeof(groupName));
	sql->BindColumn(3, SQL_CHAR, groupEmail, sizeof(groupEmail), &ni_groupEmail);

	int res = sql->ExecuteSQL("select g.id, g.name, g.email "
			"from dm_usergroup g, dm_usersingroup uig "
			"where g.id = uig.groupid and uig.userid = %d and g.status = 'N'", user.id());
	if(IS_NOT_SQL_SUCCESS(res)) {
		return;
	}

	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		UserGroup *group = findOrCreateUserGroup(id, groupName, NULL_IND(groupEmail, NULL));
		user.add(group);
	}
}


void Model::setActionNodes(class ActionNodeList *actions)
{
	if(m_actionNodes) {
		m_actionNodes->merge(*actions);
		SAFE_DELETE(actions);
	} else {
		m_actionNodes = actions;
	}
}


class ActionNode *Model::firstActionNode()
{
	return m_actionNodes ? m_actionNodes->firstActionNode() : NULL;
}


class ActionNode *Model::getActionNode(const char *name)
{
	return m_actionNodes ? m_actionNodes->getActionNode(name) : NULL;
}


void Model::getOwnerForObject(Object &obj)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int ownerid = 0;
	int ogrpid = 0;
	char userName[DB_NAME_LEN];
	char userEmail[DB_EMAIL_LEN];
	char userReal[DB_NAME_LEN];
	char userPhone[DB_PHONE_LEN];
	char groupName[DB_NAME_LEN];
	char groupEmail[DB_EMAIL_LEN];
	SQLLEN ni_ownerid = 0, ni_ogrpid = 0, ni_userName = 0, ni_userEmail = 0,
		ni_userReal = 0, ni_userPhone = 0, ni_groupName = 0, ni_groupEmail = 0;

	sql->BindColumn(1, SQL_INTEGER, &ownerid, sizeof(ownerid), &ni_ownerid);
	sql->BindColumn(2, SQL_INTEGER, &ogrpid, sizeof(ogrpid), &ni_ogrpid);
	sql->BindColumn(3, SQL_CHAR, userName, sizeof(userName), &ni_userName);
	sql->BindColumn(4, SQL_CHAR, userEmail, sizeof(userEmail), &ni_userEmail);
	sql->BindColumn(5, SQL_CHAR, userReal, sizeof(userReal), &ni_userReal);
	sql->BindColumn(6, SQL_CHAR, userPhone, sizeof(userPhone), &ni_userPhone);
	sql->BindColumn(7, SQL_CHAR, groupName, sizeof(groupName), &ni_groupName);
	sql->BindColumn(8, SQL_CHAR, groupEmail, sizeof(groupEmail), &ni_groupEmail);

	int res = sql->ExecuteSQL(
			"select o.ownerid, o.ogrpid, u.name, u.email, "
			" u.realname, u.phone, g.name, g.email "
			"from (%s o left join dm_user u on o.ownerid = u.id and u.status = 'N' "
			"left join dm_usergroup g on o.ogrpid = g.id and g.status = 'N') "
			"where o.id = %d ", obj.table(), obj.id());
	if(IS_NOT_SQL_SUCCESS(res)) {
		return;
	}

	res = sql->FetchRow();
	if(IS_SQL_SUCCESS(res)) {
		User *owner = findOrCreateUser(NULL_IND(ownerid, 0),
			NULL_IND(userName, NULL),
			NULL_IND(userEmail, NULL),
			NULL_IND(userReal, NULL),
			NULL_IND(userPhone, NULL));
		UserGroup *owngrp = findOrCreateUserGroup(NULL_IND(ogrpid, 0),
			NULL_IND(groupName, NULL),
			NULL_IND(groupEmail, NULL));

		if(owner) {
			obj.setOwner(owner);
		} else if(owngrp) {
			obj.setOwner(owngrp);
		}
	}
}


void Model::getVariablesForObject(Object &obj, Scope &vars)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	char varName[DB_NAME_LEN];
	char varValue[DB_VARVAL_LEN];
	int arrayid = 0;
	char nocase[DB_BOOL_LEN];
	SQLLEN ni_varValue = 0, ni_arrayid = 0, ni_nocase = 0;

	sql->BindColumn(1, SQL_CHAR, varName, sizeof(varName));
	sql->BindColumn(2, SQL_CHAR, varValue, sizeof(varValue), &ni_varValue);
	sql->BindColumn(3, SQL_INTEGER, &arrayid, sizeof(arrayid), &ni_arrayid);
	sql->BindColumn(4, SQL_CHAR, nocase, sizeof(nocase), &ni_nocase);

	int res = sql->ExecuteSQL("select v.name, v.value, v.arrayid, v.nocase "
			"from %svars v where v.%s = %d ",
			obj.table(), obj.fk(), obj.id());
	if(IS_NOT_SQL_SUCCESS(res)) {
		return;
	}

	int deferred_arrayid[10];
	DMArray *deferred_array[10];
	int deferred_arrays = 0;

	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		if(NULL_IND(arrayid, 0) > 0) {
			// Create the new array, but defer the filling till later
			DMArray *ht = vars.newArray(varName, false,
				BOOL_NULL_IND(nocase, false));
			deferred_arrayid[deferred_arrays] = NULL_IND(arrayid, 0);
			deferred_array[deferred_arrays] = ht;
			deferred_arrays++;
		} else {
			vars.set(varName, NULL_IND(varValue, NULL),
				BOOL_NULL_IND(nocase, false));
		}
	}

	sql->CloseSQL();

	// Now run queries for each array after we have finished with the variables query
	for(int a = 0; a < deferred_arrays; a++) {
		char arrName[DB_ARRAYKEY_LEN];
		char arrValue[DB_VARVAL_LEN];
		SQLLEN ni_arrValue = 0;

		sql->BindColumn(1, SQL_CHAR, arrName, sizeof(varName));
		sql->BindColumn(2, SQL_CHAR, arrValue, sizeof(arrValue), &ni_arrValue);

		res = sql->ExecuteSQL("select a.name, a.value "
				"from dm_arrayvalues a where a.id = %d ",
				deferred_arrayid[a]);
		if(IS_SQL_SUCCESS(res)) {
			for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
				deferred_array[a]->put(arrName, new Variable(NULL, NULL_IND(arrValue, NULL)));
			}
		}

		sql->CloseSQL();
	}
}


void Model::addAccessForDomain(Domain &dom, HashtableById<ObjectAccess> &ia)
{
	//debug0("addAccessForDomain('%s')", dom.name());

	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int usrgrpid = 0;
	char readAccess[DB_BOOL_LEN];
	char writeAccess[DB_BOOL_LEN];
	SQLLEN ni_readAccess = 0, ni_writeAccess = 0;

	sql->BindColumn(1, SQL_INTEGER, &usrgrpid, sizeof(usrgrpid));
	sql->BindColumn(2, SQL_CHAR, readAccess, sizeof(readAccess), &ni_readAccess);
	sql->BindColumn(3, SQL_CHAR, writeAccess, sizeof(writeAccess), &ni_writeAccess);

	int res = sql->ExecuteSQL("select a.usrgrpid, a.readaccess, a.writeaccess "
			"from dm_domaininherit a where a.domainid = %d ", dom.id());
	if(IS_NOT_SQL_SUCCESS(res)) {
		return;
	}

	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		ObjectAccess *oa = ia.get(usrgrpid);
		if(!oa) {
			oa = new ObjectAccess();
			ia.put(usrgrpid, oa);
		}
		//debug0("Domain '%s' adds access %d, %s, %s", dom.name(), usrgrpid,
		//	NULL_IND(readAccess, "(null)"), NULL_IND(writeAccess, "(null)"));
		oa->addDomainAccess(NULL_IND(readAccess, NULL), NULL_IND(writeAccess, NULL));
	}

	Domain *pdom = dom.getDomain();
	if(pdom) {
		addAccessForDomain(*pdom, ia);
	}
}


HashtableById<ObjectAccess> *Model::getAccessForObject(Object &obj)
{
	//debug0("getAccessForObject('%s')", obj.name());

	HashtableById<ObjectAccess> *ret = new HashtableById<ObjectAccess>(true);
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int usrgrpid = 0;
	char readAccess[DB_BOOL_LEN];
	char writeAccess[DB_BOOL_LEN];
	//Xchar grpName[DB_NAME_LEN];
	//Xchar grpEmail[DB_EMAIL_LEN];
	//XSQLLEN ni_grpEmail = 0;
	SQLLEN ni_readAccess = 0, ni_writeAccess = 0;

	sql->BindColumn(1, SQL_INTEGER, &usrgrpid, sizeof(usrgrpid));
	sql->BindColumn(2, SQL_CHAR, readAccess, sizeof(readAccess), &ni_readAccess);
	sql->BindColumn(3, SQL_CHAR, writeAccess, sizeof(writeAccess), &ni_writeAccess);
	//Xsql->BindColumn(4, SQL_CHAR, grpName, sizeof(grpName));
	//Xsql->BindColumn(5, SQL_CHAR, grpEmail, sizeof(grpEmail), &ni_grpEmail);

	//Xint res = sql->ExecuteSQL("select a.usrgrpid, a.readaccess, a.writeaccess, g.name, g.email "
	//X		"from %saccess a, dm_usergroup g where a.%s = %d and g.id = a.usrgrpid ",
	//X		obj.table(), obj.fk(), obj.id());
	int res = sql->ExecuteSQL("select a.usrgrpid, a.readaccess, a.writeaccess "
			"from %saccess a where a.%s = %d ", obj.table(), obj.fk(), obj.id());
	if(IS_NOT_SQL_SUCCESS(res)) {
		return ret;
	}

	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		ObjectAccess *oa = new ObjectAccess();
		//XUserGroup *usrgrp = findOrCreateUserGroup(usrgrpid, grpName, NULL_IND(grpEmail, NULL));
		//Xobj.addAccess(*usrgrp, ((readAccess[0] == 'Y') ? true : false),
		//X	((writeAccess[0] == 'Y') ? true : false));
		//Xdebug0("Object %d has access %d, %s, %s", obj.id(), usrgrpid,
		//	NULL_IND(readAccess, "(null)"), NULL_IND(writeAccess, "(null)"));
		oa->addObjectAccess(NULL_IND(readAccess, NULL), NULL_IND(writeAccess, NULL));
		ret->put(usrgrpid, oa);
	}

	Domain *dom = obj.getDomain();
	if(dom) {
		addAccessForDomain(*dom, *ret);
	}

	return ret;
}

		
void Model::getDomainForObject(Object &obj)
{
	char fromClause[256], whereClause[256];
	sprintf(fromClause, "%s t", obj.table());
	sprintf(whereClause, "t.id = %d and d.id = t.domainid", obj.id());
	AutoPtr<List<Domain> > matches = internalGetDomains(fromClause, whereClause);
	if(matches && (matches->size() > 0)) {
		ListIterator<Domain> iter(*matches);
		obj.setDomain(iter.first());
		// Note that we don't add an incomplete list of children
		// they will be read from the db only if requested
	}
}


void Model::getSummaryForObject(Object &obj)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	char summary[DB_SUMMARY_LEN];
	SQLLEN ni_summary = 0;
	sql->BindColumn(1, SQL_CHAR, summary, sizeof(summary), &ni_summary);

	int res = sql->ExecuteSQL("select t.summary "
			"from %s t where t.id = %d ",
			obj.table(), obj.id());
	if(IS_NOT_SQL_SUCCESS(res)) {
		return;
	}

	res = sql->FetchRow();
	if(IS_SQL_SUCCESS(res)) {
		obj.setSummary(NULL_IND(summary, ""));
	}
}


void Model::getNotesForObject(Object &obj)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	char notes[DB_NOTES_LEN];
	SQLLEN ni_notes = 0;
	sql->BindColumn(1, SQL_CHAR, notes, sizeof(notes), &ni_notes);

	int res = sql->ExecuteSQL("select t.notes "
			"from %s t where t.id = %d ",
			obj.table(), obj.id());
	if(IS_NOT_SQL_SUCCESS(res)) {
		return;
	}

	res = sql->FetchRow();
	if(IS_SQL_SUCCESS(res)) {
		obj.setNotes(NULL_IND(notes, ""));
	}
}


void Model::getCredentialsForProviderObject(ProviderObject &po)
{
	char whereClause[256];
	sprintf(whereClause, "t.id = %d", po.id());

	Credentials *creds = internalGetCredentials(po.table(), whereClause);
	po.setCredentials(creds);
}


void Model::getPropertiesForProviderObject(ProviderObject &obj)
{
	AutoPtr<List<Property> > matches = internalGetProperties(
		obj.table(), obj.fk(), obj.id());
	if(matches) {
		ListIterator<Property> iter(*matches);
		for(Property *prop = iter.first(); prop; prop = iter.next()) {
			obj.setProperty(prop);
		}
	}
}


List<RepositoryIgnorePattern> *Model::getIgnorePatternsForRepositoryDef(ProviderObjectDef &def)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	char pattern[257];
	char isdir[DB_BOOL_LEN];

	sql->BindColumn(1, SQL_CHAR, pattern, sizeof(pattern));
	sql->BindColumn(2, SQL_CHAR, isdir, sizeof(isdir));

	int res = sql->ExecuteSQL("select i.pattern, i.isdir "
			"from dm_repositoryignore i where i.defid = %d ", def.id());
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	List<RepositoryIgnorePattern> *ret = new List<RepositoryIgnorePattern>(true);

	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		ret->add(new RepositoryIgnorePattern(pattern,
			((isdir[0] == 'Y') ? true : false)));
	}

	return ret;
}


ProviderObjectDef *Model::getDefForProviderObject(ProviderObject &obj)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	int id = 0;
	char defName[DB_NAME_LEN];
	int pluginId = 0;
	int pluginVer = 0;
	char pluginLib[257];
	SQLLEN ni_pluginId = 0, ni_pluginVer = 0, ni_pluginLib = 0;

	sql->BindColumn(1, SQL_INTEGER, &id, sizeof(id));
	sql->BindColumn(2, SQL_CHAR, defName, sizeof(defName));
	sql->BindColumn(3, SQL_INTEGER, &pluginId, sizeof(pluginId), &ni_pluginId);
	sql->BindColumn(4, SQL_INTEGER, &pluginVer, sizeof(pluginVer), &ni_pluginVer);
	sql->BindColumn(5, SQL_CHAR, pluginLib, sizeof(pluginLib), &ni_pluginLib);

	int res = sql->ExecuteSQL("select d.id, d.name, d.pluginid, p.version, p.library "
			"from %s o, (dm_providerdef d left join dm_plugin p on p.id = d.pluginid) "
			"where o.id = %d and d.id = o.defid ",
			obj.table(), obj.id());
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	res = sql->FetchRow();
	if(IS_SQL_SUCCESS(res)) {
		Plugin *plugin = NULL;
		if(NULL_IND(pluginId, 0)) {
			plugin = findOrCreatePlugin(pluginId, NULL_IND(pluginVer, 0), NULL_IND(pluginLib, NULL));
		}
		return findOrCreateProviderObjectDef(id, defName, obj.def_kind(), plugin);
	}

	debug0("No def for %s with id %d found - have you set it up correctly?", obj.def_kind(), obj.id());
	return NULL;
}


void Model::getPropertyDefsForProviderObjectDef(ProviderObjectDef &pod)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	char pdName[DB_NAME_LEN];
	char pdReqd[DB_BOOL_LEN];
	char pdApnd[DB_BOOL_LEN];

	sql->BindColumn(1, SQL_CHAR, pdName, sizeof(pdName));
	sql->BindColumn(2, SQL_CHAR, pdReqd, sizeof(pdReqd));
	sql->BindColumn(3, SQL_CHAR, pdApnd, sizeof(pdApnd));

	int res = sql->ExecuteSQL("select pd.name, pd.required, pd.appendable "
			"from dm_propertydef pd where pd.defid = %d ", pod.id());
	if(IS_NOT_SQL_SUCCESS(res)) {
		return;
	}

	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		pod.add(new PropertyDef(pdName,
			((pdReqd[0] == 'Y') ? true : false),
			((pdApnd[0] == 'Y') ? true : false)));
	}
}


void Model::getPropertiesForProviderObjectDef(ProviderObjectDef &def)
{
	AutoPtr<List<Property> > matches = internalGetProperties(
		"dm_providerdef", "defid", def.id(), "engineid", m_engineId);
	if(matches) {
		ListIterator<Property> iter(*matches);
		for(Property *prop = iter.first(); prop; prop = iter.next()) {
			def.setDefProperty(prop);
		}
	}
}


List<RepositoryTextPattern> *Model::getTextPatternsForRepositoryPath(
		Repository &repo, const char *path)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	char rtpPath[DB_PATH_LEN];
	char rtpPattern[257];
	char rtpText[DB_BOOL_LEN];

	sql->BindColumn(1, SQL_CHAR, rtpPath, sizeof(rtpPath));
	sql->BindColumn(2, SQL_CHAR, rtpPattern, sizeof(rtpPattern));
	sql->BindColumn(3, SQL_CHAR, rtpText, sizeof(rtpText));

	int res = sql->ExecuteSQL("select rtp.path, rtp.pattern, rtp.istext "
			"from dm_repositorytextpattern rtp "
			"where rtp.repositoryid = %d and rtp.path = '%s' ", repo.id(), path);
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	List<RepositoryTextPattern> *ret = new List<RepositoryTextPattern>(true);
	for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
		ret->add(new RepositoryTextPattern(rtpPath, rtpPattern,
			((rtpText[0] == 'Y') ? true : false)));
	}

	return ret;
}


char *Model::getNotifyText(int textid)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	char ntName[DB_NAME_LEN];
	sql->BindColumn(1, SQL_CHAR, ntName, sizeof(ntName));

	int res = sql->ExecuteSQL(
		"select nt.name, nt.data from dm_notifytext nt where nt.id = %d ", textid);
	if(IS_NOT_SQL_SUCCESS(res)) {
		return NULL;
	}

	char *ret = NULL;
	res = sql->FetchRow();
	if(IS_SQL_SUCCESS(res)) {
		//debug0("Template name: %s", ntName);

		char *data = NULL;
		SQLLEN ni_data = 0;

		res = sql->GetData(2, SQL_C_BINARY, &data, 0, &ni_data);
		if(IS_SQL_SUCCESS(res)) {
			//debug0("Text size: %ld", ni_data);

			// Get all the data at once.
			data = (char*) malloc(ni_data);
			res = sql->GetData(2, SQL_C_DEFAULT, data, ni_data, &ni_data);
			if(IS_SQL_SUCCESS(res)) {
				ret = data;
				//debug0("Text is: %s", data);
			}
		}
	}

	sql->CloseSQL();
	return ret;
}


void Model::getActionForField(Field &field)
{
	char whereClause[1024];
	sprintf(whereClause, "f.id = %d and a.id = f.actionid", field.id());

	Action *action = internalGetAction("dm_field f", whereClause, false);
	field.setAction(action);
}


void Model::setPluginObject(const char *name, PluginObject *obj)
{
	m_pluginObjects.put(name, obj);
}


PluginObject *Model::getPluginObject(const char *name)
{
	return m_pluginObjects.get(name);
}


bool Model::checkPropertyDefs(const char *name, List<class PropertyDef> *propdefs, int pdId)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();

	char propName[DB_NAME_LEN];
	char propReqd[DB_BOOL_LEN];
	/*bool*/ int propApnd = 0 /*false*/;
	sql->BindColumn(1, SQL_CHAR, propName, sizeof(propName));
	sql->BindColumn(2, SQL_CHAR, propReqd, sizeof(propReqd));
	sql->BindColumn(3, SQL_INTEGER, &propApnd, sizeof(propApnd));

	int res = sql->ExecuteSQL("select p.name, p.required, p.appendable from dm_propertydef p where p.defid = %d", pdId);
	if(IS_SQL_SUCCESS(res)) {
		List<PropertyDef> foundProps;
		for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
			ListIterator<PropertyDef> iter(*propdefs);
			bool found = false;
			for(PropertyDef *def = iter.first(); def; def = iter.next()) {
				if(strcmp(propName, def->name()) == 0) {
					if(((propReqd[0] == 'Y') ? true : false) != def->required()) {
						printf("ERROR: Property '%s' of statement '%s' is already registered with a different required setting\n", propName, name);
						return false;
					}
					//if((propApnd ? true : false) != def->appendable()) {
					//	printf("ERROR: Property '%s' of statement '%s' is already registered with a different appendable setting\n", propName, name);
					//	return false;
					//}
					found = true;
					foundProps.add(def);
					break;
				}
			}

			if(!found) {
				printf("ERROR: Statement '%s' is already registered, but property '%s' is unknown\n", name, propName);
				return false;
			}
		}

		// Now look for missing propertydefs
		if(foundProps.size() != propdefs->size()) {
			debug2("Statement '%s' is already registered, but property counts differ", name);
			ListIterator<PropertyDef> pit(*propdefs);
			for(PropertyDef *pdef = pit.first(); pdef; pdef = pit.next()) {
				ListIterator<PropertyDef> fit(foundProps);
				bool found = false;
				for(PropertyDef *fdef = fit.first(); fdef; fdef = fit.next()) {
					if(fdef == pdef) {
						found = true;
						break;
					}
				}
				if(!found) {
					printf("ERROR: Statement '%s' is already registered, but property '%s' is missing\n", name, pdef->name());
				}
			}
			return false;
		}
	}

	return true;
}


bool Model::installProviderImpl(
	const char *name, const char *plugin,
	int kind, List<class PropertyDef> *propdefs)
{
	AutoPtr<triSQL> sql = m_odbc.GetSQL();
	int res = sql->ExecuteSQL("set schema 'dm'");
	if(IS_NOT_SQL_SUCCESS(res)) {
		return 1;
	}

	// Check to see if we have a plugin of this name, and if so, check the definition is the same
	if(plugin) {
		int pluginId = 0;
		sql->BindColumn(1, SQL_INTEGER, &pluginId, sizeof(pluginId));
		res = sql->ExecuteSQL("select p.id from dm_plugin p where p.library = '%s'", plugin);
		if((IS_SQL_SUCCESS(res)) && (sql->GetRowCount() > 0)) {
			debug2("Plugin '%s' is already registered", plugin);
			res = sql->FetchRow();
			if(IS_SQL_SUCCESS(res)) {
				sql->CloseSQL();

				// Found it, now check the definition is the same
				int pdId = 0;
				char pdName[DB_NAME_LEN];
				int pdKind = 0;
				sql->BindColumn(1, SQL_INTEGER, &pdId, sizeof(pdId));
				sql->BindColumn(2, SQL_CHAR, pdName, sizeof(pdName));
				sql->BindColumn(3, SQL_INTEGER, &pdKind, sizeof(pdKind));
				res = sql->ExecuteSQL("select d.id, d.name, d.kind from dm_providerdef d where d.pluginid = %d", pluginId);
				if((IS_SQL_SUCCESS(res)) && (sql->GetRowCount() > 0)) {
					bool found = false;
					for(res = sql->FetchRow(); IS_SQL_SUCCESS(res); res = sql->FetchRow()) {
						if(STRCASECMP(pdName, name) == 0) {
							if(pdKind == kind) {
								// Statement of same kind found, check properties
								if(!checkPropertyDefs(name, propdefs, pdId)) {
									return false;
								}
							} else {
								printf("ERROR: Statement '%s' of plugin '%s' is already registered with a different kind\n", name, plugin);
								return false;
							}
							found = true;
							break;
						}
					}
					if(!found) {
						printf("ERROR: Plugin '%s' is already registered, but statement '%s' is missing\n", plugin, name);
						return false;
					}

					printf("Plugin '%s' is already registered, definition is the same\n", plugin);
					return true;
				}
			}
		}
	}

	// No plugin, check for statement with this name
	int pdId = 0;
	int pdKind = 0;
	sql->BindColumn(1, SQL_INTEGER, &pdId, sizeof(pdId));
	sql->BindColumn(2, SQL_INTEGER, &pdKind, sizeof(pdKind));
	res = sql->ExecuteSQL("select d.id, d.kind from dm_providerdef d where d.name = '%s'", name);
	if(IS_SQL_SUCCESS(res)) {
		res = sql->FetchRow();
		if(IS_SQL_SUCCESS(res)) {
			sql->CloseSQL();

			debug2("Statement '%s' is already registered", name);
			if(pdKind == kind) {
				// Statement of same kind found, check properties
				if(!checkPropertyDefs(name, propdefs, pdId)) {
					return false;
				}
			} else {
				printf("ERROR: Statement '%s' is already registered with a different kind\n", name);
				return false;
			}

			printf("Statement '%s' is already registered, definition is the same\n", name);
			return true;
		}
	}

	return false;
}
