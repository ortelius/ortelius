#ifndef __audit_h

#define __audit_h


#include "list.h"


/**
 * This is a dummy class that is used for -noexec and populate
 */
class Audit
{
protected:
	int m_deployId;
	int m_currStepId;
	char *m_status;

	virtual void startAuditEntry(class AuditEntry &entry);
	virtual void finishAuditEntry(class AuditEntry &entry);
	virtual void recordInstance(
		class AuditEntry &entry, class ProviderObjectImpl &inst,
		class Context &ctx);
	virtual void recordTransfer(
		class AuditEntry &entry, class Server &target,
		class TransferResult &tr);
	virtual void recordRemoteScript(
		class AuditEntry &entry, class Server &target,
		const char *cmd, int exitCode);

public:
	Audit();
	virtual ~Audit();

	int deploymentId()  { return m_deployId; }

	virtual void startAudit(class Environment *env, class Application *app);
	virtual void finishAudit(int exitCode);

	AuditEntry *newAuditEntry(const char *type);

	virtual void recordAction(class Action &action);

	virtual void writevToAuditLog(int stream, long threadId, const char* fmt, va_list args);
	virtual void writeBufferToAuditLog(int stream, long threadId, const char* buffer, int len);

	void setStatus(const char *status);

	friend class AuditEntry;
};


/**
 * This is the real class that writes audit information to the database
 */
class DatabaseAudit : public Audit
{
private:
	int m_userId;
	class triODBC &m_odbc;
	bool m_auditStarted;
	class TempFile* m_auditLog;
	int m_lineno;

	int allocateNewDeployId();

protected:
	void startAuditEntry(class AuditEntry &entry);
	void finishAuditEntry(class AuditEntry &entry);
	void recordInstance(
		class AuditEntry &entry, class ProviderObjectImpl &inst,
		class Context &ctx);
	void recordTransfer(
		class AuditEntry &entry, class Server &target,
		class TransferResult &tr);
	void recordRemoteScript(
		class AuditEntry &entry, class Server &target,
		const char *cmd, int exitCode);

public:
	DatabaseAudit(int userId, class triODBC &odbc);
	virtual ~DatabaseAudit();

	void startAudit(class Environment *env, class Application *app);
	void finishAudit(int exitCode);

	void recordAction(class Action &action);

	void writevToAuditLog(int stream, long threadId, const char* fmt, va_list args);
	void writeBufferToAuditLog(int stream, long threadId, const char* buffer, int len);
};


class AuditEntry
{
private:
	Audit &m_audit;
	int m_stepId;
	char *m_type;

	AuditEntry(Audit &audit, int stepId, const char *type);

public:
	~AuditEntry();

	int stepId()  { return m_stepId; }
	const char *type()  { return m_type; }

	void start();
	void finish();

	void recordInstance(
		class ProviderObjectImpl &inst, class Context &ctx);
	void recordTransferResults(
		class Server &target, List<class TransferResult> &results);
	void recordRemoteScript(
		class Server &target, const char *cmd, int exitCode);

	friend class Audit;
};


#endif /*__audit_h*/
