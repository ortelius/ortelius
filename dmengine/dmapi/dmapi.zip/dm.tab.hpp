
/* A Bison parser, made by GNU Bison 2.4.1.  */

/* Skeleton interface for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     START_ACTION = 258,
     START_EXPR = 259,
     START_STMTLIST = 260,
     NE = 261,
     GE = 262,
     LE = 263,
     PE = 264,
     ME = 265,
     TE = 266,
     DOLBR = 267,
     CLPL = 268,
     CLMI = 269,
     MAP = 270,
     REDIR = 271,
     NOWS = 272,
     T_BOOL = 273,
     NUM = 274,
     STR = 275,
     STR2 = 276,
     IDENT = 277,
     DOLIDENT = 278,
     T_ACTION = 279,
     T_BREAK = 280,
     T_CASE = 281,
     T_CATCH = 282,
     T_CONTINUE = 283,
     T_DECR = 284,
     T_DEFAULT = 285,
     T_ECHO = 286,
     T_ELSE = 287,
     T_EVAL = 288,
     T_FINALLY = 289,
     T_FOR = 290,
     T_FOREACH = 291,
     T_FUNC = 292,
     T_IF = 293,
     T_IN = 294,
     T_INCR = 295,
     T_NULL = 296,
     T_PARALLEL = 297,
     T_POST = 298,
     T_PRE = 299,
     T_PSLOOP = 300,
     T_RETURN = 301,
     T_SET = 302,
     T_SWITCH = 303,
     T_TRY = 304,
     T_USING = 305,
     T_WHILE = 306,
     NEG = 307
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union 
/* Line 1676 of yacc.c  */
#line 22 "../../../dmapi/dm.y"
value
{

/* Line 1676 of yacc.c  */
#line 22 "../../../dmapi/dm.y"

	class ActionNode     *actn;
	class ActionNodeList *alist;
	class Stmt	     *stmt;
	class StmtList	     *slist;
	class CaseStmt       *cstmt;
	class CaseStmtList   *clist;
	class Node 	     *node;
	class NodeList 	     *nlist;
	bool		      bval;
	int 		      ival;
	char 		     *str;



/* Line 1676 of yacc.c  */
#line 123 "../../../dmapi/dm.tab.hpp"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE yylval;

#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif

extern YYLTYPE yylloc;

