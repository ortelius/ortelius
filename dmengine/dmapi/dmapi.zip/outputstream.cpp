#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <memory.h>

#include "outputstream.h"
#include "platform.h"


///////////////////////////////////////////////////////////////////////////////
// OutputStream
///////////////////////////////////////////////////////////////////////////////

OutputStream::OutputStream()
	: m_buffer(NULL), m_len(0), m_refCount(0), m_autoNewline(true)
{}


OutputStream::OutputStream(bool autoNewline)
	: m_buffer(NULL), m_len(0), m_refCount(0), m_autoNewline(autoNewline)
{}


OutputStream::~OutputStream()
{
	if(m_buffer) { free(m_buffer); m_buffer = NULL; }
}


void OutputStream::addRef()
{
	m_refCount++;
	debug3("addRef() - count now %d", m_refCount);
}


void OutputStream::releaseRef()
{
	m_refCount--;
	debug3("releaseRef() - count now %d", m_refCount);
	if(m_refCount == 0) {
		debug3("ref count zero on outputstream - deleting");
		delete this;
	}
}


void OutputStream::writeToStdOut(const char *fmt, ...)
{
	va_list args;
	va_start(args, fmt);
	writevToStdOut(0, fmt, args);
	va_end(args);
}


void OutputStream::writevToStdOut(long threadId, const char *fmt, va_list args)
{
	// Keeps trying to print the string into a buffer and increasing the size
	// of the buffer until it fits.  m_buffer is then increased to hold just
	// the new string, not the whole of the new buffer.
	int size = 1024;
	char *temp, *np;
	if((temp = (char*) malloc(size)) == NULL) {
		// out of memory!
		return;
	}
	*temp = '\0';
	while(1) {
		int n = vsnprintf(temp, size, fmt, args);
		if((n > -1) && (n < size)) {
			if(m_buffer) {
				m_buffer = (char*) realloc(m_buffer, m_len + n + 2);
				// if this is not the first line we automatically start a new line
				if(m_autoNewline) {
					sprintf(&m_buffer[m_len], "\n%s", temp);
					m_len += n + 1;
				} else {
					sprintf(&m_buffer[m_len], "%s", temp);
					m_len += n;
				}
				free(temp);
			} else {
				m_buffer = temp;
				m_len = n;
			}
			return;
		}

		if(n > -1) {
			size = n + 1;	// Precisely what is needed as glibc 2.1 returns the required size
		} else {
			size *= 2;		// Dumb approach of doubling the buffer until we fit
		}
		if((np = (char*) realloc(temp, size)) == NULL) {
			// out of memory!
			free(temp);
			return;
		}
		temp = np;
	}
}


void OutputStream::writeBufferToStdOut(long threadId, const char *buffer, int len)
{
	if(m_buffer) {
		m_buffer = (char*) realloc(m_buffer, m_len + len + 1);
		memcpy(&m_buffer[m_len], buffer, len);
		m_len += len;
		m_buffer[m_len] = '\0';
	} else {
		m_buffer = (char*) malloc(len + 1);
		memcpy(m_buffer, buffer, len);
		m_len = len;
		m_buffer[m_len] = '\0';
	}
}


void OutputStream::writeToStdErr(const char *fmt, ...)
{
	va_list args;
	va_start(args, fmt);
	writevToStdErr(0, fmt, args);
	va_end(args);
}


void OutputStream::writevToStdErr(long threadId, const char *fmt, va_list args)
{
	// error just redirects to out so that the order of the lines is preserved
	writevToStdOut(0, fmt, args);
}


void OutputStream::writeBufferToStdErr(long threadId, const char *buffer, int len)
{
	// error just redirects to out so that the order of the lines is preserved
	writeBufferToStdOut(0, buffer, len);
}


void OutputStream::readFromStdIn()
{
	// Read input from stdin
	char line[1024];
	while(fgets(line, sizeof(line), stdin)) {
		//debug0("STDIN: %s", line);
		writeBufferToStdOut(0, line, strlen(line));
	}
	//debug0("STDIN END");
}


const char *OutputStream::buffer()
{
	return m_buffer ? m_buffer : "";
}


long OutputStream::size()
{
	return m_len;
}
