#ifndef __thread_h

#define __thread_h


#include "list.h"
#include "platform.h"


class Runable
{
public:
	virtual void run() = 0;
};


class Thread
{
protected:
	THREAD_ID m_id;
#ifndef WIN32
	bool m_joined;
#endif /*WIN32*/
	static void *s_globallock;

public:
	Thread();
	virtual ~Thread();

	THREAD_ID id()  { return m_id; };
	virtual void start();
	void stop();
	void waitFor();
#if defined(__LINUX__) || defined(__linux__)
	int waitForWithTimeout();
#endif /*Linux*/
	
	virtual void run();

	static long currentThreadId();

	static void lock();
	static void unlock();
};


class DMThread : public virtual Thread
{
private:
	class DMThreadList &m_threadList;
	class DMException *m_ex;

protected:
	int m_exitCode;
	class Context *m_ctx;

public:
	DMThread(class DMThreadList &threadList, class Context *ctx);
	virtual ~DMThread();

	void start();

	class DMException *exception();
	int exitCode();

	void run();

	virtual void execute(class Context &ctx);
};


class DMThreadList : public virtual List<DMThread>
{
private:
	int m_threadLimit;
	List<DMThread> *m_activeThreads;
	List<DMThread> *m_pendingThreads;

	bool threadStart(DMThread *thread);
	DMThread *waitForOne();

public:
	DMThreadList(int threadLimit);
	~DMThreadList();

	int waitForAll();

	friend class DMThread;
};

#endif /*__thread_h*/
