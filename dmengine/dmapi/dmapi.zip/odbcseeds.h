//
// odbcseeds - encryption seeds for trident.odbc - included in triodbc.cpp and
//             in the encryption program setodbc.cpp
//
static unsigned long odbcseed1=0x56231282;
static unsigned long odbcseed2=0x12873101;
static unsigned long odbcseed3=0x1498fb1a;
