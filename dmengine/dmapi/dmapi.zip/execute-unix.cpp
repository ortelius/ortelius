#include "execute.h"
#include "cmdline.h"
#include "outputstream.h"

#include <unistd.h>
#include <stdlib.h>
#include <strings.h>
#include <errno.h>
#include <sys/wait.h>
#include <poll.h>
#include <signal.h>

#include <stdio.h>
#if 0
#define TRIDEBUG(msg) { printf msg; printf("\n"); }
#else
#define TRIDEBUG(msg) 
#endif
#define TRIERROR(msg) { printf msg; printf("\n"); }


int Fork()
{
	// Like "fork()" but intercepts failures.
	int res=fork();
	if (res==-1)
	{
		perror("fork");
		exit(1);
	}
	return res;
}


extern "C" void ChildProcessDies(int signal)
{
	//switch(signal) {
	//case SIGCHLD:
	//	TRIDEBUG(("ChildProcessDies - SIGCHLD"));
	//	break;
	//default:
	//	TRIDEBUG(("ChildProcessDies - %d", signal));
	//	break;
	//}
}


int executeAndCapture(
	IOutputStream &ostr, CmdLine &cmd,
	const char *cwd, bool ShowOutput, long threadId,
	int *ChildExitStatus, CapturedData **cd,
	char **EnvPtr)
{
	int StdOut[2];
	int StdErr[2];
	int StdIn[2];
	int ipc[2];
	int ErrNum=0;
	char ReadBuffer[8192];
	//NOT USED: fd_set	ReadDescriptors;
	//NOT USED: fd_set	WriteDescriptors;
	
	TRIDEBUG(("ExecuteAndCapture - Enter"));

	signal(SIGCHLD,ChildProcessDies);

	*cd = new CapturedData();

	pipe(StdOut);	// For capturing the standard out stream of the running process.
	pipe(StdErr);	// For capturing the standard error stream of the running process.
	pipe(StdIn);	// For capturing the standard input stream of the running process.
	pipe(ipc);	// For notifying the parent if the child could not launch the specified program image.

	bool ChildProgramIsRunning=true;

	char **argv = cmd.toArgv();

	int pid=Fork();
	switch(pid)
	{
		case 0:
			// Child Process - run the program.
			close(ipc[0]);		// Close the "read" side of the pipe
			close(StdOut[0]);	// Close the "read" side of the pipe
			close(StdErr[0]);	// Close the "read" side of the pipe
			close(StdIn[1]);	// Close the "write" side of the pipe.
			close(0);		// Close standard in
			dup(StdIn[0]);		// make standard in the read end of the "stdin" pipe
			close(1);		// Close standard out
			dup(StdOut[1]);		// make standard out the "write" end of the "stdout" pipe
			close(2);		// Close standard err
			dup(StdErr[1]);		// make standard err the "write" end of the "stderr" pipe
			// Change the working directory if one has been specified
			if(cwd) {
				if(chdir(cwd) != 0) {
					fprintf(stderr, "Unable to chdir to '%s'\n", cwd);
					exit(1);
				}
			}
			//
			// Now try and run the program.
			//
			if(EnvPtr) {
				execve(argv[0],argv,EnvPtr);
			} else {
				execv(argv[0],argv);
			}
			////fprintf(stderr, "argv[0]=\"%s\"\n", argv[0]);
			perror("exec failed");	// ### This lets us see why something failed
			//
			// If we got here the program failed to run. Write the value of "errno" to
			// the IPC pipe to allow our parent to determine why we failed to run.
			//
			ErrNum=errno;
			write(ipc[1],(void *)&ErrNum,sizeof(ErrNum));
			exit(1);
		default:
			// Parent Process - set up to read stdin/stdout and pass back to client.
			close(ipc[1]);		// Close the "write" side of the pipe
			close(StdOut[1]);	// Close the "write" side of the pipe
			close(StdErr[1]);	// Close the "write" side of the pipe
			close(StdIn[0]);	// Close the "read" side of the pipe

			close(StdIn[1]);	// Close the "write" side of the pipe as we won't be writing anything - RHT 16/04/2012

			//
			// Use poll to block until something is ready
			// to read.
			//
			struct pollfd fds[3];
			//
			// Standard Output
			//
			fds[0].fd = StdOut[0];
			fds[0].events = POLLIN;
			//
			// Standard Error
			//
			fds[1].fd = StdErr[0];
			fds[1].events = POLLIN;
			//
			// InterProcess Communication
			//
			fds[2].fd = ipc[0];
			fds[2].events = POLLIN;
			//
			// Now loop, waiting for data from the child...
			//
			int Event;
			do
			{
				fds[0].revents = 0;
				fds[1].revents = 0;
				fds[2].revents = 0;
				int BytesRead;
				Event=0;
TRIDEBUG(("Before poll"));
				int s = poll(fds,3,-1);
TRIDEBUG(("After poll; s=%d, fds[0].revents=%d, fds[1].revents=%d, fds[2].revents=%d", s, fds[0].revents, fds[1].revents, fds[2].revents));				
				if (s == -1)
				{
					if (errno!=EINTR)
					{
						// poll has failed in some way (other than being interrupted
						// by SIGCHLD which we expect and can allow for...
						ErrNum=errno;
						TRIDEBUG(("poll failed - ErrNum = %d", ErrNum));
					}
					else
					{
						// RHT 13/04/2012 - EINTR means interupted, no error and try again with continue
						// poll was interrupted by a signal. Was it SIGCHLD? If so,
						// then "ChildProgramIsRunning" will have been cleared down
						// by the signal handler...
						//
						//if (ChildProgramIsRunning==true)
						//{
						//	// Couldn't have been SIGCHLD then...
						//	ErrNum=errno;
						//}
						TRIDEBUG(("poll failed EINTR - ErrNum = %d", ErrNum));
						continue;
					}
				}
				if (fds[0].revents & POLLIN)
				{
					// Something arriving on standard output
					Event=1;
TRIDEBUG(("Before read stdout"));				
					BytesRead=read(StdOut[0],ReadBuffer,sizeof(ReadBuffer));
TRIDEBUG(("After read stdout; BytesRead=%d", BytesRead));				
					if (BytesRead > 0)
					{
						(*cd)->appendStandardOut(ReadBuffer, BytesRead);
						
						// RHT 10/04/2012 - allow DM to show progress
						if(ShowOutput) {
							ostr.writeBufferToStdOut(threadId, ReadBuffer, BytesRead);
						}
					}
					else if ((BytesRead == -1) && (errno == EINTR))
					{
						printf("caught you\n");
						continue;
					}
				}
				if (fds[2].revents & POLLIN)
				{
					Event=1;
					// Something arriving on the ipc error channel.
					// This can be a genuine message from the child process if the
					// exec failed OR it can be spurious caused by the other end of
					// the pipe closing. Read the data and, if no bytes are read,
					// set ErrNum back to 0. Either way, stop the loop since there'll
					// be no more data to read.
					//
					int p = read(ipc[0],(void *)&ErrNum,sizeof(ErrNum));
					TRIDEBUG(("p = %d; ErrNum = %d", p, ErrNum));
					if (!p)
					{
						ErrNum=0;
					}
					//ChildProgramIsRunning=false;
				}
				if (fds[1].revents & POLLIN)
				{
					Event=1;
					// Something arriving on standard error
TRIDEBUG(("Before read stderr"));				
					BytesRead=read(StdErr[0],ReadBuffer,sizeof(ReadBuffer));
TRIDEBUG(("After read stderr; BytesRead=%d", BytesRead));				
					if (BytesRead > 0)
					{
						(*cd)->appendStandardErr(ReadBuffer, BytesRead);
						
						// RHT 10/04/2012 - allow DM to show progress
						if(ShowOutput) {
							ostr.writeBufferToStdErr(threadId, ReadBuffer, BytesRead);
						}
					}
					else if ((BytesRead == -1) && (errno == EINTR))
					{
						printf("caught you 2\n");
						continue;
					}
				}
				if (!Event && ChildProgramIsRunning)
				{
TRIDEBUG(("Before waitpid"));				
					int pid2 = waitpid(pid,ChildExitStatus,WNOHANG);
TRIDEBUG(("After waitpid; pid2=%d", pid2));				
					if (pid2 == pid || pid2 == -1)
					{
						//
						// Child has exited - loop a few more times, to ensure we get
						// all the data
						//
						// printf("pid2 == pid ... getting read to exit\n");
						ChildProgramIsRunning=false;
					}
				}
			}
			while (ChildProgramIsRunning);
	}

	TRIDEBUG(("ExecuteAndCapture - Exit - rc: %d", ErrNum));
	return ErrNum;
}
