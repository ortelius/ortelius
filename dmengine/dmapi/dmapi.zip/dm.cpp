#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include <errno.h>

#ifdef WIN32
#include <direct.h>
#include <io.h>
#include <windows.h>
#include <process.h>
#else
#include <unistd.h>
#include <dlfcn.h>
#include <pthread.h>
#endif /*WIN32*/

#include "dm.h"
#include "node.h"
#include "lexer.h"
#include "scopestack.h"
#include "exceptions.h"
#include "thread.h"
#include "model.h"
#include "dropzone.h"
#include "context.h"
#include "extended.h"
#include "function.h"
#include "expr.h"
#include "charptr.h"
#include "triodbc.h"
#include "audit.h"

// For factories
#include "repository.h"
#include "transfer.h"
#include "notify.h"
#include "transfer.h"
#include "datasource.h"
#include "filefind.h"
#include "properties.h"
#include "modify.h"
#include "pathname.h"
#include "task.h"


extern int yyparse(void *buffer);


///////////////////////////////////////////////////////////////////////////////

int clearDirectory(const char *pathname)
{
	int res = 0;	// success
	FileFind finder(pathname, NULL);
	if(finder.find()) {
		do {
			if(finder.isDirectory()) {
				// Directory
				if(!finder.isDots()) {
					char *fp = finder.fullpath();
					debug3("recursing into '%s'", fp);
					if(clearDirectory(fp) != 0) {
						SAFE_FREE(fp);
						res = 1;
						break;
					}
					SAFE_FREE(fp);
				}
			} else {
				// File, so attempt to remove it
				char *fp = finder.fullpath();
				debug3("removing '%s'", fp);
				CHMOD(fp, FILE_WRITE_PERMISSIONS);
				if(unlink(fp) != 0) {
					debug0("clearDirectory failed to unlink '%s'", fp);
					res = 1;
					break;
				}
				SAFE_FREE(fp);
			}
		} while(finder.next());
	}
	finder.close();

	debug3("removing folder '%s'", pathname);
	CHMOD(pathname, FILE_WRITE_PERMISSIONS);
	if(RMDIR(pathname) != 0)
	{
//#if defined(WIN32) && defined(_DEBUG)
#ifdef WIN32
		LPVOID lpMsgBuf;
		FormatMessage( 
			FORMAT_MESSAGE_ALLOCATE_BUFFER | 
			FORMAT_MESSAGE_FROM_SYSTEM | 
			FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL,
			GetLastError(),
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
			(LPTSTR) &lpMsgBuf,
			0,
			NULL 
		);
		debug0("rmdir(\"%s\") failed: %s", pathname, lpMsgBuf);
		LocalFree(lpMsgBuf);
#endif /*WIN32 && _DEBUG*/
		res = 1;
	}
	return res;
}


///////////////////////////////////////////////////////////////////////////////
// TempFile
///////////////////////////////////////////////////////////////////////////////


TempFile::TempFile(int num)
{
	char fn[1024];
#ifdef WIN32
	sprintf(fn, "%s\\tdm.%d.%d.tmp", getenv("TEMP"), getpid(), num);
#else
	sprintf(fn, "/tmp/tdm.%d.%d.tmp", getpid(), num);
#endif
	m_filename = strdup(fn);
}


TempFile::~TempFile()
{
	SAFE_FREE(m_filename);
}


FILE *TempFile::open(bool forRead /*= false*/, bool append /*= false*/)
{
#ifdef WIN32
	return fopen(m_filename, (forRead ? "rb" : (append ? "ab+" : "wb")));
#else
	return fopen(m_filename, (forRead ? "r" : (append ? "a+" : "w")));
#endif /*WIN32*/
}


bool TempFile::unlink()
{
	// Make writable (dfo files are created read-only)
	CHMOD(m_filename, FILE_WRITE_PERMISSIONS);

	// Remove the file
	return (::unlink(m_filename) == 0) ? true : false;
}


///////////////////////////////////////////////////////////////////////////////
// TempFolder
///////////////////////////////////////////////////////////////////////////////


TempFolder::TempFolder(const char *deployId)
{
	char fn[1024];
#ifdef WIN32
	sprintf(fn, "%s\\tdm.%s", getenv("TEMP"), deployId);
#else
	sprintf(fn, "/tmp/tdm.%s", deployId);
#endif
	m_pathname = strdup(fn);
}


TempFolder::~TempFolder()
{
	SAFE_FREE(m_pathname);
}


bool TempFolder::mkdir(bool empty)
{
	struct stat sb;
	if(stat(m_pathname, &sb) == -1) {
		debug3("TempFolder::mkdir('%s') - stat returned -1", m_pathname);
		if(errno == ENOENT) {
			// Doesn't exist - so create it
			bool ret = (MKDIR(m_pathname) == 0) ? true : false;
	
			if(!ret) {
				// Create failed - create the parent and then retry
				TempFolder *tmp = parent();
				if(tmp) {
					debug1("TempFolder::mkdir('%s') - creating parent '%s'", m_pathname, tmp->pathname());
					if(tmp->mkdir(true)) {
						ret = (MKDIR(m_pathname) == 0) ? true : false;
					}
					SAFE_DELETE(tmp);
				}
			}

			return ret;
		} else {
			// Unable to stat
			return false;
		}
	}
	// Is it a directory?
	if(sb.st_mode & STAT_IS_DIRECTORY) {
		// Directory
		debug2("TempFolder::mkdir('%s') - dir exists", m_pathname);
		if(!empty) {
			// Empty check not required
			return true;
		}
		// Is it empty?
		FileFind finder(m_pathname, NULL);
		bool found = false;
		if(finder.find()) {
			do {
				if(!finder.isDots()) {
					// Found something, so not empty
					debug1("TempFolder::mkdir('%s') - not empty", m_pathname);
					found = true;
					break;
				}
			} while(finder.next());
		}

		return found ? false : true;
	}

	// File with same name as the directory we want
	debug0("TempFolder::mkdir('%s') - file exists with same name", m_pathname);
	return false;
}


bool TempFolder::unlink()
{
	debug3("TempFolder::unlink('%s')", m_pathname);
	return (clearDirectory(m_pathname) == 0) ? true : false;
}


TempFolder *TempFolder::parent()
{
	const char *ls = strrchr(m_pathname, DIR_SEP_CHAR);
	if(!ls) {
		return NULL;
	}

	int len = ls - m_pathname;

	char *pf = (char*) malloc(len + 1);
	strncpy(pf, m_pathname, len);
	pf[len] = '\0';
	
	TempFolder *ret = new TempFolder("dummy");
	ret->m_pathname = pf;
	return ret;
}


///////////////////////////////////////////////////////////////////////////////
// DM
///////////////////////////////////////////////////////////////////////////////


DM::DM()
	: m_environment(NULL), m_application(NULL), m_application2(NULL), m_model(NULL),
	  /*m_deployId(0), m_depMajor(0),*/ m_tempFiles(true), m_tempFolders(true),
	  m_dropzones(true, true), m_dmhome(NULL), m_initializationDone(false),
	  m_stack(*this)
{}


DM::~DM()
{
	m_environment = NULL;			// storage owned by model
	m_application = NULL;			// storage owned by model
	m_application2 = NULL;			// storage owned by model
	m_model = NULL;					// created on stack - will destroy itself
	// m_tempFiles, m_tempFolders and m_dropzones are members so should be deleted automatically
}


void DM::setModel(Model *model)
{
	m_model = model;
}


Model *DM::getModel()
{
	return m_model;
}


class EngineConfig &DM::getEngineConfig()
{
	if(!m_model) {
		throw RuntimeError("Model not yet initialised - can't read engine config");
	}

	return m_model->getEngineConfig();
}


bool DM::setTargetEnvironment(const char *env)
{
	m_environment = m_model ? m_model->getEnvironment(env) : NULL;
	return m_environment ? true : false;
}


bool DM::setTargetEnvironment(int envid)
{
	m_environment = m_model ? m_model->getEnvironment(envid) : NULL;
	return m_environment ? true : false;
}


Environment *DM::getTargetEnvironment()
{
	return m_environment;
}


bool DM::setTargetApplication(const char *app)
{
	m_application = m_environment ? m_environment->application(app) : NULL;
	return m_application ? true : false;
}


bool DM::setTargetApplication(int appid)
{
	// TODO: This should be m_environment->application(appid)
	m_application = m_model ? m_model->getApplication(appid) : NULL;
	return m_application ? true : false;
}


class Application *DM::getTargetApplication()
{
	return m_application;
}


bool DM::setSecondApplication(int appid)
{
	if(appid < 0) {
		// Special values:
		// -1 = latest (or parent application if no versions)
		// -2 = latest on branch (or parent application if no versions)
		//      new version will be created on the selected branch (i.e. the branch in inherited)
		Application *parent = getTargetApplication();
		m_application2 = parent ? parent->getLatestVersion(/*branch*/) : NULL;
	} else {
		m_application2 = m_model ? m_model->getApplication(appid) : NULL;
	}
	return m_application2 ? true : false;
}


class Application *DM::getSecondApplication()
{
	return m_application2;
}


void DM::setDialogCredentials(class Credentials *creds)
{
	m_dialogCredentials = creds;
}


class Credentials *DM::getDialogCredentials()
{
	return m_dialogCredentials;
}


bool DM::setCurrentUser(const char *username)
{
	if(!m_model) {
		return false;
	}

	User *currentUser = m_model->getUser(username);
	m_model->setCurrentUser(currentUser);
	return currentUser ? true : false;
}


class User *DM::getCurrentUser()
{
	return m_model ? m_model->getCurrentUser() : NULL;
}


void DM::updateUserLastLogin(User &user)
{
	if(m_model) {
		m_model->updateUserLastLogin(user);
	}
}


Server *DM::getPhysicalServer(const char *name)
{
	return m_environment ? m_environment->server(name) : NULL;
}


Component *DM::getComponent(const char *name)
{
	return m_model ? m_model->getComponent(name) : NULL;
}


Repository *DM::getRepository(const char *name)
{
	return m_model ? m_model->getRepository(name) : NULL;
}


class Notify *DM::getNotifier(const char *name)
{
	return m_model ? m_model->getNotifier(name) : NULL;
}


class Notify *DM::getNotifier(int id)
{
	return m_model ? m_model->getNotifier(id) : NULL;
}


class Datasource *DM::getDatasource(const char *name)
{
	return m_model ? m_model->getDatasource(name) : NULL;
}


class Action *DM::getAction(const char *name)
{
	return m_model ? m_model->getAction(name) : NULL;
}


class Task *DM::getTask(const char *name)
{
	return m_model ? m_model->getTask(name) : NULL;
}


class Task *DM::getTask(int taskid)
{
	return m_model ? m_model->getTask(taskid) : NULL;
}


// TODO: These will be removed after we add a Notification object
class User *DM::getUser(int id)
{
	return m_model ? m_model->getUser(id) : NULL;
}


class UserGroup *DM::getUserGroup(int id)
{
	return m_model ? m_model->getUserGroup(id) : NULL;
}


char *DM::getNotifyText(int id)
{
	return m_model ? m_model->getNotifyText(id) : NULL;
}


ActionNode *DM::firstActionNode()
{
	return m_model ? m_model->firstActionNode() : NULL;
}


ActionNode *DM::getActionNode(const char *name)
{
	return m_model ? m_model->getActionNode(name) : NULL;
}


int DM::deployId()
{
	return getAudit().deploymentId();
}


class Audit &DM::getAudit()
{
	if(!m_model) {
		throw RuntimeError("Model not yet initialised - can't deploy");
	}

	return m_model->getAudit();
}


class Audit &DM::getDummyAudit()
{
	if(!m_model) {
		throw RuntimeError("Model not yet initialised - can't deploy");
	}

	return m_model->getDummyAudit();
}


void DM::startAudit()
{
	Audit &audit = getAudit();
	audit.startAudit(m_environment, m_application);
	m_stack.setGlobal("DEPLOY_ID", audit.deploymentId());
}


void DM::finishAudit(int exitCode)
{
	getAudit().finishAudit(exitCode);
}


FILE *DM::createTemporaryFile(char **filename)
{
	TempFile *tmp = new TempFile(m_tempFiles.size() + 1);
	m_tempFiles.add(tmp);
	if(filename) {
		*filename = (char*) tmp->filename();
	}
	return tmp->open();
}


bool DM::createTemporaryFolder(const char *deployId, char **pathname, bool empty)
{
	TempFolder *tmp = createTemporaryFolder(deployId, empty);

	if(tmp && pathname) {
		*pathname = (char*) tmp->pathname();
	}

	return tmp ? true : false; 
}


TempFolder *DM::createTemporaryFolder(const char *deployId, bool empty)
{
	TempFolder *ret = new TempFolder(deployId);

	if(ret->mkdir(empty)) {
		m_tempFolders.add(ret);
		return ret;
	}

	// If -forceunlink specified have a go at cleaning up and retry
	if(getenv("triforceunlink")) {
		debug1("mkdir '%s' failed - trying to delete and recreate", ret->pathname());
		if(ret->unlink()) {
			if(ret->mkdir(true)) {
				m_tempFolders.add(ret);
				return ret;
			}
		}
	}

	return NULL;
}


TempFolder *DM::getTemporaryFolder(const char *deployId)
{
	TempFolder tmp(deployId);

	ListIterator<TempFolder> iter(m_tempFolders);
	for(TempFolder *f = iter.first(); f; f = iter.next()) {
		if(strcmp(f->pathname(), tmp.pathname()) == 0) {
			return f;
		}
	}
	return NULL;
}


void DM::removeTemporaryFolder(TempFolder *folder)
{
	m_tempFolders.remove(folder);
}


void DM::deleteTemporaryFilesAndFolders()
{
	if(!getenv("trinounlink")) {
		writeToLogFile("Removing temporary files");

		ListIterator<TempFile> fit(m_tempFiles);
		for(TempFile *f = fit.first(); f; f = fit.next()) {
			if(!f->unlink()) {
				writeToLogFile("Failed to remove temporary file \"%s\"", f->filename());
			}
		}

		ListIterator<TempFolder> dit(m_tempFolders);
		for(TempFolder *d = dit.first(); d; d = dit.next()) {
			if(!d->unlink()) {
				writeToLogFile("Failed to remove temporary folder \"%s\"", d->pathname());
			}
		}
	}
}


Dropzone *DM::getDropzone(const char *name)
{
	return m_dropzones.get(name);
}


Dropzone *DM::newDropzone(const char *name, bool autoUnlink)
{
	Dropzone *ret = new Dropzone(*this, name, autoUnlink);
	m_dropzones.put(ret->name(), ret);
	return ret;
}


void DM::removeDropzone(Dropzone *dropzone)
{
	dropzone->remove();
	m_dropzones.remove(dropzone->name());		// This will delete the dropzone object
}


char *DM::getHostname()
{
	char hostname[1024];
	gethostname(hostname, sizeof(hostname));
	return strdup(hostname);
}


typedef int (*PLUGIN_START_FN_PTR)(DM&); 


bool DM::loadPlugin(const char *plugin)
{
	PLUGIN_START_FN_PTR fn = NULL;

#ifdef WIN32
	HINSTANCE handle = LoadLibrary(plugin);
#else
	char buf[1024];
	sprintf(buf, "%s.so", plugin);
	void *handle = dlopen(buf, RTLD_LAZY);
#endif /*WIN32*/
	
	if(handle) {
#ifdef WIN32
		fn = (PLUGIN_START_FN_PTR) GetProcAddress(handle, "PluginStart");
#else
		fn = (PLUGIN_START_FN_PTR) dlsym(handle, "PluginStart");
#endif /*WIN32*/
		if(!fn) {
			writeToLogFile("Failed to find required functions in plugin \"%s\".", plugin);
#ifdef WIN32
			FreeLibrary(handle);
#else
			dlclose(handle);
#endif /*WIN32*/
		}
	} else {
		writeToLogFile("Failed to find plugin \"%s\".", plugin);
	}

	if(fn)
	{
		// Invoke the startup function.
		if((*fn)(*this) == 0) {
			writeToLogFile("Plugin \"%s\" loaded.", plugin);
			return true;
		} 

		writeToLogFile("Plugin \"%s\" failed to initialise.", plugin);
	}

	return false;
}


bool DM::installPlugin(const char *plugin)
{
	PLUGIN_START_FN_PTR fn = NULL;

#ifdef WIN32
	HINSTANCE handle = LoadLibrary(plugin);
#else
	char buf[1024];
	sprintf(buf, "%s.so", plugin);
	void *handle = dlopen(buf, RTLD_LAZY);
#endif /*WIN32*/
	
	if(handle) {
#ifdef WIN32
		fn = (PLUGIN_START_FN_PTR) GetProcAddress(handle, "PluginInstall");
#else
		fn = (PLUGIN_START_FN_PTR) dlsym(handle, "PluginInstall");
#endif /*WIN32*/
		if(!fn) {
			writeToLogFile("Failed to find required functions in plugin \"%s\".", plugin);
#ifdef WIN32
			FreeLibrary(handle);
#else
			dlclose(handle);
#endif /*WIN32*/
		}
	} else {
		writeToLogFile("Failed to find plugin \"%s\".", plugin);
	}

	if(fn)
	{
		// Invoke the install function.
		if((*fn)(*this) == 0) {
			writeToLogFile("Plugin \"%s\" installed.", plugin);
			return true;
		}

		writeToLogFile("Plugin \"%s\" failed to install.", plugin);
	}

	return false;
}


bool DM::installProviderImpl(
	const char *name, const char *plugin,
	int kind, List<class PropertyDef> *propdefs)
{
	return m_model ? m_model->installProviderImpl(name, plugin, kind, propdefs) : false;
}


int DM::parse(const char *filename)
{
	struct stat sb;
	if(stat(filename, &sb) != 0) {
		fprintf(stderr, "Input file '%s' not found\n", (const char*) filename);
		return 1;
	}

	int buflen = sb.st_size;
	char *input = (char*) malloc(buflen + 1);
	FILE *f = fopen(filename, "r");
	if(!f) {
		fprintf(stderr, "Error opening '%s'\n", (const char*) filename);
		return 1;
	}

	int read = fread(input, 1, buflen, f);
	fclose(f);

	if(read == 0) {
		return 1;
	}

	input[read] = '\0';
	LexerBuffer lb(action_lexer, input, filename);

	yyparse_param param;
	param.buffer = &lb;
	int res = yyparse(&param);

	SAFE_FREE(input);			// we have finished with the input buffer now
	// TODO: if an exception is raised we still need to free the memory try catch(...) throw???

	if(res != 0) {
		if(param.ex) {
			param.ex->print(*this);
		}

		return 2;
	}

	if(!param.actnlist) {
		return 3;
	}

	if(!getenv("trinosemantic")) {
		param.actnlist->semanticCheck(*this);
	}

	return 0;
}


int DM::doNotify(int nfyid, const char *from, const char *subject, int templateid)
{
	if(!m_model) {
		printf("Model not set\n");
		return -1;
	}

	try {
		Notify *notify = m_model->getNotifier(nfyid);
		if(!notify) {
			writeToStdOut("Notify %d not found or not configured", nfyid);
			return 1;
		}

		DMArray *tos = NULL;
		Variable *var = m_stack.get("ARGV");
		if(var) {
			tos = var->getArray();
		}
		if(!tos || (tos->count() == 0)) {
			writeToStdOut("No recipients specified");
			return 1;
		}

		DMArray *recipients = m_stack.newGlobalArray("RECIPIENTS", true);

		AutoPtr<StringList> keys = tos->keys();
		StringListIterator iter(*keys);
		for(const char *key = iter.first(); key; key = iter.next()) {
			var = tos->get(key);
			if(var) {
				const char *sotid = var->value();
				if(sotid) {
					ObjectKindAndId otid(sotid);
					Object *obj = NULL;
					switch(otid.getObjectKind()) {
					case OBJ_KIND_USER:
						obj = m_model->getUser(otid.getId());
						break;
					case OBJ_KIND_USERGROUP:
						obj = m_model->getUserGroup(otid.getId());
						break;
					default:
						writeToStdOut("Invalid recipient type: '%s'", sotid);
						continue;
					}
					if(obj) {
						recipients->add(new Variable(NULL, obj));
					}
				}
			}
		}

		List<Server> emptySet;
		Context ctx(*this, emptySet, m_stack);

		bool envPushed = false;
		if(getTargetEnvironment()) {
			m_stack.push(getTargetEnvironment()->getVars());
			envPushed = true;
		}

		bool appPushed = false, parentPushed = false;
		Application *app = getTargetApplication();
		if(app) {
			// If the app is an app ver, then push the parent application first
			if(app->kind() == OBJ_KIND_APPVERSION) {
				Application *parent = app->getParent();
				if(!parent) {
					throw RuntimeError(m_stack, "Application version '%s' has no parent", app->name());
				}
				m_stack.push(parent->getVars());
				parentPushed = true;
			}
			m_stack.push(app->getVars());
			appPushed = true;
		}

		StmtList *args = new StmtList();
		// TODO: allow multiple recipients
		args->add(new Stmt(strdup("to"), new Node(NODE_ARRAY, new Node(NODE_NLVAR, new Node(NODE_IDOROBJ, strdup("RECIPIENTS"))), new Node(0))));
		args->add(new Stmt(strdup("from"), new Node(NODE_STR, strdup(from))));
		args->add(new Stmt(strdup("subject"), new Node(NODE_STR, strdup(subject))));
		ExtendedStmt stmt(strdup("notify"), args);
		Audit &audit = getDummyAudit();
		AuditEntry *ae = audit.newAuditEntry("notify");
		OutputStream body;
		if(templateid != 0) {
			char *text = m_model->getNotifyText(templateid);
			if(!text) {
				throw RuntimeError("Template %d is empty - message not sent", templateid);
			}
			Node expandedText(NODE_STR, text, true);	// will free text on delete
			ExprPtr etext = expandedText.evaluate(ctx);
			ConstCharPtr stext = etext->stringify();
			body.writeToStdOut("%s", (const char*) stext);
		} else {
			body.readFromStdIn();
		}

		notify->notify(1, stmt, ae, body, NULL, ctx);

		if(appPushed) {
			m_stack.pop(APPLICATION_SCOPE);
		}
		if(parentPushed) {
			m_stack.pop(APPLICATION_SCOPE);
		}
		if(envPushed) {
			m_stack.pop(ENVIRONMENT_SCOPE);
		}
		return 0;
	} catch(DMException &e) {
		fprintf(stderr, "Exception: %s\n", e.getMessage());
		return 1;
	} catch(...) {
		fprintf(stderr, "Unhandled exception\n");
	}

	return -1;
}


int DM::providerTest(OBJECT_KIND kind, int id)
{
	if(!m_model) {
		printf("Model not set\n");
		return -1;
	}

	try {
		switch(kind) {
		case OBJ_KIND_RESPOSITORY: {
			Repository *repo = m_model->getRepository(id);
			if(!repo) {
				writeToStdOut("Repository %d not found or not configured", id);
				return 1;
			}

			List<Server> emptySet;
			Context ctx(*this, emptySet, m_stack);

			ExtendedStmt stmt(strdup("checkout"), new StmtList());
			if(!repo->testProvider(stmt, ctx)) {
				writeToStdOut("Test of repository \"%s\" failed!", repo->name());
				return 1;
			}
			}
			return 0;

		case OBJ_KIND_NOTIFY: {
			Notify *notify = m_model->getNotifier(id);
			if(!notify) {
				writeToStdOut("Notify %d not found or not configured", id);
				return 1;
			}

			List<Server> emptySet;
			Context ctx(*this, emptySet, m_stack);

			ExtendedStmt stmt(strdup("notify"), new StmtList());
			if(!notify->testProvider(stmt, ctx)) {
				writeToStdOut("Test of notify \"%s\" failed!", notify->name());
				return 1;
			}

			StmtList *args = new StmtList();
			args->add(new Stmt(strdup("to"), new Node(getCurrentUser())));
			args->add(new Stmt(strdup("subject"), new Node(NODE_STR, strdup("Test notification from DM2"))));
			args->add(new Stmt(strdup("logfile"), new Node(NODE_STR, strdup("$DMHOME/smtp.log"), true)));
			args->add(new Stmt(strdup("isTestMode"), new Node(true)));	// Turn on log to screen
			ExtendedStmt stmt2(strdup("notify"), args);
			Audit &audit = getDummyAudit();
			AuditEntry *ae = audit.newAuditEntry("notify");
			OutputStream body;
			body.writeToStdOut("Test notification from Dynamic DevOps Suite");
			//body.writeToStdOut("Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.");
			//body.writeToStdOut("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas pretium lacinia quam nec malesuada. In vehicula orci vitae lacus convallis accumsan. Etiam eleifend metus eu fringilla viverra. Etiam pretium eleifend tellus, at condimentum velit fermentum non. Phasellus dictum ultrices ullamcorper. Proin vestibulum aliquam mauris at fringilla. Aliquam erat volutpat. Nam id sapien a orci vulputate viverra in auctor elit. Nulla facilisi. In vitae tortor libero.\n"
			//	"Nulla viverra, libero et euismod fringilla, urna odio malesuada neque, at ornare urna libero id metus. Sed fermentum, tortor nec eleifend molestie, enim elit varius augue, nec luctus risus nisl a velit. Donec blandit blandit sapien in accumsan. Phasellus dignissim nec lacus et pulvinar. Donec semper urna vitae lacinia interdum. Morbi tellus purus, pharetra eget risus non, volutpat venenatis dolor. Pellentesque a lorem pulvinar, aliquam odio ut, elementum ligula. Proin et scelerisque turpis, vitae sodales diam. Proin ultricies sed ligula quis porttitor. Suspendisse tincidunt nibh nec feugiat eleifend. Curabitur rhoncus tincidunt varius.\n"
			//	"Integer tempor odio at tortor aliquet hendrerit. Nullam rhoncus gravida auctor. Pellentesque vitae massa vel mi congue bibendum. Mauris porttitor mattis massa eu vestibulum. Quisque auctor viverra condimentum. Duis felis sapien, porttitor et massa sed, sodales gravida massa. Nulla mollis arcu non consectetur vehicula.\n"
			//	"Maecenas interdum neque diam, iaculis tincidunt ligula adipiscing vel. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce lobortis eros eget suscipit consectetur. Aenean suscipit sem in rhoncus mattis. Suspendisse placerat pretium nulla eget adipiscing. Aliquam et imperdiet lectus. Nulla at orci pharetra lorem sollicitudin malesuada. Suspendisse blandit convallis purus.\n"
			//	"Donec porttitor lobortis justo vel consectetur. Integer sit amet blandit tortor. Phasellus tortor arcu, gravida at erat vel, faucibus imperdiet odio. Quisque non accumsan metus, non porta tortor. Morbi in erat faucibus, consequat mi sit amet, imperdiet lorem. Phasellus varius, odio ut pulvinar lacinia, magna felis viverra sapien, eget porttitor odio quam in ligula. Vestibulum molestie, nulla ut aliquet blandit, massa sem luctus massa, ac dignissim elit velit a augue. Integer viverra sit amet orci ac commodo. Fusce dictum euismod urna vel porttitor.\n"
			//	"Cras blandit egestas mauris et gravida. Duis lorem diam, tempor in vestibulum sit amet, vestibulum ut massa. Vestibulum ipsum libero, ornare eu elementum accumsan, consectetur at enim. Aliquam dignissim velit sed metus rutrum, id feugiat orci tempus. Duis id hendrerit lorem, sit amet hendrerit sem. Pellentesque volutpat nisl sed erat fringilla, nec porttitor augue interdum. Praesent molestie in odio eu feugiat.\n"
			//	"Pellentesque vitae auctor dui, ut pretium dolor. Nullam aliquam semper ornare. Vivamus eu erat eget dui auctor vulputate. Donec ornare id libero id venenatis. Nulla facilisi. Pellentesque nec rhoncus augue. Donec faucibus egestas mattis. Suspendisse potenti. Integer nisl risus, elementum ac odio non, luctus pulvinar tortor. Pellentesque vestibulum purus vel odio rhoncus, vitae interdum lorem pharetra. Vivamus ultricies volutpat est, at vulputate magna egestas at. Integer ac blandit mauris, nec posuere elit.\n"
			//	"Suspendisse potenti. Sed et posuere lorem. Ut sagittis erat ut ante porta, vitae interdum dui lobortis. Cras posuere condimentum mauris. Morbi iaculis nibh a quam eleifend imperdiet. Proin in placerat arcu. Vestibulum pulvinar tortor enim. Integer imperdiet, elit at condimentum tempus, nulla lacus lacinia risus, eu porttitor velit libero id risus. Fusce pulvinar tristique posuere. Quisque porta lorem at interdum fringilla. Maecenas imperdiet tellus eu hendrerit ultrices. Donec fermentum volutpat consequat. Aliquam eu dolor feugiat, aliquet mauris non, cursus nisi. Phasellus eu dui ac dui consectetur tincidunt.\n"
			//	"Duis ultricies enim convallis ultrices consequat. Aenean ornare egestas ipsum eu eleifend. Mauris sed nisl ornare, sodales mauris nec, interdum massa nunc.");
			notify->notify(1, stmt2, ae, body, NULL, ctx);
			}
			return 0;
		case OBJ_KIND_DATASOURCE: {
			Datasource *ds = m_model->getDatasource(id);
			if(!ds) {
				writeToStdOut("Datasource %d not found or not configured", id);
				return 1;
			}

			List<Server> emptySet;
			Context ctx(*this, emptySet, m_stack);

			ExtendedStmt stmt(strdup("query"), new StmtList());
			if(!ds->testProvider(stmt, ctx)) {
				writeToStdOut("Test of datasource \"%s\" failed!", ds->name());
				return 1;
			}
			}
			return 0;
		}
	} catch(DMException &e) {
		fprintf(stderr, "Exception: %s\n", e.getMessage());
		return 1;
	} catch(...) {
		fprintf(stderr, "Unhandled exception\n");
	}
	return -1;
}


void DM::writeToLogFile(const char* fmt, ...)
{
	va_list args;
	va_start(args, fmt);
	if(/*m_Logging*/ true) {
		char *logFileName;
		if(m_dmhome) {
			logFileName = (char *) malloc(strlen(m_dmhome) + 15);
			sprintf(logFileName, "%s%s%s", m_dmhome, DIR_SEP_STR, "dm.log");	// RHT 19/02/2014 - log should go in home
		} else {
			logFileName = strdup("dm.log");
		}
		FILE *out = fopen(/*m_LogFileName*/ logFileName, "a+");
		if (out) {
			time_t timenow;
			struct tm *t;
			time(&timenow);
			t = localtime(&timenow);
			fprintf(out,"%04d/%02d/%02d %02d:%02d:%02d [%d] [0x%08lx] ",
				t->tm_year+1900, t->tm_mon+1, t->tm_mday,
				t->tm_hour, t->tm_min, t->tm_sec,
				getpid(), Thread::currentThreadId());
			vfprintf(out, fmt, args);
			fprintf(out, "\n");
			fclose(out);
		} else {
			throw RuntimeError("Could not write to logfile \"%s\"", /*m_LogFileName*/ logFileName);
		}
		SAFE_FREE(logFileName);
	}
	va_end(args);
}


void DM::writeToStdOut(const char* fmt, ...)
{
	va_list args;
	va_start(args, fmt);
	writevToStdOut(0, fmt, args);
	va_end(args);
}


void DM::writevToStdOut(long threadId, const char* fmt, va_list args)
{
	vfprintf(stdout, fmt, args);
	fprintf(stdout, "\n");

	// Also record in db log
	if(m_model) {
		m_model->getAudit().writevToAuditLog(1, threadId, fmt, args);
	}
}


void DM::writeBufferToStdOut(long threadId, const char *buffer, int len)
{
	write(1, buffer, len);

	// Also record in db log
	if(m_model) {
		m_model->getAudit().writeBufferToAuditLog(1, threadId, buffer, len);
	}
}


void DM::writeToStdErr(const char* fmt, ...)
{
	va_list args;
	va_start(args, fmt);
	writevToStdErr(0, fmt, args);
	va_end(args);
}


void DM::writevToStdErr(long threadId, const char* fmt, va_list args)
{
	bool useColor = getenv("triusecolor") ? true : false;
	if(useColor) {
		fprintf(stderr, "\x1b[31m");
	}
	vfprintf(stderr, fmt, args);
	fprintf(stderr, (useColor ? "\x1b[0m\n" :  "\n"));

	// Also record in db log
	if(m_model) {
		m_model->getAudit().writevToAuditLog(2, threadId, fmt, args);
	}
}


void DM::writeBufferToStdErr(long threadId, const char *buffer, int len)
{
	bool useColor = getenv("triusecolor") ? true : false;
	if(useColor) {
		fprintf(stderr, "\x1b[31m");
	}
	write(2, buffer, len);
	if(useColor) {
		fprintf(stderr, "\x1b[0m");
	}

	// Also record in db log
	if(m_model) {
		m_model->getAudit().writeBufferToAuditLog(2, threadId, buffer, len);
	}
}


IOutputStream *DM::toOutputStream()
{
	return this;
}


void DM::exitWithError(const char* fmt, ...)
{
	va_list args;
	va_start(args, fmt);
	vfprintf(stderr, fmt, args);
	fprintf(stderr,"\n");

	if(/*m_Logging*/ true) {
		FILE *out = fopen(/*m_LogFileName*/ "dm.log", "a+");
		if (out) {
			time_t timenow;
			struct tm *t;
			time(&timenow);
			t = localtime(&timenow);
			fprintf(out,"%04d/%02d/%02d %02d:%02d:%02d [%d] [0x%08lx] ",
				t->tm_year+1900, t->tm_mon+1, t->tm_mday,
				t->tm_hour, t->tm_min, t->tm_sec,
				getpid(), Thread::currentThreadId());
			vfprintf(out, fmt, args);
			fprintf(out, "\n");
			fclose(out);
		} else {
			fprintf(stderr, "Could not write to logfile \"%s\"", /*m_LogFileName*/ "dm.log");
		}

	}
	va_end(args);
	exit(1);
}


const char *DM::getDefaultFields()
{
	return "environments,username,password,applications";
}


const char *DM::getTriField(int field)
{
	char envvar[16];
	sprintf(envvar, "TRIFIELD%d", field);
	return getenv(envvar);
}


void DM::registerBuiltins()
{
	// Setup the built in statements (deploy etc.) and functions
	ExtendedStmtImplRegistry::instance().registerBuiltIns();
	FunctionNodeImplRegistry::instance().registerBuiltIns();

	// Setup the built in repositories (harvest etc.)
	RepositoryImplRegistry::instance().registerBuiltIns(*this);

	// Setup the built in transfer providers (ftp etc.)
	TransferProviderImplRegistry::instance().registerBuiltIns();

	// Setup the built in notify providers
	NotifyProviderImplRegistry::instance().registerBuiltIns(*this);

	// Setup the built in datasource providers
	DatasourceProviderImplRegistry::instance().registerBuiltIns(*this);

	// Setup the built in modifiers
	ModifyProviderImplRegistry::instance().registerBuiltIns(*this);

	// Setup the built in path formats
	PathNameImplRegistry::instance().registerBuiltIns();

	// Setup the built in tasks
	TaskImplRegistry::instance().registerBuiltIns();
}


void DM::setEnvironmentVariables(char **envp)
{
	while(envp && *envp) {
		char *dstr = strdup(*envp);
		char *eq = strchr(dstr,'=');
		if(eq) { *eq = '\0'; }
		char *name = dstr;
		char *value = (eq+1);
		m_stack.setGlobal(name, value);
		free(dstr);
		envp++;
	}
}


/**
 * Any remaining command line arguments that are not preceded by a switch come
 * here. Two kinds of argument are supported: name/value pairs and positional
 * arguments. Name/value pairs must appear first, followed by positional
 * arguments:
 *
 *   dm ... name1=value1 name2=value2 arg1 arg2
 *
 * Name/value pairs result in a global variable of the same name being set.
 * Positional arguments go into a global variable called "ARGV" and a variable
 * called "ARGC" is set to the count of these arguments.
 */
void DM::setCommandLineVariables(char **argv)
{
	// Handle name/value pairs first
	for(; *argv; argv++) {
		if(!strstr(*argv, "=")) {
			// End of name/value pairs
			break;
		}

		char *arg = strdup(*argv);
		char *eq = strstr(arg, "=");
		*eq = '\0'; eq++;
		m_stack.setGlobal(arg, eq);
		free(arg);
	}

	// Now deal with positional arguments
	DMArray *ht = m_stack.newGlobalArray("ARGV");
	int argc = 0;

	for(; *argv; argv++) {
		char key[32];
		sprintf(key, "%d", argc);
		ht->put(key, new Variable(NULL, *argv));
		argc++;
	}

	m_stack.setGlobal("ARGC", argc);
}


/**
 * Set global variables of the form:
 * TRIFIELD['environments'] = $TRIFIELD1
 * TRILISTBOX['1']['PACKAGENAME'] = $TRI_PACKAGENAME_1
 */
void DM::setTriFieldVariables(char** envp)
{
	const char *fields = getenv("trifields");
	if(!fields) {
		fields = getDefaultFields();
	}

	DMArray *ht = m_stack.newGlobalArray("TRIFIELD");

	// Loop through field list, reading TRIFIELDn and storing it in ht
	int n = 0;
	char *temp = strdup(fields);
	for(char *f = strtok(temp, ","); f; f = strtok(NULL, ",")) {
		n++;
		const char *trifieldn = getTriField(n);
		if(trifieldn) {
			ht->put(f, new Variable(NULL, trifieldn));
		}
	}
	SAFE_FREE(temp);

	const char *listboxSelections = getenv("TRILISTBOXSELECTIONS");
	int selections = (listboxSelections ? atoi(listboxSelections) : 0);
	if(selections == 0) {
		return;
	}

	ht = m_stack.newGlobalArray("TRILISTBOX");

	// Now go through all the env var looking for TRI_<columnname>_<n> vars
	while(envp && *envp) {
		// This looks like us
		if(strncmp(*envp, "TRI_", 4) == 0) {
			char *dstr = strdup(*envp);
			char *eq = strchr(dstr,'=');
			if(eq) { *eq = '\0'; }
			char *name = dstr;
			char *value = (eq+1);
			int len = strlen(name);

			// Must be at least TRI_A_1 and end in a number
			if((len > 7) && isdigit(name[len-1])) {
				for(len = len - 1; (len > 4) && isdigit(name[len-1]); len--) { /*empty*/ }
				if((len > 4) && (name[len-1] == '_')) {
					// Got one
					name[len-1] = '\0';
					char *column = &name[4];
					char *selection = &name[len];
					int sel = atoi(selection);

					if((sel > 0) && (sel <= selections)) {
						Variable *row = ht->get(selection);
						if(!row) {
							row = new Variable(NULL, new DMArray(false, true, true));
							ht->put(selection, row);
						}
						DMArray *rowarr = row->getArray();
						if(rowarr) {
							debug2("TRILISTBOX['%s']['%s'] = '%s'", selection, column, value);
							rowarr->put(column, new Variable(NULL, value));
						}
					}
				}
			}
			free(dstr);
		}
		envp++;
	}
}


void DM::initialize(const char *baseDir, char **argv, char **envp)
{
	if(m_initializationDone) {
		return;
	}

	m_initializationDone = true;

	registerBuiltins();

	// Set up the stack with env vars, trifield array and globals
	setEnvironmentVariables(envp);
	setCommandLineVariables(argv);
	setTriFieldVariables(envp);

	m_stack.setGlobal("DMHOME", baseDir);
	m_stack.setGlobal("TRIDM_PLATFORM", DM_PLATFORM);
	debug2("Setting $$ = %d", getpid());
	m_stack.setGlobal("$", getpid());
}


int DM::runAction(Action &action)
{
	if(!m_initializationDone) {
		writeToStdErr("FATAL ERROR: Initialization not done before running script");
		return 1;
	}

	debug2("Running action '%s'", action.name());

	bool envPushed = false, appPushed = false, parentPushed = false;

	if(getTargetEnvironment()) {
		m_stack.push(getTargetEnvironment()->getVars());
		envPushed = true;
	}

	Application *app = getTargetApplication();
	if(app) {
		// If the app is an app ver, then push the parent application first
		if(app->kind() == OBJ_KIND_APPVERSION) {
			Application *parent = app->getParent();
			if(!parent) {
				throw RuntimeError(m_stack, "Application version '%s' has no parent", app->name());
			}
			m_stack.push(parent->getVars());
			parentPushed = true;
		}
		m_stack.push(app->getVars());
		appPushed = true;
	}

	int ret = internalRunAction(action);

	try {
		if(appPushed) {
			m_stack.pop(APPLICATION_SCOPE);
		}
		if(parentPushed) {
			m_stack.pop(APPLICATION_SCOPE);
		}

		if(envPushed) {
			m_stack.pop(ENVIRONMENT_SCOPE);
		}
	} catch(DMException &e) {
		writeToLogFile("Caught exception (2)");
		e.print(*this);
		ret = 3;
	} catch(...) {
		writeToStdErr("FATAL ERROR: Unhandled exception");
		writeToLogFile("Unhandled exception (2)");
		ret = 3;
	}

	return ret;
}


int DM::runTask(Task &task)
{
	if(!m_initializationDone) {
		writeToStdErr("FATAL ERROR: Initialization not done before running task");
		return 1;
	}

	debug2("Running task '%s'", task.name());

	bool envPushed = false, appPushed = false, parentPushed = false;

	if(getTargetEnvironment()) {
		m_stack.push(getTargetEnvironment()->getVars());
		envPushed = true;
	}

	Application *app = getTargetApplication();
	if(app) {
		// If the app is an app ver, then push the parent application first
		if(app->kind() == OBJ_KIND_APPVERSION) {
			Application *parent = app->getParent();
			if(!parent) {
				//throw RuntimeError(m_stack, "Application version '%s' has no parent", app->name());
				writeToStdErr("FATAL ERROR: Application version '%s' has no parent", app->name());
				return 1;
			}
			m_stack.push(parent->getVars());
			parentPushed = true;
		}
		m_stack.push(app->getVars());
		appPushed = true;
	}

	StmtList *args = new StmtList();

	// TODO: Find a more extensible way to do this
	if(strcmp(task.taskType(), "approve") == 0) { 
		OutputStream note;
		note.readFromStdIn();
		args->add(new Stmt(strdup("approve"), new Node(NODE_LOOKUP, strdup("approve_approved"))));
		args->add(new Stmt(strdup("note"), new Node(NODE_STR, DUP_NULL(note.buffer()))));
	} else if((strcmp(task.taskType(), "move") == 0)
			|| (strcmp(task.taskType(), "copy") == 0)
			|| (strcmp(task.taskType(), "request") == 0)) {
		OutputStream note;
		note.readFromStdIn();
		args->add(new Stmt(strdup("note"), new Node(NODE_STR, DUP_NULL(note.buffer()))));
	} else if(strcmp(task.taskType(), "createversion") == 0) {
		Application *predecessor = getSecondApplication();
		if(predecessor) {
			debug0("predecessor is %d '%s'", predecessor->id(), predecessor->name());
			args->add(new Stmt(strdup("predecessor"), new Node(predecessor)));
		}
	}

	ExtendedStmt stmt(strdup("runtask"), args);
	Audit &audit = getDummyAudit();
	AuditEntry *ae = audit.newAuditEntry("task");

	int ret = -1;
	try {
		if(getTargetEnvironment()) {
			Context ctx(*this, *(getTargetEnvironment()->getServers()), m_stack);
			Scope *scope = task.getVars(1, stmt, ae, ctx);
			//scope->setStatementObject(this);
			//Scope *scope = new Scope(TASK_SCOPE, task);
			ctx.stack().push(scope);
			try {
				ret = task.run(1, stmt, ae, ctx);
			} catch(...) {
				m_stack.pop(TASK_SCOPE);
				throw;
			}
			m_stack.pop(TASK_SCOPE);
		} else {
			List<Server> emptyList;
			Context ctx(*this, emptyList, m_stack);
			Scope *scope = task.getVars(1, stmt, ae, ctx);
			//scope->setStatementObject(this);
			//Scope *scope = new Scope(TASK_SCOPE, task);
			ctx.stack().push(scope);
			try {
				ret = task.run(1, stmt, ae, ctx);
			} catch(...) {
				m_stack.pop(TASK_SCOPE);
				throw;
			}
			m_stack.pop(TASK_SCOPE);
		}
		//getAudit().setStatus("Finished");
	} catch(ReturnException &/*e*/) {
		// Normal return via return statement
		//getAudit().setStatus("Finished");
		ret = 0;
	} catch(DMException &e) {
		writeToLogFile("Caught exception");
		e.print(*this);
		if(e.getStacktrace()) {
			writeToStdErr(e.getStacktrace());
		}
		//getAudit().setStatus(e.getMessage());
		ret = 2;
	} catch(...) {
		writeToLogFile("Unhandled exception");
		writeToStdErr("FATAL ERROR: Unhandled exception");
		//getAudit().setStatus("Unhandled exception");
		ret = 2;
	}

	try {
		if(appPushed) {
			m_stack.pop(APPLICATION_SCOPE);
		}
		if(parentPushed) {
			m_stack.pop(APPLICATION_SCOPE);
		}

		if(envPushed) {
			m_stack.pop(ENVIRONMENT_SCOPE);
		}
	} catch(DMException &e) {
		writeToLogFile("Caught exception (2)");
		e.print(*this);
		ret = 3;
	} catch(...) {
		writeToStdErr("FATAL ERROR: Unhandled exception");
		writeToLogFile("Unhandled exception (2)");
		ret = 3;
	}

	return ret;
}


int DM::internalRunAction(Action &action)
{
	//// Parse the action script
	//ActionNode *act = NULL;
	//try {
	//	List<Server> emptyList;
	//	Context ctx(*this, emptyList, m_stack);
	//	act = action.getActionNode(ctx);
	//	if(!act) {
	//		// Shouldn't happen, as should raise an exception
	//		return 1;
	//	}
	//} catch(SyntaxError &e) {
	//	e.print(*this);
	//	getAudit().setStatus(e.getMessage());
	//	return 1;
	//} catch(DMException &e) {
	//	getAudit().setStatus(e.getMessage());
	//	e.print(*this);
	//	return 1;
	//}

	//Scope *actscope = new Scope(ACTION_SCOPE, act, *act, true);
	//m_stack.push(actscope);

	////m_stack.dump();

	//int ret = 0;

	//try {
	//	writeToLogFile("Running action '%s'", action.name());
	//	if(getTargetEnvironment()) {
	//		Context ctx(*this, *(getTargetEnvironment()->getServers()), m_stack);
	//		act->execute(ctx);
	//	} else {
	//		List<Server> emptyList;
	//		Context ctx(*this, emptyList, m_stack);
	//		act->execute(ctx);
	//	}
	//	getAudit().setStatus("Finished");
	//} catch(ReturnException &/*e*/) {
	//	// Normal return via return statement
	//	getAudit().setStatus("Finished");
	//} catch(DMException &e) {
	//	writeToLogFile("Caught exception");
	//	e.print(*this);
	//	if(e.getStacktrace()) {
	//		writeToStdErr(e.getStacktrace());
	//	}
	//	getAudit().setStatus(e.getMessage());
	//	ret = 2;
	//} catch(...) {
	//	writeToLogFile("Unhandled exception");
	//	writeToStdErr("FATAL ERROR: Unhandled exception");
	//	getAudit().setStatus("Unhandled exception");
	//	ret = 2;
	//}

	//try {
	//	m_stack.pop(ACTION_SCOPE);
	//} catch(DMException &e) {
	//	writeToLogFile("Caught exception (2)");
	//	e.print(*this);
	//	ret = 3;
	//} catch(...) {
	//	writeToStdErr("FATAL ERROR: Unhandled exception");
	//	writeToLogFile("Unhandled exception (2)");
	//	ret = 3;
	//}

	//return ret;

	// Use ExtendedStmt implementation mechanism to perform the action call.
	// This will handle parsing scripts in files or the db, mapping to external
	// scripts and even calling plugin actions directly.
	try {
		ExtendedStmt stmt(&action);
		if(getTargetEnvironment()) {
			Context ctx(*this, *(getTargetEnvironment()->getServers()), m_stack);
			stmt.execute(ctx);
		} else {
			List<Server> emptyList;
			Context ctx(*this, emptyList, m_stack);
			stmt.execute(ctx);
		}
		getAudit().setStatus("Finished");
	} catch(SyntaxError &e) {
		e.print(*this);
		getAudit().setStatus(e.getMessage());
		return 1;
	} catch(ReturnException &/*e*/) {
		// Normal return via return statement
		getAudit().setStatus("Finished");
	} catch(DMException &e) {
		getAudit().setStatus(e.getMessage());
		e.print(*this);
		return 1;
	} catch(...) {
		writeToLogFile("Unhandled exception");
		writeToStdErr("FATAL ERROR: Unhandled exception");
		getAudit().setStatus("Unhandled exception");
		return 2;
	}

	return 0;
}


int DM::internalDeployComponent(class Component &comp)
{
	writeToStdOut("Deploying component '%s'", comp.name());

	m_stack.push(comp.getVars());

	int ret = 0;

	//m_stack.dump();

	// Build a pretend deploy statement - the component will come from the stack
	yylloc_param loc;
	loc.file_num     = loc.frag_num    = 0;
	loc.first_column = loc.last_column = 0;
	loc.first_line   = loc.last_line   = 0;

	StmtList *args = new StmtList();
	ExtendedStmt deployComp(loc, strdup("deploy"), args, NULL, NULL);

	try {
		writeToLogFile("Deploying component '%s'", comp.name());
		if(getTargetEnvironment()) {
			Context ctx(*this, *(getTargetEnvironment()->getServers()), m_stack);
			AutoPtr<List<Server> > servers = comp.getServerSubset(ctx);
			Context newctx(ctx, *servers);
			deployComp.execute(newctx);
		} else {
			// This is probably pointless
			List<Server> emptyList;
			Context ctx(*this, emptyList, m_stack);
			deployComp.execute(ctx);
		}
		//getAudit().setStatus("Finished");
	} catch(ReturnException &/*e*/) {
		// Normal return via return statement
		//getAudit().setStatus("Finished");
	} catch(DMException &e) {
		writeToLogFile("Caught exception");
		e.print(*this);
		if(e.getStacktrace()) {
			writeToStdErr(e.getStacktrace());
		}
		getAudit().setStatus(e.getMessage());
		ret = 2;
	} catch(...) {
		writeToLogFile("Unhandled exception");
		writeToStdErr("FATAL ERROR: Unhandled exception");
		getAudit().setStatus("Unhandled exception");
		ret = 2;
	}

	try {
		m_stack.pop(COMPONENT_SCOPE);
	} catch(DMException &e) {
		writeToLogFile("Caught exception (2)");
		e.print(*this);
		ret = 3;
	} catch(...) {
		writeToStdErr("FATAL ERROR: Unhandled exception");
		writeToLogFile("Unhandled exception (2)");
		ret = 3;
	}

	return ret;
}


void DM::recordDeployedToEnvironment(class Application &app, bool success)
{
	debug0("Updating appsinenv");

	Environment *env = getTargetEnvironment();
	if(env) {
		app.recordDeployedToEnv(*this, *env, success);
	}
}


int DM::internalDeployApplication(class Application &app)
{
	debug0("Deploying application '%s'", app.name());

	Action *action = app.getCustomAction();
	if(action) {
		// Custom action, this takes precedence over components
		int res = internalRunAction(*action);
		recordDeployedToEnvironment(app, true);
		cleanup();
		return res;
	}

	// No custom action, so assume that this is a component based deployment
	Action *preAction = app.getPreAction();
	Action *postAction = app.getPostAction();
	List<Component> *components = app.getComponents();

	int res = 0;
	if(preAction) {
		res = internalRunAction(*preAction);
	}
	if(components) {
		ListIterator<Component> iter(*components);
		for(Component *comp = iter.first(); comp; comp = iter.next()) {
			internalDeployComponent(*comp);
		}
		recordDeployedToEnvironment(app, true);
	}
	if(postAction) {
		res = internalRunAction(*postAction);
	}
	return res;
}


int DM::doDeployment()
{
	if(!m_initializationDone) {
		writeToStdErr("FATAL ERROR: Initialization not done before running script");
		return 1;
	}

	// We have to have an application of some sort
	Application *app = getTargetApplication();
	if(!app) {
		writeToStdErr("No application selected");
		return 1;
	}
	AutoPtr<List<Application> > parents = app->getParentList();
	if(!parents) {
		writeToStdErr("Unable to get application parents");
		return 1;
	}
	// Check that we have something to run or deploy
	bool somethingToDo = false;
	ListIterator<Application> ait(*parents);
	for(Application *a = ait.first(); a; a = ait.next()) {
		if(a->getCustomAction()
			|| (a->getComponents() && (a->getComponents()->size() > 0))) {
			somethingToDo = true;
			break;
		}
	}
	if(!somethingToDo) {
		writeToStdErr("Application has no action or components to deploy");
		return 1;
	}

	// Setup the stack:

	// Environment goes on first
	bool envPushed = false;
	if(getTargetEnvironment()) {
		m_stack.push(getTargetEnvironment()->getVars());
		envPushed = true;
	}

	// Then the application OR the parent application and its application version
	bool parentPushed = false;
	// If the app is an app ver, then push the parent application first
	if(app->kind() == OBJ_KIND_APPVERSION) {
		Application *parent = app->getParent();
		if(!parent) {
			throw RuntimeError(m_stack, "Application version '%s' has no parent", app->name());
		}
		m_stack.push(parent->getVars());
		parentPushed = true;
	}
	m_stack.push(app->getVars());

	int ret = internalDeployApplication(*app);

	try {
		m_stack.pop(APPLICATION_SCOPE);
		if(parentPushed) {
			m_stack.pop(APPLICATION_SCOPE);
		}

		if(envPushed) {
			m_stack.pop(ENVIRONMENT_SCOPE);
		}
	} catch(DMException &e) {
		writeToLogFile("Caught exception (2)");
		e.print(*this);
		ret = 3;
	} catch(...) {
		writeToStdErr("FATAL ERROR: Unhandled exception");
		writeToLogFile("Unhandled exception (2)");
		ret = 3;
	}

	return ret;
}


void DM::cleanup()
{
	ExtendedStmtImplRegistry::cleanup();
	FunctionNodeImplRegistry::cleanup();
	RepositoryImplRegistry::cleanup();
	TransferProviderImplRegistry::cleanup();
	NotifyProviderImplRegistry::cleanup();
	DatasourceProviderImplRegistry::cleanup();
	ModifyProviderImplRegistry::cleanup();
}


void DM::setPluginObject(const char *name, PluginObject *obj)
{
	if(m_model) {
		m_model->setPluginObject(name, obj);
	}
}


PluginObject *DM::getPluginObject(const char *name)
{
	return m_model ? m_model->getPluginObject(name) : NULL;
}
