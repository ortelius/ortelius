#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>

#include "platform.h"

char *platform_vsprintf(const char *fmt, va_list ap)
{
#ifdef WIN32
	long size = strlen(fmt) + 500;	// First Guess
	char * ret = (char*) malloc(size);
	int cc = _vsnprintf(ret, size-1, fmt, ap);
	ret[size-1] = '\0';

	while(cc == -1) {
		// Not enough space
		size += 500;	// another 500 bytes
		ret = (char*)realloc(ret, size);
		//va_start(ap,SQLformat);
		cc = _vsnprintf(ret, size-1, fmt, ap);
		ret[size-1] = '\0';
	}
#else
	char dummy[1];
	int cc = vsnprintf(dummy, sizeof(dummy), fmt, ap);
	//va_end(ap);
	char *ret = (char*) malloc(cc+10);
	//va_start(ap,SQLformat);
	vsprintf(ret, fmt, ap);
#endif
	return ret;
}


static int s_debuglevel = 0;


int debuglevel()
{
	return s_debuglevel;
}


void setdebuglevel(int level)
{
	s_debuglevel = level;
}


void debug0(const char *fmt, ...)
{
	va_list args;
	va_start(args, fmt);
	char *msg = platform_vsprintf(fmt, args);
	printf("DEBUG0: %s\n", msg);
	free(msg);
	va_end(args);
}


void debug1(const char *fmt, ...)
{
	if(s_debuglevel >= 1) {
		va_list args;
		va_start(args, fmt);
		char *msg = platform_vsprintf(fmt, args);
		printf("DEBUG1: %s\n", msg);
		free(msg);
		va_end(args);
	}
}


void debug2(const char *fmt, ...)
{
	if(s_debuglevel >= 2) {
		va_list args;
		va_start(args, fmt);
		char *msg = platform_vsprintf(fmt, args);
		printf("DEBUG2: %s\n", msg);
		free(msg);
		va_end(args);
	}
}


void debug3(const char *fmt, ...)
{
	if(s_debuglevel >= 3) {
		va_list args;
		va_start(args, fmt);
		char *msg = platform_vsprintf(fmt, args);
		printf("DEBUG3: %s\n", msg);
		free(msg);
		va_end(args);
	}
}


void catFile(const char *filename)
{
	printf("file: %s\n----- 8< -----\n", filename);
	FILE *f = fopen(filename, "r");
	if(f) {
		char buf[1024];
		int n;
		while(n = fread(buf, 1, sizeof(buf)-1, f)) {
			buf[n] = '\0';
			printf("%s", buf);
		}
		fclose(f);
	}
	printf("----- 8< -----\n");
}


void catFile1(const char *filename)
{
	if(s_debuglevel >= 1) {
		catFile(filename);
	}
}


void catFile2(const char *filename)
{
	if(s_debuglevel >= 2) {
		catFile(filename);
	}
}


void catFile3(const char *filename)
{
	if(s_debuglevel >= 3) {
		catFile(filename);
	}
}


void dumpbuffer(const char *buf, int len)
{
	for(int x = 0; x < ((len/16)+((len%16) ? 1 : 0)); x++) {
		printf("%02x: ", x);
		int y;
		for(y = 0; y < 16; y++) {
			if((x*16 + y) >= len) { break; }
			int v = (unsigned char) buf[x*16 + y];
			printf("%02x ", v);
		}
		for(; y < 16; y++) {
			printf("   ");
		}
		for(y = 0; y < 16; y++) {
			if((x*16 + y) >= len) { break; }
			int v = buf[x*16 + y];
			printf("%c", (((v >= 32) && (v <= 127)) ? v : '.'));
		}
		printf("\n");
	}
}
