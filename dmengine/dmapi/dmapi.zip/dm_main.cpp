#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <errno.h>

#ifdef WIN32
#include <windows.h>
#else
#include <dlfcn.h>
#include <pthread.h>
#endif /*WIN32*/

//#ifdef WIN32
#undef HAVE_TRILOGYAPI
//#endif

#ifdef HAVE_TRILOGYAPI
#include <trilogyapi.h>
#endif /*HAVE_TRILOGYAPI*/

#include "dm.h"
#include "context.h"
#include "scopestack.h"
#include "exceptions.h"
#include "model.h"
//#include "db.h"
#include "triodbc.h"
#include "options.h"
#include "license.h"
#include "crypto.h"
//#include "expr.h"	// For CharPtr only
#include "charptr.h"
#include "audit.h"


#define DM_VERSION "2.0beta"
#define SCHEMA_VERSION 20000L


OPTIONS options[]={
	{ "-fields", 'Y', "trifields" },
	{ "-validate", 'Y', "trivalidate" },	// TODO: use this
//{"-b",		'Y',	"TRIDM_BROKER"		},
//{"-cf",		'Y',	"triconfigfile"		},
//{"-cfv",	'Y',	"tricfileinscm"		},
	{"-usr",	'Y',	"TRIDM_USER" 		},
	{"-pw",		'Y',	"tripassword"		},
	{"-h",		'N',	"trihelp"		},
//{"-en",		'Y',	"TRIDM_PROJECT"		},
//{"-st",		'Y',	"TRIDM_STATE"		},
//{"-cen",	'Y',	"tricfileproject"	},
//{"-cst",	'Y',	"tricfilestate"		},
//{"-dbo",	'Y',	"tridbfile"			},
//{"-nls",	'N',	"trinolocalscript"	},
//{"-ncf",	'N',	"trincocfileinscm"	},
	{"-home",	'Y',	"tridmhome"		},
	{"-sessionid",	'Y',	"trisessionid"	},	// RHT 24/07/2013 - sessionid from web interface
	{"-app",	'Y',	"triappname"	},		// RHT 16/10/2013 - application name from web interface
	{"-appid",	'Y',	"triappid"		},		// RHT 16/10/2013 - application id from web interface
	{"-app2id",	'Y',	"triapp2id"		},		// RHT 16/12/2013 - second application id from web interface
	{"-env",	'Y',	"trienvname"	},		// RHT 16/10/2013 - environment name from web interface
	{"-envid",	'Y',	"trienvid"		},		// RHT 16/10/2013 - environment id from web interface
	{"-log",	'Y',	"trilogfile"	},	// TODO: use this
	{"-showlog",  'Y',	"trideplog"			},	// RHT 22/09/2010 - dumps the given deployment log
	{"-color",    'N',  "triusecolor"       },  // RHT 25/05/2013 - display console output in colour
	{"-testmode", 'N',	"tritestmode"		},	// RHT 01/08/2012 - performs tests on the model
	{"-install", 'N',	"triinstall"		},	// RHT 11/09/2012 - installs a plugin
	{"-parse",	 'Y',	"triparse"			},	// RHT 01/10/2012 - parses the given file
	{"-encrypt", 'N',	"triencrypt"		},	// RHT 02/12/2013 - encrypts data from stdin
	{"-providertest",	 'Y',	"triprovidertest" },	// RHT 16/07/2013 - tests the given provider
	{"-notify",	 'Y',	"trinotify" },	// RHT 29/11/2013 - sends a notification
	{"-from",	 'Y',	"trifrom" },	// RHT 29/11/2013 - address notification is from
	{"-subject",	 'Y',	"trisubject" },	// RHT 29/11/2013 - subject line for notification
	{"-template",	 'Y',	"tritemplate" },	// RHT 29/11/2013 - notification template - if not given use stdin
	{"-runtask",	 'Y',	"triruntask" },	// RHT 05/12/2013 - runs a task and any linked actions
	{"-nosemantic", 'N', "trinosemantic"	},	// RHT 09/10/2012 - disables semantic checks
//{"-audit",  'Y',	"triaudlvl"			},	// RHT 23/09/2010 - hidden switch to turn auditing off
                                            //                (1 = ignore errors; 2 = off completely)
//#ifdef WINDOWS_PROTOCOL_SUPPORT
//{"-nodrivemap",	   'N', "trinodrivemap" },		// RHT 21/01/2012 - pass flag to RemoteRunner
//{"-noimpersonate", 'N', "trinoimpersonate" },	// RHT 21/01/2012 - pass flag to RemoteCopy/Runner
//#endif /*WINDOWS_PROTOCOL_SUPPORT*/
	{"-noexec",	'N',	"trinoexec"			},	// TODO: dry-run mode - stops commands being run
	{"-nounlink", 'N',  "trinounlink"		},	// turn off temporary file deletion
	{"-nonotify", 'N',	"trinonotify"		},	// turn off notifications (for testing)
	{"-forceunlink", 'N',  "triforceunlink"	},	// force temporary file deletion if not empty
	{"-debug", 'Y',  "tridebuglevel"	    },	// debug level
	{"-lexdebug", 'Y',  "trilexdebug"	    }	// write lexer output to specified file
};


extern void setdebuglevel(int level);


///////////////////////////////////////////////////////////////////////////////


char *getFieldContent(DM &dm, int fieldNumber)
{
	const char *fields = getenv("trifields");
	if(!fields) {
		fields = dm.getDefaultFields();
	}

	int n = 0;
	char *temp = strdup(fields);
	for(char *f = strtok(temp, ",:;|"); f; f = strtok(NULL, ",:;|")) {
		n++;
		if(n == fieldNumber) {
			char *ret = strdup(f);
			SAFE_FREE(temp);
			return ret;
		}
	}

	SAFE_FREE(temp);
	return NULL;
}


int getFieldNumber(DM &dm, const char *fieldName)
{
	const char *fields = getenv("trifields");
	if(!fields) {
		fields = dm.getDefaultFields();
	}

	int n = 0;
	char *temp = strdup(fields);
	for(char *f = strtok(temp, ",:;|"); f; f = strtok(NULL, ",:;|")) {
		n++;
		if(STRCASECMP(f, fieldName) == 0) {
			SAFE_FREE(temp);
			return n;
		}
	}

	SAFE_FREE(temp);
	return 0;
}


const char *getEnvironmentNameFromDialog(DM &dm)
{
	int field = getFieldNumber(dm, "environments");
	if(field) {
		return dm.getTriField(field);
	}
	return NULL;
}


const char *getUserNameFromDialog(DM &dm)
{
	int field = getFieldNumber(dm, "username");
	if(field) {
		return dm.getTriField(field);
	}
	return NULL;
}


const char *getPasswordFromDialog(DM &dm)
{
	int field = getFieldNumber(dm, "password");
	if(field) {
		return dm.getTriField(field);
	}
	return NULL;
}


const char *getApplicationNameFromDialog(DM &dm)
{
	int field = getFieldNumber(dm, "applications");
	if(field) {
		return dm.getTriField(field);
	}
	return NULL;
}


/**
 * Output the list of environments.  If an application is selected, then only
 * output the environments which are applicable to that application.
 */
int outputEnvironmentList(DM &dm, Model& model)
{
	const char *szChangedField = getenv("TRICHANGEDFIELD");
	const char *szApplicationName = NULL;
	if(szChangedField && szChangedField[0]) {
		// We've been triggered due to a field change
		int field = atoi(szChangedField);
		if(field == getFieldNumber(dm, "applications")) {
			// Application has changed
			szApplicationName = getApplicationNameFromDialog(dm);
		}
	}

	List<Environment> *envs = model.getEnvironments();
	if(szApplicationName) {
		dm.writeToLogFile("Listing valid logical servers for application [%s]", szApplicationName);
	}
	if(envs) {
		ListIterator<Environment> eiter(*envs);
		for(Environment *e = eiter.first(); e; e = eiter.next()) {
			if(e->hasAccess(dm.getCurrentUser())) {
				if(szApplicationName) {
					// There's an application and we're listing valid servers for this application
					List<Application> *apps = e->getAllowedApplications();
					if(apps) {
						ListIterator<Application> aiter(*apps);
						for(Application *a = aiter.first(); a; a = aiter.next()) {
							if(strcmp(a->name(), szApplicationName) == 0) {
								// The application is allowed on this server
								printf("%s\n",e->name());
								break;
							}
						}
					}
				} else {
					// no application - just print the environment name
					printf("%s\n", e->name());
				}
			}
		}
	}
	
	return 0;
}


/**
 * Output the list of applications.  If an environment is selected, then only
 * output the applications which are applicable to that environment.
 */
int outputApplicationList(DM& dm, Model& model)
{
	Environment *env = NULL;

	char *szChangedField = getenv("TRICHANGEDFIELD");
	if(szChangedField && szChangedField[0]) {
		// We've been triggered due to a field change
		int field = atoi(szChangedField);
		if(field == getFieldNumber(dm, "environments")) {
			// Server has changed
			const char *szEnvName = getEnvironmentNameFromDialog(dm);
			if(szEnvName) {
				dm.writeToLogFile("Environment Name = [%s]", szEnvName);
				env = model.getEnvironment(szEnvName);
				if(!env) {
					dm.exitWithError("Environment \"%s\" is invalid or you have no access", szEnvName);
				}
			} else {
				dm.writeToLogFile("Environment name not set");
			}
		}
	}

	List<Application> *apps = env ? env->getAllowedApplications() : model.getApplications();
	int appCount = 0;
	if(apps) {
		ListIterator<Application> iter(*apps);
		for(Application *a = iter.first(); a; a = iter.next()) {
			if(a->hasAccess(dm.getCurrentUser())) {
				appCount++;
				printf("%s\n", a->name());
			}
		}
	}

	if(appCount == 0) {
		dm.writeToLogFile("No Applications listed - exiting with failure (disable field)");
		//exit(1);
		return 1;
	}
	
	return 0;
}


/**
 * if we remembered the username for this box output it here.  If the server
 * has an encrypted username/password associated, exit with 1.
 */
int handleUserName(DM &dm, Model &model)
{
	// Get the environment name (if any)
	const char *szEnvName = getEnvironmentNameFromDialog(dm);
	if(szEnvName) {
		Environment *env = model.getEnvironment(szEnvName);
		if(env) {
			// Valid server
			Credentials *creds = env->getCredentials();
			if(creds) {
				// There is password data associated with this environment
				printf("********\n");

				// Exit with failure to disable the entry box
				//exit(1);
				return 1;
			} else {
				// No password data for the environment - what about the servers?
				bool allPhysicalServersHavePassword = true;
				List<Server> *servers = env->getServers();
				if(servers) {
					ListIterator<Server> iter(*servers);
					for(Server *s = iter.first(); s; s = iter.next()) {
						Credentials *creds = s->getCredentials();
						if(!creds) {
							// No password data for this server
							allPhysicalServersHavePassword = false;
						}
					}
				}
				if(allPhysicalServersHavePassword) {
					// They may differ but all servers have password data
					// Just exit with failure to disable the field.
					//exit(1);
					return 1;
				}
			}
		}
	}
	
	return 0;
}


int handlePassword(DM& dm, Model& model)
{
	// Get the environment name (if any)
	const char *szEnvName = getEnvironmentNameFromDialog(dm);
	if(szEnvName) {
		Environment *env = model.getEnvironment(szEnvName);
		if(env) {
			// Valid server
			Credentials *creds = env->getCredentials();
			if(creds) {
				// There is password data
				if(creds->kind() == CREDENTIALS_IN_DATABASE) {
					// Do we have password or just username?
					if(creds->hasPassword()) {
						printf("********\n");
						// Disable the entry box
						//exit(1);
						return 1;
					}
				} else {
					// Must be encrypted username/password
					// Disable the trilogy entry box
					printf("********\n");
					//exit(1);
					return 1;
				}
			} else {
				// No password data for the environment - what about the servers?
				bool allPhysicalServersHavePassword = true;
				List<Server> *servers = env->getServers();
				if(servers) {
					ListIterator<Server> iter(*servers);
					for(Server *s = iter.first(); s; s = iter.next()) {
						Credentials *creds = s->getCredentials();
						if(creds) {
							if(creds->kind() == CREDENTIALS_IN_DATABASE) {
								// Do we have password or just username?
								if(!creds->hasPassword()) {
									allPhysicalServersHavePassword = false;
								}
							}
						} else {
							// No password data for this server
							allPhysicalServersHavePassword = false;
						}
					}
				}
				if(allPhysicalServersHavePassword) {
					// They may differ but all servers have password data
					// Just exit with failure to disable the field.
					//exit(1);
					return 1;
				}
			}
		}
	}
	
	return 0;
}


int outputDropDownContent(DM &dm, Model& model, const char *type)
{
	int ret = 0;
	
	if(STRCASECMP(type, "environments") == 0) {
		ret = outputEnvironmentList(dm, model);
	} else if(STRCASECMP(type, "applications") == 0) {
		ret = outputApplicationList(dm, model);
	} else if(STRCASECMP(type, "username") == 0) {
		ret = handleUserName(dm, model);
	} else if(STRCASECMP(type, "password") == 0) {
		ret = handlePassword(dm, model);
	} else {
		Field *field = model.getField(type);
		if(field) {
			field->populate(dm);
			// TODO: how to return exit code from this?
		} else {
			dm.writeToStdErr("Unknown content type \"%s\"", type);
		}
	}
	
	return ret;
}


int handleFieldPopulation(DM &dm, Model& model)
{
	const char *szFieldNumber = getenv("TRICURRENTFIELD");
	if(!szFieldNumber) {
		dm.writeToStdErr("TRICURRENTFIELD not set!");
		return 2;
	}

	int fieldNumber = atoi(szFieldNumber);

	ConstCharPtr fieldToOutput = getFieldContent(dm, fieldNumber);
	if(fieldToOutput) {
		return outputDropDownContent(dm, model, fieldToOutput);
	}

	dm.writeToStdErr("Unknown field number \"%s\" in TRICURRENTFIELD", szFieldNumber);
	return 2;
}


void getOwnersForServers(List<Server> *servers)
{
	if(servers) {
		ListIterator<Server> iter(*servers);
		for(Server *s = iter.first(); s; s = iter.next()) {
			s->getOwner();
		}
	}
}


void getCredentialsForServers(List<Server> *servers)
{
	if(servers) {
		ListIterator<Server> iter(*servers);
		for(Server *s = iter.first(); s; s = iter.next()) {
			s->getCredentials();
		}
	}
}


int testThings(triODBC &odbc)
{
	AutoPtr<triSQL> sql = odbc.GetSQL();

	char envName[DB_NAME_LEN];
	char envEmail[DB_EMAIL_LEN];
	char serverName[DB_NAME_LEN];
	char hostname[DB_HOSTNAME_LEN];
	char serverEmail[DB_EMAIL_LEN];
	SQLLEN ni_serverEmail;

	sql->BindColumn(0, SQL_CHAR, envName, sizeof(envName));
	sql->BindColumn(1, SQL_CHAR, envEmail, sizeof(envEmail));
	sql->BindColumn(2, SQL_CHAR, serverName, sizeof(serverName));
	sql->BindColumn(3, SQL_CHAR, hostname, sizeof(hostname));
	sql->BindColumn(4, SQL_CHAR, serverEmail, sizeof(serverEmail), &ni_serverEmail);

	int res = sql->ExecuteSQL("select e.name, u1.email, s.name, s.hostname, u2.email "
			"from (dm_environment e left join dm_user u1 on e.ownerid = u1.id), "
			"(dm_server s left join dm_user u2 on s.ownerid = u2.id), dm_serversinenv sie "
			"where e.id = sie.envid and sie.serverid = s.id ");
	if((res != SQL_SUCCESS) && (res != SQL_SUCCESS_WITH_INFO)) {
		return 1;
	}

	int i = 0;
	for(res = sql->FetchRow(); (res == SQL_SUCCESS) || (res == SQL_SUCCESS_WITH_INFO); res = sql->FetchRow()) {
		printf("[%d] %s, %s, %s, %s, %s\n", i++, envName, envEmail, serverName, hostname, (ni_serverEmail ? serverEmail : "(no owner)"));
	}

	DM dm;
	Model model(odbc, dm.getHostname());
	User *user = model.getUser("robert");
	model.setCurrentUser(user);

	// List of environments - servers won't be loaded
	List<Environment> *envs = model.getEnvironments();
	if(envs) {
		//envs->print(0);
		ListIterator<Environment> iter(*envs);
		for(Environment *e = iter.first(); e; e = iter.next()) {
			e->print(0);
		}
	}

	printf("--\n");

	// List of applications
	List<Application> *apps = model.getApplications();
	if(apps) {
		//apps->print(0);
		ListIterator<Application> iter(*apps);
		for(Application *a = iter.first(); a; a = iter.next()) {
			a->print(0);
		}
	}

	printf("--\n");

	// One environment after loading servers and applications for it
	Environment *envA = model.getEnvironment("envA");
	if(envA) {
		envA->getOwner();
		envA->getCredentials();
		List<Server> *servers = envA->getServers();
		getOwnersForServers(servers);
		getCredentialsForServers(servers);
		List<Application> *apps = envA->getAllowedApplications();
		envA->print(0);
	}

	printf("--\n");

	// Another environment after loading servers and applications for it
	Environment *envB = model.getEnvironment("envB");
	if(envB) {
		envB->getOwner();
		envB->getCredentials();
		List<Server> *servers = envB->getServers();
		getOwnersForServers(servers);
		getCredentialsForServers(servers);
		List<Application> *apps = envB->getAllowedApplications();
		envB->print(0);
	}

	printf("--\n");

	// Yet another environment after loading servers and applications for it
	Environment *envC = model.getEnvironment("envC");
	if(envC) {
		envC->getOwner();
		envC->getCredentials();
		List<Server> *servers = envC->getServers();
		getOwnersForServers(servers);
		getCredentialsForServers(servers);
		List<Application> *apps = envC->getAllowedApplications();
		envC->print(0);
	}

	printf("--\n");

	// User for testing
	User *test = model.getUser("robert");
	Application *app1 = model.getApplication("app1");
	app1->getOwner();
	app1->hasAccess(test);
	Application *app2 = model.getApplication("app2");
	app2->getOwner();
	app2->hasAccess(test);
	Application *app3 = model.getApplication("app3");
	app3->getOwner();
	app3->hasAccess(test);
	if(app2) {
		Domain *adom1 = app2->getDomain();
		if(adom1) {
			adom1->getOwner();
			adom1->getApplications();
			adom1->print(0);
		}
	} else {
		printf("Failed to get Application\n");
	}

	printf("--\n");

	Repository *repoTest = model.getRepository("test");
	if(repoTest) {
		repoTest->getOwner();
		Domain *repoDom = repoTest->getDomain();
		if(repoDom) {
			repoDom->getOwner();
			repoDom->getRepositories();
			repoDom->print(0);
		} else {
			repoTest->print(0);
		}
	} else {
		printf("Failed to get Repository\n");
	}

	printf("--\n");

	Notify *nfyEmail = model.getNotifier("email");
	if(nfyEmail) {
		nfyEmail->getOwner();
		Domain *nfyDom = nfyEmail->getDomain();
		if(nfyDom) {
			nfyDom->getOwner();
			nfyDom->getNotifys();
			nfyDom->print(0);
		} else {
			nfyEmail->print(0);
		}
	} else {
		printf("Failed to get Notify\n");
	}

	printf("--\n");

	Datasource *testDat = model.getDatasource("dm");
	if(testDat) {
		testDat->getOwner();
		Domain *datDom = testDat->getDomain();
		if(datDom) {
			datDom->getOwner();
			datDom->getDatasources();
			datDom->print(0);
		} else {
			testDat->print(0);
		}
	} else {
		printf("Failed to get Datasource\n");
	}

	printf("--\n");

	// Now get the parent domains
	envA->hasAccess(test);
	Domain *testEnvs = envA->getDomain();
	if(testEnvs) {
		testEnvs->getOwner();
		testEnvs->getSubdomains();
		testEnvs->getEnvironments();
		testEnvs->getApplications();
		testEnvs->getRepositories();
		testEnvs->getNotifys();
		testEnvs->getDatasources();
		testEnvs->hasAccess(test);
		Domain *trinemEnvs = testEnvs->getDomain();
		if(trinemEnvs) {
			trinemEnvs->getOwner();
			trinemEnvs->getSubdomains();
			trinemEnvs->getEnvironments();
			trinemEnvs->getApplications();
			trinemEnvs->getRepositories();
			trinemEnvs->getNotifys();
			trinemEnvs->getDatasources();
			trinemEnvs->hasAccess(test);
			trinemEnvs->print(0);
		} else {
			testEnvs->print(0);
		}
	} else {
		printf("Failed to get Domain\n");
	}

	printf("--\n");

	User *robert = model.getUser("robert");
	if(robert) {
		printf("robert: %s (%s)\n", NULL_CHECK(robert->getFQDomain()), NULL_CHECK(robert->getAccessibleDomains()));
	}
	User *demo = model.getUser("demo");
	if(demo) {
		printf("demo:   %s (%s)\n", NULL_CHECK(demo->getFQDomain()), NULL_CHECK(demo->getAccessibleDomains()));
	}

	printf("--\n");

	//const char *encrypted = "U2FsdGVkX19u1EggRdePnNzrocqVkLIdqBMFfmxZj6c=";
	//char *testDecrypt = decryptValue(encrypted, strlen(encrypted));
	//printf("decrypted: '%s'\n", (testDecrypt ? testDecrypt : "(null)"));
	//SAFE_FREE(testDecrypt);

	const char *password = "password";
	char *testDigest = digestValue(password, strlen(password), true);
	printf("digested: '%s'\n", (testDigest ? testDigest : "(null)"));
	SAFE_FREE(testDigest);

	return 0;
}


int validateDialog(DM &dm, Model& model)
{
	dm.writeToLogFile("Validating Dialog Content...");

	// Ensure that contents of the Trilogy Dialog are valid before we proceed

	const char *environment  = getEnvironmentNameFromDialog(dm);
	const char *application  = getApplicationNameFromDialog(dm);
	const char *username     = getUserNameFromDialog(dm);
	const char *password     = getPasswordFromDialog(dm);

	// (1) Do we have a target server?
	if(!environment || !environment[0]) {
		dm.exitWithError("You must specify a Target Environment");
	}

	// (2) Do we have an application?
	if(!application || !application[0]) {
		dm.exitWithError("You must specify an Application");
	}

	// (3) Does the server have a username/password specified?
	Environment *env = model.getEnvironment(environment);
	if(!env) {
		dm.exitWithError("Invalid Environment '%s' specified", NULL_CHECK(environment));
	}

	bool needUserName = true;
	bool needPassword = true;

	Credentials *creds = env->getCredentials();
	if(creds) {
		// yes it does - what type of password data?
		switch(creds->kind()) {
		case CREDENTIALS_ENCRYPTED:
		case CREDENTIALS_IN_DATABASE:
			// UserName/Password
			needUserName = false;
			if(creds->hasPassword()) {
				needPassword = false;
			}
			break;
		case CREDENTIALS_RTI3_DFO_IN_FILESYSTEM:
		case CREDENTIALS_HARVEST_DFO_IN_FILESYSTEM:
			// DFO encrypted username/password
			needUserName = needPassword = false;
			break;
		}
	} else {
		needUserName = needPassword = false;

		List<Server> *servers = env->getServers();
		if(servers) {
			ListIterator<Server> iter(*servers);
			for(Server *s = iter.first(); s; s = iter.next()) {
				Credentials *creds = s->getCredentials();
				if(creds) {
					if(!creds->hasPassword()) {
						needPassword = true;
					}
				} else {
					dm.writeToLogFile("No password data for server %s, need=true", s->name());
					needUserName = needPassword = true;
					break;
				}
			}
		}
	}

	if((needUserName && !(username && username[0]))
		|| (needPassword && !(password && password[0]))) {
		dm.exitWithError("You must specify a username/password for this deployment");
	}

	// TODO: Does the application need a package specifying?

	// TODO: custom verify action

	return 0;
}


void ensurePassphraseFile(DM &dm, const char *homeDir)
{
	char ppfilename[1024];
	sprintf(ppfilename, "%s%sdm.asc", homeDir, DIR_SEP_STR);
	debug3("ppfilename = '%s'", ppfilename);

	try {
		// Does the passphrase file exist?
		struct stat sb;
		if(stat(ppfilename, &sb) == -1) {
			if(errno == ENOENT) {
				//// Doesn't exist - so create it
				//dm.writeToLogFile("Creating passphrase file");
				//createPassphraseFile(ppfilename);
				// Doesn't exist - user should run dmsetup to create
				dm.exitWithError("FATAL ERROR: The file dm.asc does not exist.  Please run the dmsetup\n"
					             "             tool to create it.");
			} else {
				dm.exitWithError("FATAL ERROR: Unable to stat passphrase file");
			}
		}

		// Read the passphrase file to allow us to do encryption
		if(!readPassphraseFile(ppfilename)) {
			dm.writeToStdErr("FATAL ERROR: Unable to initialise encryption");
		}
	} catch(RuntimeError &e) {
		e.print(dm);
		dm.exitWithError("FATAL ERROR: Passphrase file mechanism failed");
	}
}


int runScript(DM &dm, const char *baseDir, char **argv, char **envp)
{
	dm.initialize(baseDir, argv, envp);
	return dm.doDeployment();
}


int runListboxScript(DM &dm, const char *baseDir, char **argv, char **envp)
{
	dm.initialize(baseDir, argv, envp);

	Action *action = dm.getAction("populate_listbox");
	if(!action) {
		dm.exitWithError("No action named '%s'", "populate_listbox");
	}

	int res = dm.runAction(*action);
	dm.cleanup();
	return res;
}


int runTask(DM &dm, int taskid, const char *baseDir, char **argv, char **envp)
{
	dm.initialize(baseDir, argv, envp);

	Task *task = dm.getTask(taskid);
	if(!task) {
		dm.exitWithError("Invalid task id %d", taskid);
	}

	int res = dm.runTask(*task);
	dm.cleanup();
	return res;
}


typedef enum tagTriReason {
	REASON_NONE = 0,
	REASON_UNSET,
	REASON_POPULATE,
	REASON_LISTBOX,
	REASON_VALIDATION,
	REASON_SCRIPT,
	REASON_TIMED
#ifdef HAVE_TRILOGYAPI
	, REASON_PRELOAD
#endif /*HAVE_TRILOGYAPI*/
} TriReason;


TriReason triReasonFromString(const char *triReason)
{
	if(strcmp(triReason, "POPULATE") == 0) {
		return REASON_POPULATE;
	} else if(strcmp(triReason, "LISTBOX") == 0) {
		return REASON_LISTBOX;
	} else if(strcmp(triReason, "VALIDATION") == 0) {
		return REASON_VALIDATION;
	} else if(strcmp(triReason, "SCRIPT") == 0) {
		return REASON_SCRIPT;
	} else if(strcmp(triReason, "TIMED") == 0) {
		return REASON_TIMED;
	}
#ifdef HAVE_TRILOGYAPI
	 else if(strcmp(triReason, "PRELOAD") == 0) {
		return REASON_PRELOAD;
	}
#endif /*HAVE_TRILOGYAPI*/
	return REASON_NONE;
}


/**
 * First check if -usr was specified, if not then use Trilogy's TRICLIENTUSERNAME
 */
void setCurrentUser(DM &dm)
{
	const char *username = getenv("TRIDM_USER");
	if(!username) {
		username = getenv("TRICLIENTUSERNAME");
	}
	if(!username) {
		dm.exitWithError("Username must be specified");
	}
	if(!dm.setCurrentUser(username)) {
		// TODO: This should probably report "invalid username or password" so
		// as not to give away usernames
		dm.exitWithError("Invalid user '%s' specified", username);
	}

	const char *password = getenv("tripassword");
	if(password) {
		char *passhash = digestValue(password, strlen(password), true);
		if(!dm.getCurrentUser()->validateHashedPassword(passhash)) {
			dm.exitWithError("Logon denied: invalid username or password");
		}

		dm.writeToLogFile("User '%s' authenticated", username);
		dm.updateUserLastLogin(*(dm.getCurrentUser()));
	}
}


void setTargetAppAndEnvFromParams(DM &dm, bool required)
{
	const char *envname = getenv("trienvname");
	const char *envidstr = getenv("trienvid");
	const char *appname = getenv("triappname");
	const char *appidstr = getenv("triappid");

	if(required) {
		if(!((envname != NULL) ^ (envidstr != NULL))) {
			dm.exitWithError("-env and -envid are mutually exclusive but must be specified in this mode");
		}
		if(!((appname != NULL) ^ (appidstr != NULL))) {
			dm.exitWithError("-app and -appid are mutually exclusive but must be specified in this mode");
		}
	} else {
		if(envname && envidstr) {
			dm.exitWithError("-env and -envid are mutually exclusive");
		}
		if(appname && appidstr) {
			dm.exitWithError("-app and -appid are mutually exclusive");
		}
	}

	if(envname) {
		if(!dm.setTargetEnvironment(envname)) {
			dm.exitWithError("Invalid environment '%s' specified", envname);
		}
	} else if(envidstr) {
		int envid = atoi(envidstr);
		if(!envid || !dm.setTargetEnvironment(envid)) {
			dm.exitWithError("Invalid environment id '%s' specified", envidstr);
		}
	} else if(required) {
		dm.exitWithError("No environment specified");
	}

	if(appname) {
		if(!dm.setTargetApplication(appname)) {
			dm.exitWithError("Invalid application '%s' specified", appname);
		}
	} else if(appidstr) {
		int appid = atoi(appidstr);
		if(!appid || !dm.setTargetApplication(appid)) {
			dm.exitWithError("Invalid application id '%s' specified", appidstr);
		}
	} else if(required) {
		dm.exitWithError("No application specified");
	}

	const char *app2idstr = getenv("triapp2id");
	if(app2idstr) {
		int app2id = (app2idstr[0] == '+') ? -atoi(&app2idstr[1]) : atoi(app2idstr);
		debug0("app2id is %d", app2id);
		if(!app2id || !dm.setSecondApplication(app2id)) {
			dm.exitWithError("Invalid application id '%s' specified", app2idstr);
		}
	}
}


///////////////////////////////////////////////////////////////////////////////


#ifdef WIN32
char *getHomeDirectory(const char *argv0)
{
	char moduleFileName[1024];
	GetModuleFileNameA(NULL, moduleFileName, sizeof(moduleFileName));

	// Split off the name of the executable
	char *lastsep = strrchr(moduleFileName, '\\');
	if(!lastsep) {
		// This should never happen!
		debug0("Module filename is '%s'", moduleFileName);
		return strdup(".");
	}
	*lastsep = '\0';
	// If we still have a slash, then do dirname
	if((lastsep = strrchr(moduleFileName, '\\')) != NULL) {
		*lastsep = '\0';
	} else {
		// otherwise must be a relative path, so append "\.."
		strcat(moduleFileName, "\\..");
	}
	return strdup(moduleFileName);
}
#else
char *getHomeDirectory(const char *argv0)
{
	char *basedir = strdup(argv0);
	// Split off the name of the executable
	char *lastsep = strrchr(basedir, '/');
	if(!lastsep) {
		// This should never happen!
		debug0("Basedir is '%s'", basedir);
		return strdup(".");
	}
	*lastsep = '\0';
	// If we still have a slash, then do dirname
	if((lastsep = strrchr(basedir, '/')) != NULL) {
		*lastsep = '\0';
	} else {
		// otherwise must be a relative path, so append "\.."
		strcat(basedir, "/..");
	}
	return basedir;
}
#endif


#ifdef HAVE_TRILOGYAPI
extern "C" int PreloadPopulateField(int argc, char **argv)
{
	printf("preload: ");
	//return 0;

	int n = ScanOptions(options, sizeof(options)/sizeof(options[0]), argc, argv);

	// Start of name/value and positional args
	char **nvargv = &argv[n];

	triODBC odbc;
	int res = odbc.ConnectToDataSource("dm", "postgres", "postgres");
	if((res != SQL_SUCCESS) && (res != SQL_SUCCESS_WITH_INFO)) {
		return 1;
	}

	AutoPtr<triSQL> sql = odbc.GetSQL();
	res = sql->ExecuteSQL("set schema 'dm'");
	if((res != SQL_SUCCESS) && (res != SQL_SUCCESS_WITH_INFO)) {
		return 1;
	}

	////DM dm;
	////char *baseDir = getBaseDirectory(argv[0]);
	////dm.setDmHome(baseDir);

	dm.writeToLogFile("PreloadPopulateField - TRICURRENTFIELD = %d; TRICHANGEDFIELD = %d",
		CurrentField(), ChangedField());

	try {
	Model model(odbc);
	dm.setModel(&model);
	setCurrentUser(dm);
	dm.initialize(baseDir, nvargv, NULL);
	int res = handleFieldPopulation(dm, model);
	dm.cleanup();
	dm.deleteTemporaryFilesAndFolders();

	dm.writeToLogFile("PreloadPopulateField - res = %d", res);
	return res;

	} catch(DMException &e) {
		fprintf(stderr, "Unhandled exception: %s\n", e.getMessage());
		fprintf(stdout, "Unhandled exception: %s\n", e.getMessage());
	} catch(...) {
		fprintf(stderr, "Unknown exception\n");
		fprintf(stdout, "Unknown exception\n");
	}
	return 2;
}
#endif /*HAVE_TRILOGYAPI*/


triODBC *connectToDatabase(DM &dm, const char *homeDir)
{
	ensurePassphraseFile(dm, homeDir);

	char odbcfilename[1024];
	sprintf(odbcfilename, "%s%sdm.odbc", homeDir, DIR_SEP_STR);
	debug3("odbcfilename = '%s'", odbcfilename);

	// Does the odbc file exist?
	struct stat sb;
	if(stat(odbcfilename, &sb) == -1) {
		if(errno == ENOENT) {
			// Doesn't exist - so create it
			dm.exitWithError("FATAL ERROR: The file dm.odbc does not exist.  Please configure\n"
				"             the database connection using the dmsetup tool.");
		} else {
			dm.exitWithError("FATAL ERROR: Unable to stat odbc file");
		}
	}

	int len = 0;
	CharPtr details = decryptFile(odbcfilename, &len);
	const char *dsn = details;
	const char *user = NULL;
	const char *pass = NULL;

	int nulls = 0;
	for(int n = 0; n < len; n++) {
		if(!details[n]) {
			nulls++;
			if(nulls == 1) {
				user = &details[n+1];
			} else if(nulls == 2) {
				pass = &details[n+1];
			}
		}
	}
	if(nulls != 2) {
		dm.exitWithError("FATAL ERROR: dm.odbc is not a valid odbc file");
	}
	//printf("dsn = '%s'; user = '%s'; pass = '%s'\n", (const char*) details, user, pass);

	triODBC *odbc = new triODBC();
	int res = odbc->ConnectToDataSource((char*) dsn, (char*) user, (char*) pass);
	if((res != SQL_SUCCESS) && (res != SQL_SUCCESS_WITH_INFO)) {
		return NULL;
	}

	AutoPtr<triSQL> sql = odbc->GetSQL();
	long schemaver;
	sql->BindColumn(1, SQL_C_SLONG, &schemaver, sizeof(schemaver));
	res = sql->ExecuteSQL("select schemaver from dm_tableinfo");
	if((res != SQL_SUCCESS) && (res != SQL_SUCCESS_WITH_INFO)) {
		return NULL;
	}
	res = sql->FetchRow();
	if((res != SQL_SUCCESS) && (res != SQL_SUCCESS_WITH_INFO)) {
		return NULL;
	}
	if(schemaver != SCHEMA_VERSION) {
		dm.exitWithError("FATAL ERROR: Schema version (%ld) does not match"
			" expected schema version (%ld)", schemaver, SCHEMA_VERSION);
	}
	return odbc;
}


int showDeploymentLog(triODBC &odbc, int logtoshow)
{
	AutoPtr<triSQL> sql = odbc.GetSQL();

	int stream;
	char line[2049];
	SQLLEN ni_line = 0;
	sql->BindColumn(1, SQL_INTEGER, &stream, sizeof(stream));
	sql->BindColumn(2, SQL_CHAR, line, sizeof(line), &ni_line);

	SQLRETURN res = sql->ExecuteSQL(
		"SELECT stream, line FROM dm_deploymentlog "
		"WHERE deploymentid=%d ORDER BY runtime", logtoshow);
	if((res != SQL_SUCCESS) && (res != SQL_SUCCESS_WITH_INFO)) {
		fprintf(stderr, "Deployment log %d not found", logtoshow);
		return 1;
	}

	bool useColor = getenv("triusecolor") ? true : false;

	for(res = sql->FetchRow(); (res == SQL_SUCCESS) || (res == SQL_SUCCESS_WITH_INFO); res = sql->FetchRow()) {
		char *output = NULL_IND(line, NULL);
		if(output) {
			if(stream == 2) {
				fprintf(stderr, (useColor ? "\x1b[31m%s\x1b[0m\n" : "%s\n"), output);
			} else {
				fprintf(stdout, "%s\n", output);
			}
		}
	}
	sql->CloseSQL();
	return 0;
}


void printHelpAndExit()
{
	printf("OpenMake Deployment Manager " DM_VERSION "\n"
		"(c) 2013 OpenMake Software.  All rights reserved.\n"
		"\nUsage: dm <options>\n\n"
		"-fields <fieldlist> - Field mapping for dialog\n"
		//"-validate <validate>\n"
		"-usr <username>     - DM user\n"
		"-pw <password>      - DM password\n"
		"-h                  - This help text\n"
		//"-log <logfile>      - Set log filename\n"
#ifdef DEV_VERSION
		"-home <dir>         - Forcibly set DMHOME\n"
		"-testmode           - #Performs tests on the model\n"
#endif /*DEV_VERSION*/
		"-install            - Installs plugins\n"
		"-parse <file>       - Parses the given file\n"
#ifdef DEV_VERSION
		"-nosemantic         - #Disables semantic checks\n"
#endif /*DEV_VERSION*/
		//"-noexec             - Dry-run mode - stops commands being run\n"
		"-nounlink           - Turn off temporary file deletion\n"
		"-nonotify           - Turn off notifications (for testing)\n"
		"-forceunlink        - Force temporary file deletion if not empty\n"
		"-showlog <deployid> - Show the given deployment log\n"
#ifdef DEV_VERSION
		"-debug <level>      - #Debug level (0-3)\n"
		"-lexdebug <file>    - #Write lexer output to specified file\n"
		"\n"
		"# - development option\n"
#endif /*DEV_VERSION*/
		);
	exit(0);
}


// TODO: These will be removed when turned into DLLs
extern "C" int filesystem_PluginInstall(DM &dm);
extern "C" int svn_PluginInstall(DM &dm);
extern "C" int rti_PluginInstall(DM &dm);
extern "C" int smtpemail_PluginInstall(DM &dm);
extern "C" int txtlocal_PluginInstall(DM &dm);
#ifdef HAVE_ODBC
extern "C" int odbcdatasource_PluginInstall(DM &dm);
#endif /*HAVE_ODBC*/
extern "C" int xmlmodify_PluginInstall(DM &dm);
extern "C" int textmodify_PluginInstall(DM &dm);


extern "C"
#ifdef WIN32
__declspec(dllexport)
#endif /*WIN32*/
int DM_main(int argc, char **argv, char **envp)
{
//	printf(
//#ifdef WIN32
//#ifdef _WIN64
//		"WIN64"
//#else
//		"WIN32"
//#endif /*_WIN64*/
//#else
//		"UNIX"
//#endif /*WIN32*/
//		"; sizeof(short) = %d; sizeof(int) = %d; sizeof(long) = %d; sizeof(DMINT32) = %d\n",
//		sizeof(short), sizeof(int), sizeof(long), sizeof(DMINT32));
//	exit(0);

	try {
	int n = ScanOptions(options, sizeof(options)/sizeof(options[0]), argc, argv);

	if(getenv("tridebuglevel")) {
		setdebuglevel(atoi(getenv("tridebuglevel")));
	}

	if(getenv("trihelp")) {
		printHelpAndExit();
	}

	// Start of name/value and positional args
	char **nvargv = &argv[n];

	const char *triReason = getenv("TRIREASON");

	TriReason reason = triReason ? triReasonFromString(triReason) : REASON_UNSET;
	if(reason == REASON_NONE) {
		fprintf(stderr, "Not a good TRIREASON!\n");
		return 1;
	}

	// Now safe to create a DM object and set our homedir
	DM dm;
	ConstCharPtr homeDir = getHomeDirectory(argv[0]);
#ifdef DEV_VERSION
	if(getenv("tridmhome")) {
		homeDir = strdup(getenv("tridmhome"));
		struct stat sb;
		if(stat(homeDir, &sb) == -1) {
			if(errno == ENOENT) {
				// Doesn't exist - so create it
				dm.exitWithError("FATAL ERROR: Directory '%s' does not exist", (const char*) homeDir);
			} else {
				dm.exitWithError("FATAL ERROR: Unable to stat directory '%s'", (const char*) homeDir);
			}
		}
	}
#endif /*DEV_VERSION*/
	dm.setDmHome(homeDir);

	// Reset path to include bin dir for ssl libraries
#ifdef WIN32
	const char *path = getenv("PATH");
	if(path) {
		char *temp = (char*) malloc(strlen(path) + 5 + strlen(homeDir) + 10);
		sprintf(temp, "PATH=%s%sbin%s%s", homeDir, DIR_SEP_STR, PATH_SEP_STR, path);
		putenv(temp);
	} else {
		char *temp = (char*) malloc(strlen(homeDir) + 10);
		sprintf(temp, "PATH=%s%sbin", homeDir, DIR_SEP_STR);
		putenv(temp);
	}
#endif /*WIN32*/

	// Everything from here on needs a database connection
	AutoPtr<triODBC> odbc;
	try {
		if(!(odbc = connectToDatabase(dm, homeDir))) {
			dm.exitWithError("FATAL ERROR: Failed to connect to database");
		}
	} catch(DMException &e) {
		dm.exitWithError("%s\nFATAL ERROR: Failed to connect to database", e.getMessage());
	}

	// If -install specified, just install plugins and exit
	if(getenv("triinstall")) {
		Model model(*odbc, dm.getHostname());
		dm.setModel(&model);
		// repositories
		filesystem_PluginInstall(dm);
		svn_PluginInstall(dm);
		dm.installPlugin("harvest");
		// transfers
		rti_PluginInstall(dm);
		// notifies
		smtpemail_PluginInstall(dm);
		txtlocal_PluginInstall(dm);
		// datasources
#ifdef HAVE_ODBC
		odbcdatasource_PluginInstall(dm);
#endif /*HAVE_ODBC*/
		// modifiers
		xmlmodify_PluginInstall(dm);
		textmodify_PluginInstall(dm);
		return 0;
	}

	const char *deplog = getenv("trideplog");
	if(deplog) {
		int logtoshow = atoi(deplog);
		if(!logtoshow) {
			dm.exitWithError("Invalid deploymentid for -showlog");
		}
		return showDeploymentLog(*odbc, logtoshow);
	}

	const char *fileToParse = NULL;
	if((fileToParse = getenv("triparse")) != NULL) {
		int ret = 0;
		try {
			ret = dm.parse(fileToParse);
			if(ret == 0) {
				printf("\"%s\" parsed ok.\n", fileToParse);
			}
		} catch(DMException &e) {
			e.print(dm);
			ret = 4;
		}
		return ret;
	}

	if(getenv("triencrypt")) {
		Model model(*odbc, dm.getHostname());
		dm.setModel(&model);
		setCurrentUser(dm);
		ensurePassphraseFile(dm, homeDir);

		// Read first line of input from stdin
		char line[1024];
		if(!fgets(line, sizeof(line), stdin)) {
			dm.exitWithError("No input given");
		}

		// Trim trailing newline
		for(char *x = &line[strlen(line) - 1];
				(x > line) && ((*x == '\r') || (*x == '\n')); x--) {
			*x = '\0';
		}

		//dumpbuffer(line, strlen(line));
		
		try {
			ConstCharPtr encLine = encryptValue(line, strlen(line));
			printf("%s\n", (const char*) encLine);
		} catch(DMException &e) {
			e.print(dm);
			dm.exitWithError("Error during encryption");
		}

		return 0;
	}

	const char *providerTest = NULL;
	if((providerTest = getenv("triprovidertest")) != NULL) {
		OBJECT_KIND kind = OBJ_KIND_NONE;
		if(strcmp(providerTest, "repository") == 0) {
			kind = OBJ_KIND_RESPOSITORY;
		} else if(strcmp(providerTest, "notify") == 0) {
			kind = OBJ_KIND_NOTIFY;
		} else if(strcmp(providerTest, "datasource") == 0) {
			kind = OBJ_KIND_DATASOURCE;
		} else {
			dm.exitWithError("Unrecognised provider type '%s'", providerTest);
		}
		int ret = -1;
		if(nvargv && nvargv[0]) {
			int id = atoi(nvargv[0]);
			if(id > 0) {
#ifdef DEV_VERSION
				if(getenv("tridmhome")) {
					debug0("DMHOME = '%s'", (const char*) homeDir);
				}
#endif /*DEV_VERSION*/
				Model model(*odbc, dm.getHostname());
				dm.setModel(&model);
				setCurrentUser(dm);
				dm.initialize(homeDir, nvargv, envp);
				ret = dm.providerTest(kind, id);
				dm.deleteTemporaryFilesAndFolders();
			} else {
				dm.exitWithError("Bad provider id '%s'", nvargv[0]);
			}
		} else {
			dm.exitWithError("No provider id specified");
		}
		return ret;
	}

	const char *notifier = NULL;
	if((notifier = getenv("trinotify")) != NULL) {
		int ret = -1;
		int nfyid = atoi(notifier);
		if(nfyid > 0) {
			const char *notifyFrom = getenv("trifrom");
			if(!notifyFrom) {
				notifyFrom = "dm2@trinem.com";
			}
			const char *notifySubject = getenv("trisubject");
			if(!notifySubject) {
				 notifySubject = "Notification from DM2";
			}
			int templateid = 0;
			const char *notifyTemplate = getenv("tritemplate");
			if(notifyTemplate) {
				templateid = atoi(notifyTemplate);
				if(templateid == 0) {
					dm.exitWithError("Bad template id '%s'", notifyTemplate);
				}
			}
			if(nvargv && nvargv[0]) {
#ifdef DEV_VERSION
				if(getenv("tridmhome")) {
					debug0("DMHOME = '%s'", (const char*) homeDir);
				}
#endif /*DEV_VERSION*/
				Model model(*odbc, dm.getHostname());
				dm.setModel(&model);
				setCurrentUser(dm);
				setTargetAppAndEnvFromParams(dm, false);
				dm.initialize(homeDir, nvargv, envp);
				ret = dm.doNotify(nfyid, notifyFrom, notifySubject, templateid);
				dm.deleteTemporaryFilesAndFolders();
			} else {
				dm.exitWithError("No recipients specified");
			}
		} else {
			dm.exitWithError("Bad notifier id '%s'", notifier);
		}
		return ret;
	}

	const char *runtask = NULL;
	if((runtask = getenv("triruntask")) != NULL) {
		int ret = -1;
		int taskid = atoi(runtask);
		if(taskid > 0) {
			Model model(*odbc, dm.getHostname());
			dm.setModel(&model);
			setCurrentUser(dm);
			setTargetAppAndEnvFromParams(dm, false);
			ret = runTask(dm, taskid, homeDir, nvargv, envp);
			dm.deleteTemporaryFilesAndFolders();
		} else {
			dm.exitWithError("Bad task id '%s'", runtask);
		}
		return ret;
	}

	switch(reason)
	{
#if 1
	case REASON_UNSET:
		// TODO: Remove this - it is here so we can run from debugger
		// Have we been invoked with a web-interface deployment flag
		if(!getenv("triappname") && !getenv("triappid")
				&& !getenv("trienvname") && !getenv("trienvid")) {
			// Run script with some test data set - -usr toggles between demo and testsuite
			const char *user = getenv("TRIDM_USER");
			if(user && (strcmp(user, "demo") == 0)) {
				putenv(strdup("TRIFIELD1=Demo Environment (SSH)"));
				putenv(strdup("TRIFIELD2="));
				putenv(strdup("TRIFIELD3="));
				//putenv(strdup("TRIFIELD4=DMDemo AppVer 2.0"));
				putenv(strdup("TRIFIELD4=DMDemo P4 Components"));

				nvargv = (char**) malloc(5 * sizeof(char*));
				nvargv[0] = (char*) "cmdln_haruser=harvest";
				nvargv[1] = (char*) "cmdln_harpass=harvest";
				nvargv[2] = (char*) "cmdln_harproject=DMDemo";
				nvargv[3] = (char*) "cmdln_harstate=Test";
				//nvargv[4] = (char*) "cmdln_harpackages='DMDemo-2.0'";
				//nvargv[5] = NULL;
				//nvargv[4] = (char*) "DMDemo-1.0";
				nvargv[4] = (char*) "DMDemo-2.0";
				nvargv[5] = NULL;
			} else {
				putenv(strdup("TRIFIELD1=envA"));
				putenv(strdup("TRIFIELD2=harvest"));
				putenv(strdup("TRIFIELD3=harvest"));
				putenv(strdup("TRIFIELD4=app2"));
				//putenv(strdup("TRIFIELD4=CreditScore"));
				nvargv = (char**) malloc(3 * sizeof(char*));
				nvargv[0] = (char*) "cmdln_haruser=harvest";
				nvargv[1] = (char*) "cmdln_harpass=harvest";
				nvargv[2] = NULL;
			}

			if(!user) {
				putenv(strdup("TRIDM_USER=robert"));
			}
		}
		// fall thru...
#endif /*0*/

	case REASON_SCRIPT:
	case REASON_TIMED: {
#ifdef DEV_VERSION
		if(getenv("tridmhome")) {
			debug0("DMHOME = '%s'", (const char*) homeDir);
		}
#endif /*DEV_VERSION*/
		if(getenv("tritestmode")) {
			return testThings(*odbc);
		}

		License lic;
		lic.OpenLicenseFile(homeDir, "dm.lic");
		LicenseError licerror = lic.LoadLicenseFile();
		if(licerror == CouldNotOpenLicenseFile) {
			dm.exitWithError("Could not find or open license file \"%s\"", "dm.lic");
		} else if(licerror == CorruptLicenseFile) {
			dm.exitWithError("Invalid or corrupt license file \"%s\"", "dm.lic");
		}
		if(lic.CheckForExpiredLicense()) {
			dm.exitWithError("License key has expired.\n"
				"Please contact OpenMake Software for a new license key");
		}
		if(lic.CheckForInvalidHostName()) {
			dm.exitWithError("License key is not valid for this host.\n"
				"Please contact OpenMake Software for a new license key");
		}
		Model model(*odbc, dm.getHostname());
		dm.setModel(&model);
		setCurrentUser(dm);

		if(getenv("triappname") || getenv("triappid")
				|| getenv("trienvname") || getenv("trienvid")) {
			setTargetAppAndEnvFromParams(dm, true);
		} else {
			validateDialog(dm, model);
			const char *envname = getEnvironmentNameFromDialog(dm);
			if(!envname) {
				dm.exitWithError("Environment name must be specified");
			}
			const char *appname = getApplicationNameFromDialog(dm);
			if(!appname) {
				dm.exitWithError("Application name must be specified");
			}
			if(!dm.setTargetEnvironment(envname)) {
				dm.exitWithError("Invalid environment '%s' specified", envname);
			}
			if(!dm.setTargetApplication(appname)) {
				dm.exitWithError("Invalid application '%s' specified", appname);
			}
		}
		Environment &targetEnv = *dm.getTargetEnvironment();
		if(!targetEnv.hasAccess(dm.getCurrentUser())) {
			dm.exitWithError(
				"You do not have permission to deploy to the environment '%s'",
				targetEnv.name());
		}
		if(!targetEnv.isAvailable()) {
			dm.exitWithError(
				"Environment '%s' is not available at this time",
				targetEnv.name());
		}
		Application &targetApp = *dm.getTargetApplication();
		if(!targetApp.hasAccess(dm.getCurrentUser())) {
			dm.exitWithError(
				"You do not have permission to deploy the application '%s'",
				targetApp.name());
		}
		if(!targetApp.isAvailable(targetEnv)) {
			dm.exitWithError(
				"Application '%s' cannot be deployed into environment '%s' at this time",
				targetApp.name(), targetEnv.name());
		}
		ensurePassphraseFile(dm, homeDir);
		// Create encrypted dialog credentials that we can pass around
		Credentials *dialogCreds = NULL;
		const char *username = getUserNameFromDialog(dm);
		const char *password = getPasswordFromDialog(dm);
		if(username || password) {
			try {
				ConstCharPtr encuser = encryptValue(username, strlen(username));
				ConstCharPtr encpass = encryptValue(password, strlen(password));
				dialogCreds = new Credentials(0, "DialogCredentials", CREDENTIALS_ENCRYPTED, encuser, encpass);
			} catch(DMException &e) {
				e.print(dm);
				dm.exitWithError("FATAL ERROR: Credentials encryption failed");
			}
		}
		dm.setDialogCredentials(dialogCreds);
		int ret = 0;
		try {
			dm.startAudit();	// Startup auditing system
			dm.writeToStdOut("Starting deployment #%d", dm.deployId());
			clock_t start = clock();
			ret = runScript(dm, homeDir, nvargv, envp);
			clock_t finish = clock();
			clock_t elapsed = finish - start;
			//printf("Time taken %f\n", ((float) elapsed)/CLOCKS_PER_SEC);
			dm.writeToStdOut("Time taken %f", ((float) elapsed)/CLOCKS_PER_SEC);
		} catch(DMException &e) {
			debug0("Unhandled DMException in main - exit code -1");
			e.print(dm);
			dm.finishAudit(-1);
			dm.deleteTemporaryFilesAndFolders();
			SAFE_DELETE(dialogCreds);
			return -1;
		} catch(...) {
			debug0("Unhandled exception in main - exit code -1");
			dm.finishAudit(-1);
			dm.deleteTemporaryFilesAndFolders();
			SAFE_DELETE(dialogCreds);
			return -1;	//throw;
		}
		debug3("Finished - exit code %d", ret);
		dm.finishAudit(ret);
		dm.deleteTemporaryFilesAndFolders();
		SAFE_DELETE(dialogCreds);
		return ret;
		}

	case REASON_VALIDATION: {
		Model model(*odbc, dm.getHostname());
		dm.setModel(&model);
		dm.getDummyAudit();
		return validateDialog(dm, model);
		}

#if 0
	case REASON_UNSET:
		// Run script with some test data set
		putenv(strdup("trifields=environments,username,password,applications,combo1,combo2,combo3"));
		//putenv(strdup("TRICURRENTFIELD=1"));
		putenv(strdup("TRICURRENTFIELD=7"));
		putenv(strdup("TRIFIELD1=envA"));
		putenv(strdup("TRIDM_USER=robert"));
		// fall thru...
#endif /*0*/

	case REASON_POPULATE: {
		Model model(*odbc, dm.getHostname());
		dm.setModel(&model);
		dm.getDummyAudit();
		setCurrentUser(dm);
		dm.initialize(homeDir, nvargv, envp);
		int res = handleFieldPopulation(dm, model);
		dm.cleanup();
		dm.deleteTemporaryFilesAndFolders();
		return res;
		}

#if 0
	case REASON_UNSET:
		putenv(strdup("TRIDM_USER=robert"));
		// fall thru...
#endif /*0*/

	case REASON_LISTBOX: {
		Model model(*odbc, dm.getHostname());
		dm.setModel(&model);
		dm.getDummyAudit();
		setCurrentUser(dm);
		ensurePassphraseFile(dm, homeDir);
		int res = runListboxScript(dm, homeDir, nvargv, envp);
		dm.cleanup();
		dm.deleteTemporaryFilesAndFolders();
		return res;
		}

#ifdef HAVE_TRILOGYAPI
	case REASON_PRELOAD: {
		dm.writeToLogFile("PRELOAD");
		OnPopulateAnyField(PreloadPopulateField);
		int ret = WaitForTrilogy(60, argc, argv);
		dm.writeToLogFile("EXITING - ret = %d", ret);
		return 0;
		}
		break;
#endif /*HAVE_TRILOGYAPI*/
	}

	} catch(DMException &e) {
		fprintf(stderr, "Unhandled exception: %s\n", e.getMessage());
		fprintf(stdout, "Unhandled exception: %s\n", e.getMessage());
	} catch(...) {
		fprintf(stderr, "Unknown exception\n");
		fprintf(stdout, "Unknown exception\n");
	}
	return 0;
}


#ifdef WIN32
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
    }
    return TRUE;
}
#endif /*WIN32*/
